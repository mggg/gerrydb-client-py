--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.4 (Debian 16.4-1.pgdg110+2)
-- Dumped by pg_dump version 17.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: gerrydb; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA gerrydb;


ALTER SCHEMA gerrydb OWNER TO postgres;

--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: columnkind; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.columnkind AS ENUM (
    'COUNT',
    'PERCENT',
    'CATEGORICAL',
    'IDENTIFIER',
    'AREA',
    'OTHER'
);


ALTER TYPE public.columnkind OWNER TO postgres;

--
-- Name: columntype; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.columntype AS ENUM (
    'FLOAT',
    'INT',
    'BOOL',
    'STR',
    'JSON'
);


ALTER TYPE public.columntype OWNER TO postgres;

--
-- Name: graphrenderstatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.graphrenderstatus AS ENUM (
    'PENDING',
    'RUNNING',
    'FAILED',
    'SUCCEEDED'
);


ALTER TYPE public.graphrenderstatus OWNER TO postgres;

--
-- Name: namespacegroup; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.namespacegroup AS ENUM (
    'PUBLIC',
    'PRIVATE',
    'ALL'
);


ALTER TYPE public.namespacegroup OWNER TO postgres;

--
-- Name: scopetype; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.scopetype AS ENUM (
    'NAMESPACE_READ',
    'NAMESPACE_WRITE',
    'NAMESPACE_WRITE_DERIVED',
    'NAMESPACE_CREATE',
    'LOCALITY_READ',
    'LOCALITY_WRITE',
    'META_READ',
    'META_WRITE',
    'ALL'
);


ALTER TYPE public.scopetype OWNER TO postgres;

--
-- Name: viewrenderstatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.viewrenderstatus AS ENUM (
    'PENDING',
    'RUNNING',
    'FAILED',
    'SUCCEEDED'
);


ALTER TYPE public.viewrenderstatus OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: api_key; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.api_key (
    key_hash bytea NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    active boolean NOT NULL
);


ALTER TABLE gerrydb.api_key OWNER TO postgres;

--
-- Name: column; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb."column" (
    col_id integer NOT NULL,
    namespace_id integer NOT NULL,
    canonical_ref_id integer NOT NULL,
    description text,
    source_url character varying(2048),
    kind public.columnkind NOT NULL,
    type public.columntype NOT NULL,
    meta_id integer NOT NULL
);


ALTER TABLE gerrydb."column" OWNER TO postgres;

--
-- Name: column_col_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.column_col_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.column_col_id_seq OWNER TO postgres;

--
-- Name: column_col_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.column_col_id_seq OWNED BY gerrydb."column".col_id;


--
-- Name: column_ref; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_ref (
    ref_id integer NOT NULL,
    namespace_id integer NOT NULL,
    col_id integer,
    path text NOT NULL,
    meta_id integer NOT NULL
);


ALTER TABLE gerrydb.column_ref OWNER TO postgres;

--
-- Name: column_ref_ref_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.column_ref_ref_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.column_ref_ref_id_seq OWNER TO postgres;

--
-- Name: column_ref_ref_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.column_ref_ref_id_seq OWNED BY gerrydb.column_ref.ref_id;


--
-- Name: column_relation; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_relation (
    relation_id integer NOT NULL,
    namespace_id integer NOT NULL,
    name text NOT NULL,
    expr json NOT NULL,
    meta_id integer NOT NULL
);


ALTER TABLE gerrydb.column_relation OWNER TO postgres;

--
-- Name: column_relation_member; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_relation_member (
    relation_id integer NOT NULL,
    member_id integer NOT NULL
);


ALTER TABLE gerrydb.column_relation_member OWNER TO postgres;

--
-- Name: column_relation_relation_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.column_relation_relation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.column_relation_relation_id_seq OWNER TO postgres;

--
-- Name: column_relation_relation_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.column_relation_relation_id_seq OWNED BY gerrydb.column_relation.relation_id;


--
-- Name: column_set; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_set (
    set_id integer NOT NULL,
    path text NOT NULL,
    namespace_id integer NOT NULL,
    description text,
    meta_id integer NOT NULL
);


ALTER TABLE gerrydb.column_set OWNER TO postgres;

--
-- Name: column_set_member; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_set_member (
    set_id integer NOT NULL,
    ref_id integer NOT NULL,
    "order" integer NOT NULL
);


ALTER TABLE gerrydb.column_set_member OWNER TO postgres;

--
-- Name: column_set_set_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.column_set_set_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.column_set_set_id_seq OWNER TO postgres;

--
-- Name: column_set_set_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.column_set_set_id_seq OWNED BY gerrydb.column_set.set_id;


--
-- Name: column_value; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
)
PARTITION BY LIST (col_id);


ALTER TABLE gerrydb.column_value OWNER TO postgres;

--
-- Name: column_value_1; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_1 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_1 OWNER TO postgres;

--
-- Name: column_value_10; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_10 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_10 OWNER TO postgres;

--
-- Name: column_value_100; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_100 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_100 OWNER TO postgres;

--
-- Name: column_value_101; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_101 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_101 OWNER TO postgres;

--
-- Name: column_value_102; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_102 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_102 OWNER TO postgres;

--
-- Name: column_value_103; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_103 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_103 OWNER TO postgres;

--
-- Name: column_value_104; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_104 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_104 OWNER TO postgres;

--
-- Name: column_value_105; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_105 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_105 OWNER TO postgres;

--
-- Name: column_value_106; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_106 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_106 OWNER TO postgres;

--
-- Name: column_value_107; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_107 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_107 OWNER TO postgres;

--
-- Name: column_value_108; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_108 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_108 OWNER TO postgres;

--
-- Name: column_value_109; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_109 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_109 OWNER TO postgres;

--
-- Name: column_value_11; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_11 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_11 OWNER TO postgres;

--
-- Name: column_value_110; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_110 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_110 OWNER TO postgres;

--
-- Name: column_value_111; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_111 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_111 OWNER TO postgres;

--
-- Name: column_value_112; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_112 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_112 OWNER TO postgres;

--
-- Name: column_value_113; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_113 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_113 OWNER TO postgres;

--
-- Name: column_value_114; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_114 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_114 OWNER TO postgres;

--
-- Name: column_value_115; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_115 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_115 OWNER TO postgres;

--
-- Name: column_value_116; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_116 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_116 OWNER TO postgres;

--
-- Name: column_value_117; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_117 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_117 OWNER TO postgres;

--
-- Name: column_value_118; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_118 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_118 OWNER TO postgres;

--
-- Name: column_value_119; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_119 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_119 OWNER TO postgres;

--
-- Name: column_value_12; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_12 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_12 OWNER TO postgres;

--
-- Name: column_value_120; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_120 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_120 OWNER TO postgres;

--
-- Name: column_value_121; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_121 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_121 OWNER TO postgres;

--
-- Name: column_value_122; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_122 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_122 OWNER TO postgres;

--
-- Name: column_value_123; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_123 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_123 OWNER TO postgres;

--
-- Name: column_value_124; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_124 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_124 OWNER TO postgres;

--
-- Name: column_value_125; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_125 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_125 OWNER TO postgres;

--
-- Name: column_value_126; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_126 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_126 OWNER TO postgres;

--
-- Name: column_value_127; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_127 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_127 OWNER TO postgres;

--
-- Name: column_value_128; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_128 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_128 OWNER TO postgres;

--
-- Name: column_value_129; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_129 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_129 OWNER TO postgres;

--
-- Name: column_value_13; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_13 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_13 OWNER TO postgres;

--
-- Name: column_value_130; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_130 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_130 OWNER TO postgres;

--
-- Name: column_value_131; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_131 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_131 OWNER TO postgres;

--
-- Name: column_value_132; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_132 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_132 OWNER TO postgres;

--
-- Name: column_value_133; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_133 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_133 OWNER TO postgres;

--
-- Name: column_value_134; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_134 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_134 OWNER TO postgres;

--
-- Name: column_value_135; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_135 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_135 OWNER TO postgres;

--
-- Name: column_value_136; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_136 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_136 OWNER TO postgres;

--
-- Name: column_value_137; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_137 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_137 OWNER TO postgres;

--
-- Name: column_value_138; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_138 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_138 OWNER TO postgres;

--
-- Name: column_value_139; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_139 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_139 OWNER TO postgres;

--
-- Name: column_value_14; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_14 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_14 OWNER TO postgres;

--
-- Name: column_value_140; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_140 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_140 OWNER TO postgres;

--
-- Name: column_value_141; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_141 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_141 OWNER TO postgres;

--
-- Name: column_value_142; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_142 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_142 OWNER TO postgres;

--
-- Name: column_value_143; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_143 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_143 OWNER TO postgres;

--
-- Name: column_value_144; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_144 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_144 OWNER TO postgres;

--
-- Name: column_value_145; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_145 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_145 OWNER TO postgres;

--
-- Name: column_value_146; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_146 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_146 OWNER TO postgres;

--
-- Name: column_value_147; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_147 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_147 OWNER TO postgres;

--
-- Name: column_value_148; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_148 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_148 OWNER TO postgres;

--
-- Name: column_value_149; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_149 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_149 OWNER TO postgres;

--
-- Name: column_value_15; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_15 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_15 OWNER TO postgres;

--
-- Name: column_value_150; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_150 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_150 OWNER TO postgres;

--
-- Name: column_value_151; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_151 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_151 OWNER TO postgres;

--
-- Name: column_value_152; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_152 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_152 OWNER TO postgres;

--
-- Name: column_value_153; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_153 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_153 OWNER TO postgres;

--
-- Name: column_value_154; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_154 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_154 OWNER TO postgres;

--
-- Name: column_value_155; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_155 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_155 OWNER TO postgres;

--
-- Name: column_value_156; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_156 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_156 OWNER TO postgres;

--
-- Name: column_value_157; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_157 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_157 OWNER TO postgres;

--
-- Name: column_value_158; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_158 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_158 OWNER TO postgres;

--
-- Name: column_value_159; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_159 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_159 OWNER TO postgres;

--
-- Name: column_value_16; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_16 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_16 OWNER TO postgres;

--
-- Name: column_value_160; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_160 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_160 OWNER TO postgres;

--
-- Name: column_value_161; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_161 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_161 OWNER TO postgres;

--
-- Name: column_value_162; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_162 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_162 OWNER TO postgres;

--
-- Name: column_value_163; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_163 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_163 OWNER TO postgres;

--
-- Name: column_value_164; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_164 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_164 OWNER TO postgres;

--
-- Name: column_value_165; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_165 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_165 OWNER TO postgres;

--
-- Name: column_value_166; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_166 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_166 OWNER TO postgres;

--
-- Name: column_value_167; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_167 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_167 OWNER TO postgres;

--
-- Name: column_value_168; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_168 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_168 OWNER TO postgres;

--
-- Name: column_value_169; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_169 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_169 OWNER TO postgres;

--
-- Name: column_value_17; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_17 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_17 OWNER TO postgres;

--
-- Name: column_value_170; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_170 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_170 OWNER TO postgres;

--
-- Name: column_value_171; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_171 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_171 OWNER TO postgres;

--
-- Name: column_value_172; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_172 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_172 OWNER TO postgres;

--
-- Name: column_value_173; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_173 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_173 OWNER TO postgres;

--
-- Name: column_value_174; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_174 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_174 OWNER TO postgres;

--
-- Name: column_value_175; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_175 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_175 OWNER TO postgres;

--
-- Name: column_value_176; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_176 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_176 OWNER TO postgres;

--
-- Name: column_value_177; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_177 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_177 OWNER TO postgres;

--
-- Name: column_value_178; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_178 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_178 OWNER TO postgres;

--
-- Name: column_value_179; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_179 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_179 OWNER TO postgres;

--
-- Name: column_value_18; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_18 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_18 OWNER TO postgres;

--
-- Name: column_value_180; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_180 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_180 OWNER TO postgres;

--
-- Name: column_value_181; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_181 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_181 OWNER TO postgres;

--
-- Name: column_value_182; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_182 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_182 OWNER TO postgres;

--
-- Name: column_value_183; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_183 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_183 OWNER TO postgres;

--
-- Name: column_value_184; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_184 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_184 OWNER TO postgres;

--
-- Name: column_value_185; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_185 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_185 OWNER TO postgres;

--
-- Name: column_value_186; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_186 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_186 OWNER TO postgres;

--
-- Name: column_value_187; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_187 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_187 OWNER TO postgres;

--
-- Name: column_value_188; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_188 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_188 OWNER TO postgres;

--
-- Name: column_value_189; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_189 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_189 OWNER TO postgres;

--
-- Name: column_value_19; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_19 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_19 OWNER TO postgres;

--
-- Name: column_value_190; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_190 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_190 OWNER TO postgres;

--
-- Name: column_value_191; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_191 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_191 OWNER TO postgres;

--
-- Name: column_value_192; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_192 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_192 OWNER TO postgres;

--
-- Name: column_value_193; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_193 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_193 OWNER TO postgres;

--
-- Name: column_value_194; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_194 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_194 OWNER TO postgres;

--
-- Name: column_value_195; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_195 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_195 OWNER TO postgres;

--
-- Name: column_value_196; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_196 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_196 OWNER TO postgres;

--
-- Name: column_value_197; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_197 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_197 OWNER TO postgres;

--
-- Name: column_value_198; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_198 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_198 OWNER TO postgres;

--
-- Name: column_value_199; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_199 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_199 OWNER TO postgres;

--
-- Name: column_value_2; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_2 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_2 OWNER TO postgres;

--
-- Name: column_value_20; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_20 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_20 OWNER TO postgres;

--
-- Name: column_value_200; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_200 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_200 OWNER TO postgres;

--
-- Name: column_value_201; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_201 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_201 OWNER TO postgres;

--
-- Name: column_value_202; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_202 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_202 OWNER TO postgres;

--
-- Name: column_value_203; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_203 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_203 OWNER TO postgres;

--
-- Name: column_value_204; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_204 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_204 OWNER TO postgres;

--
-- Name: column_value_205; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_205 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_205 OWNER TO postgres;

--
-- Name: column_value_206; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_206 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_206 OWNER TO postgres;

--
-- Name: column_value_207; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_207 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_207 OWNER TO postgres;

--
-- Name: column_value_208; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_208 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_208 OWNER TO postgres;

--
-- Name: column_value_209; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_209 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_209 OWNER TO postgres;

--
-- Name: column_value_21; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_21 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_21 OWNER TO postgres;

--
-- Name: column_value_210; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_210 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_210 OWNER TO postgres;

--
-- Name: column_value_211; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_211 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_211 OWNER TO postgres;

--
-- Name: column_value_212; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_212 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_212 OWNER TO postgres;

--
-- Name: column_value_213; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_213 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_213 OWNER TO postgres;

--
-- Name: column_value_214; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_214 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_214 OWNER TO postgres;

--
-- Name: column_value_215; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_215 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_215 OWNER TO postgres;

--
-- Name: column_value_216; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_216 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_216 OWNER TO postgres;

--
-- Name: column_value_217; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_217 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_217 OWNER TO postgres;

--
-- Name: column_value_218; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_218 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_218 OWNER TO postgres;

--
-- Name: column_value_219; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_219 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_219 OWNER TO postgres;

--
-- Name: column_value_22; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_22 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_22 OWNER TO postgres;

--
-- Name: column_value_220; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_220 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_220 OWNER TO postgres;

--
-- Name: column_value_221; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_221 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_221 OWNER TO postgres;

--
-- Name: column_value_222; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_222 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_222 OWNER TO postgres;

--
-- Name: column_value_223; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_223 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_223 OWNER TO postgres;

--
-- Name: column_value_224; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_224 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_224 OWNER TO postgres;

--
-- Name: column_value_225; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_225 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_225 OWNER TO postgres;

--
-- Name: column_value_226; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_226 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_226 OWNER TO postgres;

--
-- Name: column_value_227; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_227 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_227 OWNER TO postgres;

--
-- Name: column_value_228; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_228 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_228 OWNER TO postgres;

--
-- Name: column_value_229; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_229 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_229 OWNER TO postgres;

--
-- Name: column_value_23; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_23 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_23 OWNER TO postgres;

--
-- Name: column_value_230; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_230 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_230 OWNER TO postgres;

--
-- Name: column_value_231; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_231 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_231 OWNER TO postgres;

--
-- Name: column_value_232; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_232 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_232 OWNER TO postgres;

--
-- Name: column_value_233; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_233 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_233 OWNER TO postgres;

--
-- Name: column_value_234; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_234 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_234 OWNER TO postgres;

--
-- Name: column_value_235; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_235 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_235 OWNER TO postgres;

--
-- Name: column_value_236; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_236 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_236 OWNER TO postgres;

--
-- Name: column_value_237; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_237 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_237 OWNER TO postgres;

--
-- Name: column_value_238; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_238 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_238 OWNER TO postgres;

--
-- Name: column_value_239; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_239 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_239 OWNER TO postgres;

--
-- Name: column_value_24; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_24 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_24 OWNER TO postgres;

--
-- Name: column_value_240; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_240 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_240 OWNER TO postgres;

--
-- Name: column_value_241; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_241 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_241 OWNER TO postgres;

--
-- Name: column_value_242; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_242 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_242 OWNER TO postgres;

--
-- Name: column_value_243; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_243 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_243 OWNER TO postgres;

--
-- Name: column_value_244; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_244 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_244 OWNER TO postgres;

--
-- Name: column_value_245; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_245 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_245 OWNER TO postgres;

--
-- Name: column_value_246; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_246 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_246 OWNER TO postgres;

--
-- Name: column_value_247; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_247 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_247 OWNER TO postgres;

--
-- Name: column_value_248; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_248 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_248 OWNER TO postgres;

--
-- Name: column_value_249; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_249 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_249 OWNER TO postgres;

--
-- Name: column_value_25; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_25 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_25 OWNER TO postgres;

--
-- Name: column_value_250; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_250 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_250 OWNER TO postgres;

--
-- Name: column_value_251; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_251 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_251 OWNER TO postgres;

--
-- Name: column_value_252; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_252 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_252 OWNER TO postgres;

--
-- Name: column_value_253; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_253 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_253 OWNER TO postgres;

--
-- Name: column_value_254; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_254 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_254 OWNER TO postgres;

--
-- Name: column_value_255; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_255 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_255 OWNER TO postgres;

--
-- Name: column_value_256; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_256 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_256 OWNER TO postgres;

--
-- Name: column_value_257; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_257 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_257 OWNER TO postgres;

--
-- Name: column_value_258; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_258 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_258 OWNER TO postgres;

--
-- Name: column_value_259; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_259 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_259 OWNER TO postgres;

--
-- Name: column_value_26; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_26 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_26 OWNER TO postgres;

--
-- Name: column_value_260; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_260 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_260 OWNER TO postgres;

--
-- Name: column_value_261; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_261 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_261 OWNER TO postgres;

--
-- Name: column_value_262; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_262 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_262 OWNER TO postgres;

--
-- Name: column_value_263; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_263 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_263 OWNER TO postgres;

--
-- Name: column_value_264; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_264 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_264 OWNER TO postgres;

--
-- Name: column_value_265; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_265 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_265 OWNER TO postgres;

--
-- Name: column_value_266; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_266 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_266 OWNER TO postgres;

--
-- Name: column_value_267; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_267 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_267 OWNER TO postgres;

--
-- Name: column_value_268; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_268 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_268 OWNER TO postgres;

--
-- Name: column_value_269; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_269 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_269 OWNER TO postgres;

--
-- Name: column_value_27; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_27 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_27 OWNER TO postgres;

--
-- Name: column_value_270; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_270 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_270 OWNER TO postgres;

--
-- Name: column_value_271; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_271 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_271 OWNER TO postgres;

--
-- Name: column_value_272; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_272 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_272 OWNER TO postgres;

--
-- Name: column_value_273; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_273 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_273 OWNER TO postgres;

--
-- Name: column_value_274; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_274 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_274 OWNER TO postgres;

--
-- Name: column_value_275; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_275 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_275 OWNER TO postgres;

--
-- Name: column_value_276; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_276 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_276 OWNER TO postgres;

--
-- Name: column_value_277; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_277 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_277 OWNER TO postgres;

--
-- Name: column_value_278; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_278 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_278 OWNER TO postgres;

--
-- Name: column_value_279; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_279 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_279 OWNER TO postgres;

--
-- Name: column_value_28; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_28 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_28 OWNER TO postgres;

--
-- Name: column_value_280; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_280 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_280 OWNER TO postgres;

--
-- Name: column_value_281; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_281 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_281 OWNER TO postgres;

--
-- Name: column_value_282; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_282 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_282 OWNER TO postgres;

--
-- Name: column_value_283; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_283 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_283 OWNER TO postgres;

--
-- Name: column_value_284; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_284 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_284 OWNER TO postgres;

--
-- Name: column_value_285; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_285 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_285 OWNER TO postgres;

--
-- Name: column_value_286; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_286 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_286 OWNER TO postgres;

--
-- Name: column_value_287; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_287 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_287 OWNER TO postgres;

--
-- Name: column_value_288; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_288 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_288 OWNER TO postgres;

--
-- Name: column_value_289; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_289 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_289 OWNER TO postgres;

--
-- Name: column_value_29; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_29 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_29 OWNER TO postgres;

--
-- Name: column_value_290; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_290 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_290 OWNER TO postgres;

--
-- Name: column_value_291; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_291 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_291 OWNER TO postgres;

--
-- Name: column_value_292; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_292 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_292 OWNER TO postgres;

--
-- Name: column_value_293; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_293 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_293 OWNER TO postgres;

--
-- Name: column_value_294; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_294 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_294 OWNER TO postgres;

--
-- Name: column_value_295; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_295 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_295 OWNER TO postgres;

--
-- Name: column_value_296; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_296 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_296 OWNER TO postgres;

--
-- Name: column_value_297; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_297 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_297 OWNER TO postgres;

--
-- Name: column_value_298; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_298 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_298 OWNER TO postgres;

--
-- Name: column_value_299; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_299 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_299 OWNER TO postgres;

--
-- Name: column_value_3; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_3 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_3 OWNER TO postgres;

--
-- Name: column_value_30; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_30 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_30 OWNER TO postgres;

--
-- Name: column_value_300; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_300 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_300 OWNER TO postgres;

--
-- Name: column_value_301; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_301 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_301 OWNER TO postgres;

--
-- Name: column_value_302; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_302 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_302 OWNER TO postgres;

--
-- Name: column_value_303; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_303 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_303 OWNER TO postgres;

--
-- Name: column_value_304; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_304 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_304 OWNER TO postgres;

--
-- Name: column_value_305; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_305 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_305 OWNER TO postgres;

--
-- Name: column_value_306; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_306 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_306 OWNER TO postgres;

--
-- Name: column_value_307; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_307 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_307 OWNER TO postgres;

--
-- Name: column_value_308; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_308 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_308 OWNER TO postgres;

--
-- Name: column_value_309; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_309 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_309 OWNER TO postgres;

--
-- Name: column_value_31; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_31 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_31 OWNER TO postgres;

--
-- Name: column_value_310; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_310 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_310 OWNER TO postgres;

--
-- Name: column_value_311; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_311 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_311 OWNER TO postgres;

--
-- Name: column_value_312; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_312 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_312 OWNER TO postgres;

--
-- Name: column_value_313; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_313 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_313 OWNER TO postgres;

--
-- Name: column_value_314; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_314 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_314 OWNER TO postgres;

--
-- Name: column_value_315; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_315 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_315 OWNER TO postgres;

--
-- Name: column_value_316; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_316 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_316 OWNER TO postgres;

--
-- Name: column_value_317; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_317 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_317 OWNER TO postgres;

--
-- Name: column_value_318; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_318 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_318 OWNER TO postgres;

--
-- Name: column_value_319; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_319 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_319 OWNER TO postgres;

--
-- Name: column_value_32; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_32 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_32 OWNER TO postgres;

--
-- Name: column_value_320; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_320 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_320 OWNER TO postgres;

--
-- Name: column_value_321; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_321 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_321 OWNER TO postgres;

--
-- Name: column_value_322; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_322 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_322 OWNER TO postgres;

--
-- Name: column_value_323; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_323 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_323 OWNER TO postgres;

--
-- Name: column_value_324; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_324 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_324 OWNER TO postgres;

--
-- Name: column_value_325; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_325 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_325 OWNER TO postgres;

--
-- Name: column_value_326; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_326 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_326 OWNER TO postgres;

--
-- Name: column_value_327; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_327 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_327 OWNER TO postgres;

--
-- Name: column_value_328; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_328 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_328 OWNER TO postgres;

--
-- Name: column_value_329; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_329 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_329 OWNER TO postgres;

--
-- Name: column_value_33; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_33 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_33 OWNER TO postgres;

--
-- Name: column_value_330; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_330 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_330 OWNER TO postgres;

--
-- Name: column_value_331; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_331 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_331 OWNER TO postgres;

--
-- Name: column_value_332; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_332 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_332 OWNER TO postgres;

--
-- Name: column_value_333; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_333 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_333 OWNER TO postgres;

--
-- Name: column_value_334; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_334 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_334 OWNER TO postgres;

--
-- Name: column_value_335; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_335 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_335 OWNER TO postgres;

--
-- Name: column_value_336; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_336 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_336 OWNER TO postgres;

--
-- Name: column_value_337; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_337 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_337 OWNER TO postgres;

--
-- Name: column_value_338; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_338 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_338 OWNER TO postgres;

--
-- Name: column_value_339; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_339 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_339 OWNER TO postgres;

--
-- Name: column_value_34; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_34 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_34 OWNER TO postgres;

--
-- Name: column_value_340; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_340 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_340 OWNER TO postgres;

--
-- Name: column_value_341; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_341 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_341 OWNER TO postgres;

--
-- Name: column_value_342; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_342 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_342 OWNER TO postgres;

--
-- Name: column_value_343; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_343 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_343 OWNER TO postgres;

--
-- Name: column_value_344; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_344 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_344 OWNER TO postgres;

--
-- Name: column_value_345; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_345 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_345 OWNER TO postgres;

--
-- Name: column_value_346; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_346 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_346 OWNER TO postgres;

--
-- Name: column_value_347; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_347 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_347 OWNER TO postgres;

--
-- Name: column_value_348; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_348 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_348 OWNER TO postgres;

--
-- Name: column_value_349; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_349 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_349 OWNER TO postgres;

--
-- Name: column_value_35; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_35 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_35 OWNER TO postgres;

--
-- Name: column_value_350; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_350 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_350 OWNER TO postgres;

--
-- Name: column_value_351; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_351 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_351 OWNER TO postgres;

--
-- Name: column_value_352; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_352 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_352 OWNER TO postgres;

--
-- Name: column_value_353; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_353 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_353 OWNER TO postgres;

--
-- Name: column_value_354; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_354 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_354 OWNER TO postgres;

--
-- Name: column_value_355; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_355 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_355 OWNER TO postgres;

--
-- Name: column_value_356; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_356 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_356 OWNER TO postgres;

--
-- Name: column_value_357; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_357 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_357 OWNER TO postgres;

--
-- Name: column_value_358; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_358 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_358 OWNER TO postgres;

--
-- Name: column_value_359; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_359 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_359 OWNER TO postgres;

--
-- Name: column_value_36; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_36 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_36 OWNER TO postgres;

--
-- Name: column_value_360; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_360 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_360 OWNER TO postgres;

--
-- Name: column_value_361; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_361 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_361 OWNER TO postgres;

--
-- Name: column_value_362; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_362 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_362 OWNER TO postgres;

--
-- Name: column_value_363; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_363 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_363 OWNER TO postgres;

--
-- Name: column_value_364; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_364 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_364 OWNER TO postgres;

--
-- Name: column_value_365; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_365 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_365 OWNER TO postgres;

--
-- Name: column_value_366; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_366 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_366 OWNER TO postgres;

--
-- Name: column_value_367; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_367 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_367 OWNER TO postgres;

--
-- Name: column_value_368; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_368 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_368 OWNER TO postgres;

--
-- Name: column_value_369; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_369 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_369 OWNER TO postgres;

--
-- Name: column_value_37; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_37 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_37 OWNER TO postgres;

--
-- Name: column_value_370; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_370 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_370 OWNER TO postgres;

--
-- Name: column_value_371; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_371 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_371 OWNER TO postgres;

--
-- Name: column_value_372; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_372 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_372 OWNER TO postgres;

--
-- Name: column_value_373; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_373 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_373 OWNER TO postgres;

--
-- Name: column_value_374; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_374 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_374 OWNER TO postgres;

--
-- Name: column_value_375; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_375 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_375 OWNER TO postgres;

--
-- Name: column_value_376; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_376 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_376 OWNER TO postgres;

--
-- Name: column_value_377; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_377 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_377 OWNER TO postgres;

--
-- Name: column_value_378; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_378 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_378 OWNER TO postgres;

--
-- Name: column_value_379; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_379 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_379 OWNER TO postgres;

--
-- Name: column_value_38; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_38 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_38 OWNER TO postgres;

--
-- Name: column_value_380; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_380 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_380 OWNER TO postgres;

--
-- Name: column_value_381; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_381 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_381 OWNER TO postgres;

--
-- Name: column_value_382; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_382 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_382 OWNER TO postgres;

--
-- Name: column_value_383; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_383 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_383 OWNER TO postgres;

--
-- Name: column_value_384; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_384 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_384 OWNER TO postgres;

--
-- Name: column_value_385; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_385 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_385 OWNER TO postgres;

--
-- Name: column_value_386; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_386 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_386 OWNER TO postgres;

--
-- Name: column_value_387; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_387 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_387 OWNER TO postgres;

--
-- Name: column_value_388; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_388 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_388 OWNER TO postgres;

--
-- Name: column_value_389; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_389 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_389 OWNER TO postgres;

--
-- Name: column_value_39; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_39 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_39 OWNER TO postgres;

--
-- Name: column_value_390; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_390 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_390 OWNER TO postgres;

--
-- Name: column_value_391; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_391 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_391 OWNER TO postgres;

--
-- Name: column_value_392; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_392 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_392 OWNER TO postgres;

--
-- Name: column_value_393; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_393 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_393 OWNER TO postgres;

--
-- Name: column_value_394; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_394 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_394 OWNER TO postgres;

--
-- Name: column_value_395; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_395 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_395 OWNER TO postgres;

--
-- Name: column_value_396; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_396 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_396 OWNER TO postgres;

--
-- Name: column_value_397; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_397 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_397 OWNER TO postgres;

--
-- Name: column_value_398; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_398 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_398 OWNER TO postgres;

--
-- Name: column_value_399; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_399 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_399 OWNER TO postgres;

--
-- Name: column_value_4; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_4 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_4 OWNER TO postgres;

--
-- Name: column_value_40; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_40 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_40 OWNER TO postgres;

--
-- Name: column_value_400; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_400 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_400 OWNER TO postgres;

--
-- Name: column_value_401; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_401 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_401 OWNER TO postgres;

--
-- Name: column_value_402; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_402 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_402 OWNER TO postgres;

--
-- Name: column_value_403; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_403 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_403 OWNER TO postgres;

--
-- Name: column_value_404; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_404 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_404 OWNER TO postgres;

--
-- Name: column_value_405; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_405 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_405 OWNER TO postgres;

--
-- Name: column_value_406; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_406 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_406 OWNER TO postgres;

--
-- Name: column_value_407; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_407 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_407 OWNER TO postgres;

--
-- Name: column_value_408; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_408 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_408 OWNER TO postgres;

--
-- Name: column_value_409; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_409 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_409 OWNER TO postgres;

--
-- Name: column_value_41; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_41 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_41 OWNER TO postgres;

--
-- Name: column_value_410; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_410 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_410 OWNER TO postgres;

--
-- Name: column_value_411; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_411 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_411 OWNER TO postgres;

--
-- Name: column_value_412; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_412 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_412 OWNER TO postgres;

--
-- Name: column_value_413; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_413 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_413 OWNER TO postgres;

--
-- Name: column_value_414; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_414 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_414 OWNER TO postgres;

--
-- Name: column_value_415; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_415 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_415 OWNER TO postgres;

--
-- Name: column_value_416; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_416 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_416 OWNER TO postgres;

--
-- Name: column_value_417; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_417 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_417 OWNER TO postgres;

--
-- Name: column_value_418; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_418 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_418 OWNER TO postgres;

--
-- Name: column_value_419; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_419 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_419 OWNER TO postgres;

--
-- Name: column_value_42; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_42 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_42 OWNER TO postgres;

--
-- Name: column_value_420; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_420 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_420 OWNER TO postgres;

--
-- Name: column_value_421; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_421 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_421 OWNER TO postgres;

--
-- Name: column_value_422; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_422 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_422 OWNER TO postgres;

--
-- Name: column_value_423; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_423 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_423 OWNER TO postgres;

--
-- Name: column_value_424; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_424 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_424 OWNER TO postgres;

--
-- Name: column_value_425; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_425 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_425 OWNER TO postgres;

--
-- Name: column_value_426; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_426 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_426 OWNER TO postgres;

--
-- Name: column_value_427; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_427 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_427 OWNER TO postgres;

--
-- Name: column_value_428; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_428 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_428 OWNER TO postgres;

--
-- Name: column_value_429; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_429 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_429 OWNER TO postgres;

--
-- Name: column_value_43; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_43 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_43 OWNER TO postgres;

--
-- Name: column_value_430; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_430 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_430 OWNER TO postgres;

--
-- Name: column_value_431; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_431 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_431 OWNER TO postgres;

--
-- Name: column_value_432; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_432 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_432 OWNER TO postgres;

--
-- Name: column_value_433; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_433 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_433 OWNER TO postgres;

--
-- Name: column_value_434; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_434 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_434 OWNER TO postgres;

--
-- Name: column_value_435; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_435 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_435 OWNER TO postgres;

--
-- Name: column_value_436; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_436 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_436 OWNER TO postgres;

--
-- Name: column_value_437; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_437 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_437 OWNER TO postgres;

--
-- Name: column_value_438; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_438 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_438 OWNER TO postgres;

--
-- Name: column_value_439; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_439 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_439 OWNER TO postgres;

--
-- Name: column_value_44; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_44 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_44 OWNER TO postgres;

--
-- Name: column_value_440; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_440 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_440 OWNER TO postgres;

--
-- Name: column_value_441; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_441 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_441 OWNER TO postgres;

--
-- Name: column_value_442; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_442 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_442 OWNER TO postgres;

--
-- Name: column_value_443; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_443 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_443 OWNER TO postgres;

--
-- Name: column_value_444; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_444 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_444 OWNER TO postgres;

--
-- Name: column_value_445; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_445 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_445 OWNER TO postgres;

--
-- Name: column_value_446; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_446 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_446 OWNER TO postgres;

--
-- Name: column_value_447; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_447 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_447 OWNER TO postgres;

--
-- Name: column_value_448; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_448 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_448 OWNER TO postgres;

--
-- Name: column_value_449; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_449 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_449 OWNER TO postgres;

--
-- Name: column_value_45; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_45 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_45 OWNER TO postgres;

--
-- Name: column_value_450; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_450 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_450 OWNER TO postgres;

--
-- Name: column_value_451; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_451 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_451 OWNER TO postgres;

--
-- Name: column_value_452; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_452 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_452 OWNER TO postgres;

--
-- Name: column_value_453; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_453 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_453 OWNER TO postgres;

--
-- Name: column_value_454; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_454 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_454 OWNER TO postgres;

--
-- Name: column_value_455; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_455 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_455 OWNER TO postgres;

--
-- Name: column_value_456; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_456 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_456 OWNER TO postgres;

--
-- Name: column_value_457; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_457 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_457 OWNER TO postgres;

--
-- Name: column_value_458; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_458 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_458 OWNER TO postgres;

--
-- Name: column_value_459; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_459 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_459 OWNER TO postgres;

--
-- Name: column_value_46; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_46 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_46 OWNER TO postgres;

--
-- Name: column_value_460; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_460 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_460 OWNER TO postgres;

--
-- Name: column_value_461; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_461 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_461 OWNER TO postgres;

--
-- Name: column_value_462; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_462 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_462 OWNER TO postgres;

--
-- Name: column_value_463; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_463 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_463 OWNER TO postgres;

--
-- Name: column_value_464; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_464 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_464 OWNER TO postgres;

--
-- Name: column_value_465; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_465 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_465 OWNER TO postgres;

--
-- Name: column_value_466; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_466 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_466 OWNER TO postgres;

--
-- Name: column_value_467; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_467 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_467 OWNER TO postgres;

--
-- Name: column_value_468; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_468 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_468 OWNER TO postgres;

--
-- Name: column_value_469; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_469 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_469 OWNER TO postgres;

--
-- Name: column_value_47; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_47 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_47 OWNER TO postgres;

--
-- Name: column_value_470; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_470 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_470 OWNER TO postgres;

--
-- Name: column_value_471; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_471 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_471 OWNER TO postgres;

--
-- Name: column_value_472; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_472 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_472 OWNER TO postgres;

--
-- Name: column_value_473; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_473 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_473 OWNER TO postgres;

--
-- Name: column_value_474; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_474 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_474 OWNER TO postgres;

--
-- Name: column_value_475; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_475 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_475 OWNER TO postgres;

--
-- Name: column_value_476; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_476 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_476 OWNER TO postgres;

--
-- Name: column_value_477; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_477 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_477 OWNER TO postgres;

--
-- Name: column_value_478; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_478 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_478 OWNER TO postgres;

--
-- Name: column_value_479; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_479 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_479 OWNER TO postgres;

--
-- Name: column_value_48; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_48 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_48 OWNER TO postgres;

--
-- Name: column_value_480; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_480 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_480 OWNER TO postgres;

--
-- Name: column_value_481; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_481 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_481 OWNER TO postgres;

--
-- Name: column_value_482; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_482 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_482 OWNER TO postgres;

--
-- Name: column_value_483; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_483 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_483 OWNER TO postgres;

--
-- Name: column_value_484; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_484 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_484 OWNER TO postgres;

--
-- Name: column_value_485; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_485 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_485 OWNER TO postgres;

--
-- Name: column_value_486; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_486 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_486 OWNER TO postgres;

--
-- Name: column_value_487; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_487 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_487 OWNER TO postgres;

--
-- Name: column_value_488; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_488 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_488 OWNER TO postgres;

--
-- Name: column_value_489; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_489 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_489 OWNER TO postgres;

--
-- Name: column_value_49; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_49 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_49 OWNER TO postgres;

--
-- Name: column_value_490; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_490 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_490 OWNER TO postgres;

--
-- Name: column_value_491; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_491 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_491 OWNER TO postgres;

--
-- Name: column_value_492; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_492 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_492 OWNER TO postgres;

--
-- Name: column_value_493; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_493 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_493 OWNER TO postgres;

--
-- Name: column_value_494; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_494 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_494 OWNER TO postgres;

--
-- Name: column_value_495; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_495 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_495 OWNER TO postgres;

--
-- Name: column_value_496; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_496 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_496 OWNER TO postgres;

--
-- Name: column_value_497; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_497 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_497 OWNER TO postgres;

--
-- Name: column_value_498; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_498 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_498 OWNER TO postgres;

--
-- Name: column_value_499; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_499 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_499 OWNER TO postgres;

--
-- Name: column_value_5; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_5 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_5 OWNER TO postgres;

--
-- Name: column_value_50; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_50 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_50 OWNER TO postgres;

--
-- Name: column_value_500; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_500 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_500 OWNER TO postgres;

--
-- Name: column_value_501; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_501 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_501 OWNER TO postgres;

--
-- Name: column_value_502; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_502 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_502 OWNER TO postgres;

--
-- Name: column_value_503; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_503 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_503 OWNER TO postgres;

--
-- Name: column_value_504; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_504 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_504 OWNER TO postgres;

--
-- Name: column_value_505; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_505 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_505 OWNER TO postgres;

--
-- Name: column_value_506; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_506 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_506 OWNER TO postgres;

--
-- Name: column_value_507; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_507 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_507 OWNER TO postgres;

--
-- Name: column_value_508; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_508 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_508 OWNER TO postgres;

--
-- Name: column_value_509; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_509 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_509 OWNER TO postgres;

--
-- Name: column_value_51; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_51 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_51 OWNER TO postgres;

--
-- Name: column_value_510; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_510 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_510 OWNER TO postgres;

--
-- Name: column_value_511; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_511 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_511 OWNER TO postgres;

--
-- Name: column_value_512; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_512 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_512 OWNER TO postgres;

--
-- Name: column_value_513; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_513 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_513 OWNER TO postgres;

--
-- Name: column_value_514; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_514 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_514 OWNER TO postgres;

--
-- Name: column_value_515; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_515 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_515 OWNER TO postgres;

--
-- Name: column_value_516; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_516 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_516 OWNER TO postgres;

--
-- Name: column_value_517; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_517 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_517 OWNER TO postgres;

--
-- Name: column_value_518; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_518 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_518 OWNER TO postgres;

--
-- Name: column_value_519; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_519 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_519 OWNER TO postgres;

--
-- Name: column_value_52; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_52 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_52 OWNER TO postgres;

--
-- Name: column_value_520; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_520 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_520 OWNER TO postgres;

--
-- Name: column_value_521; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_521 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_521 OWNER TO postgres;

--
-- Name: column_value_522; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_522 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_522 OWNER TO postgres;

--
-- Name: column_value_523; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_523 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_523 OWNER TO postgres;

--
-- Name: column_value_524; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_524 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_524 OWNER TO postgres;

--
-- Name: column_value_525; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_525 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_525 OWNER TO postgres;

--
-- Name: column_value_526; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_526 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_526 OWNER TO postgres;

--
-- Name: column_value_527; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_527 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_527 OWNER TO postgres;

--
-- Name: column_value_528; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_528 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_528 OWNER TO postgres;

--
-- Name: column_value_529; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_529 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_529 OWNER TO postgres;

--
-- Name: column_value_53; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_53 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_53 OWNER TO postgres;

--
-- Name: column_value_530; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_530 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_530 OWNER TO postgres;

--
-- Name: column_value_531; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_531 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_531 OWNER TO postgres;

--
-- Name: column_value_532; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_532 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_532 OWNER TO postgres;

--
-- Name: column_value_533; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_533 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_533 OWNER TO postgres;

--
-- Name: column_value_534; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_534 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_534 OWNER TO postgres;

--
-- Name: column_value_535; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_535 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_535 OWNER TO postgres;

--
-- Name: column_value_536; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_536 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_536 OWNER TO postgres;

--
-- Name: column_value_537; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_537 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_537 OWNER TO postgres;

--
-- Name: column_value_538; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_538 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_538 OWNER TO postgres;

--
-- Name: column_value_539; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_539 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_539 OWNER TO postgres;

--
-- Name: column_value_54; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_54 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_54 OWNER TO postgres;

--
-- Name: column_value_540; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_540 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_540 OWNER TO postgres;

--
-- Name: column_value_541; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_541 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_541 OWNER TO postgres;

--
-- Name: column_value_542; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_542 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_542 OWNER TO postgres;

--
-- Name: column_value_543; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_543 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_543 OWNER TO postgres;

--
-- Name: column_value_544; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_544 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_544 OWNER TO postgres;

--
-- Name: column_value_545; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_545 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_545 OWNER TO postgres;

--
-- Name: column_value_546; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_546 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_546 OWNER TO postgres;

--
-- Name: column_value_547; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_547 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_547 OWNER TO postgres;

--
-- Name: column_value_548; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_548 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_548 OWNER TO postgres;

--
-- Name: column_value_549; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_549 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_549 OWNER TO postgres;

--
-- Name: column_value_55; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_55 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_55 OWNER TO postgres;

--
-- Name: column_value_550; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_550 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_550 OWNER TO postgres;

--
-- Name: column_value_551; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_551 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_551 OWNER TO postgres;

--
-- Name: column_value_552; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_552 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_552 OWNER TO postgres;

--
-- Name: column_value_553; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_553 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_553 OWNER TO postgres;

--
-- Name: column_value_554; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_554 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_554 OWNER TO postgres;

--
-- Name: column_value_555; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_555 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_555 OWNER TO postgres;

--
-- Name: column_value_556; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_556 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_556 OWNER TO postgres;

--
-- Name: column_value_557; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_557 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_557 OWNER TO postgres;

--
-- Name: column_value_558; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_558 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_558 OWNER TO postgres;

--
-- Name: column_value_559; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_559 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_559 OWNER TO postgres;

--
-- Name: column_value_56; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_56 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_56 OWNER TO postgres;

--
-- Name: column_value_560; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_560 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_560 OWNER TO postgres;

--
-- Name: column_value_561; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_561 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_561 OWNER TO postgres;

--
-- Name: column_value_562; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_562 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_562 OWNER TO postgres;

--
-- Name: column_value_563; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_563 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_563 OWNER TO postgres;

--
-- Name: column_value_564; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_564 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_564 OWNER TO postgres;

--
-- Name: column_value_565; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_565 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_565 OWNER TO postgres;

--
-- Name: column_value_566; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_566 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_566 OWNER TO postgres;

--
-- Name: column_value_567; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_567 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_567 OWNER TO postgres;

--
-- Name: column_value_568; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_568 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_568 OWNER TO postgres;

--
-- Name: column_value_569; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_569 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_569 OWNER TO postgres;

--
-- Name: column_value_57; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_57 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_57 OWNER TO postgres;

--
-- Name: column_value_570; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_570 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_570 OWNER TO postgres;

--
-- Name: column_value_571; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_571 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_571 OWNER TO postgres;

--
-- Name: column_value_572; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_572 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_572 OWNER TO postgres;

--
-- Name: column_value_573; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_573 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_573 OWNER TO postgres;

--
-- Name: column_value_574; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_574 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_574 OWNER TO postgres;

--
-- Name: column_value_575; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_575 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_575 OWNER TO postgres;

--
-- Name: column_value_576; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_576 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_576 OWNER TO postgres;

--
-- Name: column_value_577; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_577 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_577 OWNER TO postgres;

--
-- Name: column_value_578; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_578 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_578 OWNER TO postgres;

--
-- Name: column_value_579; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_579 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_579 OWNER TO postgres;

--
-- Name: column_value_58; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_58 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_58 OWNER TO postgres;

--
-- Name: column_value_580; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_580 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_580 OWNER TO postgres;

--
-- Name: column_value_581; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_581 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_581 OWNER TO postgres;

--
-- Name: column_value_582; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_582 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_582 OWNER TO postgres;

--
-- Name: column_value_583; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_583 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_583 OWNER TO postgres;

--
-- Name: column_value_584; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_584 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_584 OWNER TO postgres;

--
-- Name: column_value_585; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_585 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_585 OWNER TO postgres;

--
-- Name: column_value_586; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_586 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_586 OWNER TO postgres;

--
-- Name: column_value_587; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_587 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_587 OWNER TO postgres;

--
-- Name: column_value_588; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_588 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_588 OWNER TO postgres;

--
-- Name: column_value_589; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_589 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_589 OWNER TO postgres;

--
-- Name: column_value_59; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_59 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_59 OWNER TO postgres;

--
-- Name: column_value_590; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_590 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_590 OWNER TO postgres;

--
-- Name: column_value_591; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_591 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_591 OWNER TO postgres;

--
-- Name: column_value_592; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_592 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_592 OWNER TO postgres;

--
-- Name: column_value_593; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_593 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_593 OWNER TO postgres;

--
-- Name: column_value_594; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_594 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_594 OWNER TO postgres;

--
-- Name: column_value_6; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_6 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_6 OWNER TO postgres;

--
-- Name: column_value_60; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_60 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_60 OWNER TO postgres;

--
-- Name: column_value_61; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_61 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_61 OWNER TO postgres;

--
-- Name: column_value_62; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_62 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_62 OWNER TO postgres;

--
-- Name: column_value_63; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_63 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_63 OWNER TO postgres;

--
-- Name: column_value_64; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_64 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_64 OWNER TO postgres;

--
-- Name: column_value_65; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_65 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_65 OWNER TO postgres;

--
-- Name: column_value_66; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_66 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_66 OWNER TO postgres;

--
-- Name: column_value_67; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_67 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_67 OWNER TO postgres;

--
-- Name: column_value_68; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_68 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_68 OWNER TO postgres;

--
-- Name: column_value_69; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_69 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_69 OWNER TO postgres;

--
-- Name: column_value_7; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_7 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_7 OWNER TO postgres;

--
-- Name: column_value_70; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_70 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_70 OWNER TO postgres;

--
-- Name: column_value_71; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_71 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_71 OWNER TO postgres;

--
-- Name: column_value_72; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_72 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_72 OWNER TO postgres;

--
-- Name: column_value_73; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_73 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_73 OWNER TO postgres;

--
-- Name: column_value_74; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_74 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_74 OWNER TO postgres;

--
-- Name: column_value_75; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_75 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_75 OWNER TO postgres;

--
-- Name: column_value_76; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_76 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_76 OWNER TO postgres;

--
-- Name: column_value_77; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_77 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_77 OWNER TO postgres;

--
-- Name: column_value_78; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_78 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_78 OWNER TO postgres;

--
-- Name: column_value_79; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_79 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_79 OWNER TO postgres;

--
-- Name: column_value_8; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_8 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_8 OWNER TO postgres;

--
-- Name: column_value_80; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_80 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_80 OWNER TO postgres;

--
-- Name: column_value_81; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_81 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_81 OWNER TO postgres;

--
-- Name: column_value_82; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_82 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_82 OWNER TO postgres;

--
-- Name: column_value_83; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_83 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_83 OWNER TO postgres;

--
-- Name: column_value_84; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_84 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_84 OWNER TO postgres;

--
-- Name: column_value_85; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_85 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_85 OWNER TO postgres;

--
-- Name: column_value_86; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_86 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_86 OWNER TO postgres;

--
-- Name: column_value_87; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_87 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_87 OWNER TO postgres;

--
-- Name: column_value_88; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_88 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_88 OWNER TO postgres;

--
-- Name: column_value_89; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_89 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_89 OWNER TO postgres;

--
-- Name: column_value_9; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_9 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_9 OWNER TO postgres;

--
-- Name: column_value_90; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_90 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_90 OWNER TO postgres;

--
-- Name: column_value_91; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_91 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_91 OWNER TO postgres;

--
-- Name: column_value_92; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_92 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_92 OWNER TO postgres;

--
-- Name: column_value_93; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_93 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_93 OWNER TO postgres;

--
-- Name: column_value_94; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_94 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_94 OWNER TO postgres;

--
-- Name: column_value_95; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_95 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_95 OWNER TO postgres;

--
-- Name: column_value_96; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_96 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_96 OWNER TO postgres;

--
-- Name: column_value_97; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_97 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_97 OWNER TO postgres;

--
-- Name: column_value_98; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_98 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_98 OWNER TO postgres;

--
-- Name: column_value_99; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.column_value_99 (
    col_id integer NOT NULL,
    geo_id integer NOT NULL,
    meta_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    val_float double precision,
    val_int bigint,
    val_str text,
    val_bool boolean
);


ALTER TABLE gerrydb.column_value_99 OWNER TO postgres;

--
-- Name: ensemble; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.ensemble (
    ensemble_id integer NOT NULL,
    namespace_id integer NOT NULL,
    path text NOT NULL,
    graph_id integer NOT NULL,
    blob_hash bytea NOT NULL,
    blob_url character varying(2048) NOT NULL,
    pop_col_id integer,
    seed_plan_id integer,
    num_districts integer NOT NULL,
    num_plans integer NOT NULL,
    params jsonb,
    description text NOT NULL,
    meta_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE gerrydb.ensemble OWNER TO postgres;

--
-- Name: ensemble_ensemble_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.ensemble_ensemble_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.ensemble_ensemble_id_seq OWNER TO postgres;

--
-- Name: ensemble_ensemble_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.ensemble_ensemble_id_seq OWNED BY gerrydb.ensemble.ensemble_id;


--
-- Name: etag; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.etag (
    etag_id integer NOT NULL,
    namespace_id integer,
    "table" text NOT NULL,
    etag uuid NOT NULL
);


ALTER TABLE gerrydb.etag OWNER TO postgres;

--
-- Name: etag_etag_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.etag_etag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.etag_etag_id_seq OWNER TO postgres;

--
-- Name: etag_etag_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.etag_etag_id_seq OWNED BY gerrydb.etag.etag_id;


--
-- Name: geo_bin; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.geo_bin (
    geo_bin_id integer NOT NULL,
    geography public.geography(Geometry,4269),
    internal_point public.geography(Point,4269),
    geometry_hash bytea GENERATED ALWAYS AS (decode(md5(public.st_asbinary(geography)), 'hex'::text)) STORED
);


ALTER TABLE gerrydb.geo_bin OWNER TO postgres;

--
-- Name: geo_bin_geo_bin_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.geo_bin_geo_bin_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.geo_bin_geo_bin_id_seq OWNER TO postgres;

--
-- Name: geo_bin_geo_bin_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.geo_bin_geo_bin_id_seq OWNED BY gerrydb.geo_bin.geo_bin_id;


--
-- Name: geo_hierarchy; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.geo_hierarchy (
    parent_id integer NOT NULL,
    child_id integer NOT NULL,
    meta_id integer NOT NULL,
    CONSTRAINT geo_hierarchy_check CHECK ((parent_id <> child_id))
);


ALTER TABLE gerrydb.geo_hierarchy OWNER TO postgres;

--
-- Name: geo_import; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.geo_import (
    import_id integer NOT NULL,
    uuid uuid NOT NULL,
    namespace_id integer NOT NULL,
    meta_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by integer NOT NULL
);


ALTER TABLE gerrydb.geo_import OWNER TO postgres;

--
-- Name: geo_import_import_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.geo_import_import_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.geo_import_import_id_seq OWNER TO postgres;

--
-- Name: geo_import_import_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.geo_import_import_id_seq OWNED BY gerrydb.geo_import.import_id;


--
-- Name: geo_layer; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.geo_layer (
    layer_id integer NOT NULL,
    path text NOT NULL,
    namespace_id integer NOT NULL,
    description text,
    source_url character varying(2048),
    meta_id integer NOT NULL
);


ALTER TABLE gerrydb.geo_layer OWNER TO postgres;

--
-- Name: geo_layer_layer_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.geo_layer_layer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.geo_layer_layer_id_seq OWNER TO postgres;

--
-- Name: geo_layer_layer_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.geo_layer_layer_id_seq OWNED BY gerrydb.geo_layer.layer_id;


--
-- Name: geo_set_member; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.geo_set_member (
    set_version_id integer NOT NULL,
    geo_id integer NOT NULL
);


ALTER TABLE gerrydb.geo_set_member OWNER TO postgres;

--
-- Name: geo_set_version; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.geo_set_version (
    set_version_id integer NOT NULL,
    layer_id integer NOT NULL,
    loc_id integer NOT NULL,
    valid_from timestamp with time zone DEFAULT now() NOT NULL,
    valid_to timestamp with time zone,
    meta_id integer NOT NULL
);


ALTER TABLE gerrydb.geo_set_version OWNER TO postgres;

--
-- Name: geo_set_version_set_version_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.geo_set_version_set_version_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.geo_set_version_set_version_id_seq OWNER TO postgres;

--
-- Name: geo_set_version_set_version_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.geo_set_version_set_version_id_seq OWNED BY gerrydb.geo_set_version.set_version_id;


--
-- Name: geo_version; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.geo_version (
    import_id integer NOT NULL,
    geo_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    geo_bin_id integer
);


ALTER TABLE gerrydb.geo_version OWNER TO postgres;

--
-- Name: geography; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.geography (
    geo_id integer NOT NULL,
    path text NOT NULL,
    namespace_id integer NOT NULL,
    meta_id integer NOT NULL
);


ALTER TABLE gerrydb.geography OWNER TO postgres;

--
-- Name: geography_geo_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.geography_geo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.geography_geo_id_seq OWNER TO postgres;

--
-- Name: geography_geo_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.geography_geo_id_seq OWNED BY gerrydb.geography.geo_id;


--
-- Name: graph; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.graph (
    graph_id integer NOT NULL,
    set_version_id integer NOT NULL,
    namespace_id integer NOT NULL,
    path text NOT NULL,
    description text NOT NULL,
    meta_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    proj text
);


ALTER TABLE gerrydb.graph OWNER TO postgres;

--
-- Name: graph_edge; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.graph_edge (
    graph_id integer NOT NULL,
    geo_id_1 integer NOT NULL,
    geo_id_2 integer NOT NULL,
    weights jsonb
);


ALTER TABLE gerrydb.graph_edge OWNER TO postgres;

--
-- Name: graph_graph_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.graph_graph_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.graph_graph_id_seq OWNER TO postgres;

--
-- Name: graph_graph_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.graph_graph_id_seq OWNED BY gerrydb.graph.graph_id;


--
-- Name: graph_render; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.graph_render (
    render_id uuid NOT NULL,
    graph_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by integer NOT NULL,
    path text NOT NULL,
    status public.graphrenderstatus NOT NULL
);


ALTER TABLE gerrydb.graph_render OWNER TO postgres;

--
-- Name: locality; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.locality (
    loc_id integer NOT NULL,
    canonical_ref_id integer NOT NULL,
    parent_id integer,
    meta_id integer NOT NULL,
    name text NOT NULL,
    default_proj text,
    CONSTRAINT locality_check CHECK ((parent_id <> loc_id))
);


ALTER TABLE gerrydb.locality OWNER TO postgres;

--
-- Name: locality_loc_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.locality_loc_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.locality_loc_id_seq OWNER TO postgres;

--
-- Name: locality_loc_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.locality_loc_id_seq OWNED BY gerrydb.locality.loc_id;


--
-- Name: locality_ref; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.locality_ref (
    ref_id integer NOT NULL,
    loc_id integer,
    path text NOT NULL,
    meta_id integer NOT NULL
);


ALTER TABLE gerrydb.locality_ref OWNER TO postgres;

--
-- Name: locality_ref_ref_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.locality_ref_ref_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.locality_ref_ref_id_seq OWNER TO postgres;

--
-- Name: locality_ref_ref_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.locality_ref_ref_id_seq OWNED BY gerrydb.locality_ref.ref_id;


--
-- Name: meta; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.meta (
    meta_id integer NOT NULL,
    uuid uuid NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by integer NOT NULL
);


ALTER TABLE gerrydb.meta OWNER TO postgres;

--
-- Name: meta_meta_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.meta_meta_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.meta_meta_id_seq OWNER TO postgres;

--
-- Name: meta_meta_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.meta_meta_id_seq OWNED BY gerrydb.meta.meta_id;


--
-- Name: namespace; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.namespace (
    namespace_id integer NOT NULL,
    path text NOT NULL,
    description text NOT NULL,
    public boolean NOT NULL,
    meta_id integer NOT NULL
);


ALTER TABLE gerrydb.namespace OWNER TO postgres;

--
-- Name: namespace_limit; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.namespace_limit (
    user_id integer NOT NULL,
    max_ns_creation integer,
    curr_creation_count integer NOT NULL
);


ALTER TABLE gerrydb.namespace_limit OWNER TO postgres;

--
-- Name: namespace_namespace_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.namespace_namespace_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.namespace_namespace_id_seq OWNER TO postgres;

--
-- Name: namespace_namespace_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.namespace_namespace_id_seq OWNED BY gerrydb.namespace.namespace_id;


--
-- Name: plan; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.plan (
    plan_id integer NOT NULL,
    namespace_id integer NOT NULL,
    path text NOT NULL,
    set_version_id integer NOT NULL,
    num_districts integer NOT NULL,
    complete boolean NOT NULL,
    description text NOT NULL,
    source_url character varying(2048),
    districtr_id text,
    daves_id text,
    meta_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE gerrydb.plan OWNER TO postgres;

--
-- Name: plan_assignment; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.plan_assignment (
    plan_id integer NOT NULL,
    geo_id integer NOT NULL,
    assignment text NOT NULL
);


ALTER TABLE gerrydb.plan_assignment OWNER TO postgres;

--
-- Name: plan_limit; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.plan_limit (
    namespace_id integer NOT NULL,
    loc_id integer NOT NULL,
    layer_id integer NOT NULL,
    max_plans integer NOT NULL
);


ALTER TABLE gerrydb.plan_limit OWNER TO postgres;

--
-- Name: plan_plan_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.plan_plan_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.plan_plan_id_seq OWNER TO postgres;

--
-- Name: plan_plan_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.plan_plan_id_seq OWNED BY gerrydb.plan.plan_id;


--
-- Name: user; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb."user" (
    user_id integer NOT NULL,
    name text NOT NULL,
    email character varying(254) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE gerrydb."user" OWNER TO postgres;

--
-- Name: user_group; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.user_group (
    group_id integer NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    meta_id integer NOT NULL
);


ALTER TABLE gerrydb.user_group OWNER TO postgres;

--
-- Name: user_group_group_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.user_group_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.user_group_group_id_seq OWNER TO postgres;

--
-- Name: user_group_group_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.user_group_group_id_seq OWNED BY gerrydb.user_group.group_id;


--
-- Name: user_group_member; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.user_group_member (
    user_id integer NOT NULL,
    group_id integer NOT NULL,
    meta_id integer NOT NULL
);


ALTER TABLE gerrydb.user_group_member OWNER TO postgres;

--
-- Name: user_group_scope; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.user_group_scope (
    group_perm_id integer NOT NULL,
    group_id integer NOT NULL,
    scope public.scopetype NOT NULL,
    namespace_group public.namespacegroup,
    namespace_id integer,
    meta_id integer NOT NULL
);


ALTER TABLE gerrydb.user_group_scope OWNER TO postgres;

--
-- Name: user_group_scope_group_perm_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.user_group_scope_group_perm_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.user_group_scope_group_perm_id_seq OWNER TO postgres;

--
-- Name: user_group_scope_group_perm_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.user_group_scope_group_perm_id_seq OWNED BY gerrydb.user_group_scope.group_perm_id;


--
-- Name: user_scope; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.user_scope (
    user_perm_id integer NOT NULL,
    user_id integer NOT NULL,
    scope public.scopetype NOT NULL,
    namespace_group public.namespacegroup,
    namespace_id integer,
    meta_id integer NOT NULL
);


ALTER TABLE gerrydb.user_scope OWNER TO postgres;

--
-- Name: user_scope_user_perm_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.user_scope_user_perm_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.user_scope_user_perm_id_seq OWNER TO postgres;

--
-- Name: user_scope_user_perm_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.user_scope_user_perm_id_seq OWNED BY gerrydb.user_scope.user_perm_id;


--
-- Name: user_user_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.user_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.user_user_id_seq OWNER TO postgres;

--
-- Name: user_user_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.user_user_id_seq OWNED BY gerrydb."user".user_id;


--
-- Name: view; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.view (
    view_id integer NOT NULL,
    namespace_id integer NOT NULL,
    path text NOT NULL,
    template_id integer NOT NULL,
    template_version_id integer NOT NULL,
    loc_id integer NOT NULL,
    layer_id integer NOT NULL,
    at timestamp with time zone DEFAULT now() NOT NULL,
    proj text,
    meta_id integer NOT NULL,
    graph_id integer,
    num_geos integer NOT NULL
);


ALTER TABLE gerrydb.view OWNER TO postgres;

--
-- Name: view_geo_set_versions; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.view_geo_set_versions (
    view_id integer NOT NULL,
    set_version_id integer NOT NULL
);


ALTER TABLE gerrydb.view_geo_set_versions OWNER TO postgres;

--
-- Name: view_render; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.view_render (
    render_id uuid NOT NULL,
    view_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by integer NOT NULL,
    path text NOT NULL,
    status public.viewrenderstatus NOT NULL
);


ALTER TABLE gerrydb.view_render OWNER TO postgres;

--
-- Name: view_template; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.view_template (
    template_id integer NOT NULL,
    namespace_id integer NOT NULL,
    path text NOT NULL,
    description text NOT NULL,
    meta_id integer NOT NULL
);


ALTER TABLE gerrydb.view_template OWNER TO postgres;

--
-- Name: view_template_column_member; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.view_template_column_member (
    template_version_id integer NOT NULL,
    ref_id integer NOT NULL,
    "order" integer NOT NULL
);


ALTER TABLE gerrydb.view_template_column_member OWNER TO postgres;

--
-- Name: view_template_column_set_member; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.view_template_column_set_member (
    template_version_id integer NOT NULL,
    set_id integer NOT NULL,
    "order" integer NOT NULL
);


ALTER TABLE gerrydb.view_template_column_set_member OWNER TO postgres;

--
-- Name: view_template_template_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.view_template_template_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.view_template_template_id_seq OWNER TO postgres;

--
-- Name: view_template_template_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.view_template_template_id_seq OWNED BY gerrydb.view_template.template_id;


--
-- Name: view_template_version; Type: TABLE; Schema: gerrydb; Owner: postgres
--

CREATE TABLE gerrydb.view_template_version (
    template_version_id integer NOT NULL,
    template_id integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_to timestamp with time zone,
    meta_id integer NOT NULL
);


ALTER TABLE gerrydb.view_template_version OWNER TO postgres;

--
-- Name: view_template_version_template_version_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.view_template_version_template_version_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.view_template_version_template_version_id_seq OWNER TO postgres;

--
-- Name: view_template_version_template_version_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.view_template_version_template_version_id_seq OWNED BY gerrydb.view_template_version.template_version_id;


--
-- Name: view_view_id_seq; Type: SEQUENCE; Schema: gerrydb; Owner: postgres
--

CREATE SEQUENCE gerrydb.view_view_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE gerrydb.view_view_id_seq OWNER TO postgres;

--
-- Name: view_view_id_seq; Type: SEQUENCE OWNED BY; Schema: gerrydb; Owner: postgres
--

ALTER SEQUENCE gerrydb.view_view_id_seq OWNED BY gerrydb.view.view_id;


--
-- Name: column_value_1; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_1 FOR VALUES IN (1);


--
-- Name: column_value_10; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_10 FOR VALUES IN (10);


--
-- Name: column_value_100; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_100 FOR VALUES IN (100);


--
-- Name: column_value_101; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_101 FOR VALUES IN (101);


--
-- Name: column_value_102; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_102 FOR VALUES IN (102);


--
-- Name: column_value_103; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_103 FOR VALUES IN (103);


--
-- Name: column_value_104; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_104 FOR VALUES IN (104);


--
-- Name: column_value_105; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_105 FOR VALUES IN (105);


--
-- Name: column_value_106; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_106 FOR VALUES IN (106);


--
-- Name: column_value_107; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_107 FOR VALUES IN (107);


--
-- Name: column_value_108; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_108 FOR VALUES IN (108);


--
-- Name: column_value_109; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_109 FOR VALUES IN (109);


--
-- Name: column_value_11; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_11 FOR VALUES IN (11);


--
-- Name: column_value_110; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_110 FOR VALUES IN (110);


--
-- Name: column_value_111; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_111 FOR VALUES IN (111);


--
-- Name: column_value_112; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_112 FOR VALUES IN (112);


--
-- Name: column_value_113; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_113 FOR VALUES IN (113);


--
-- Name: column_value_114; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_114 FOR VALUES IN (114);


--
-- Name: column_value_115; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_115 FOR VALUES IN (115);


--
-- Name: column_value_116; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_116 FOR VALUES IN (116);


--
-- Name: column_value_117; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_117 FOR VALUES IN (117);


--
-- Name: column_value_118; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_118 FOR VALUES IN (118);


--
-- Name: column_value_119; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_119 FOR VALUES IN (119);


--
-- Name: column_value_12; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_12 FOR VALUES IN (12);


--
-- Name: column_value_120; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_120 FOR VALUES IN (120);


--
-- Name: column_value_121; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_121 FOR VALUES IN (121);


--
-- Name: column_value_122; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_122 FOR VALUES IN (122);


--
-- Name: column_value_123; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_123 FOR VALUES IN (123);


--
-- Name: column_value_124; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_124 FOR VALUES IN (124);


--
-- Name: column_value_125; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_125 FOR VALUES IN (125);


--
-- Name: column_value_126; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_126 FOR VALUES IN (126);


--
-- Name: column_value_127; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_127 FOR VALUES IN (127);


--
-- Name: column_value_128; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_128 FOR VALUES IN (128);


--
-- Name: column_value_129; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_129 FOR VALUES IN (129);


--
-- Name: column_value_13; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_13 FOR VALUES IN (13);


--
-- Name: column_value_130; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_130 FOR VALUES IN (130);


--
-- Name: column_value_131; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_131 FOR VALUES IN (131);


--
-- Name: column_value_132; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_132 FOR VALUES IN (132);


--
-- Name: column_value_133; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_133 FOR VALUES IN (133);


--
-- Name: column_value_134; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_134 FOR VALUES IN (134);


--
-- Name: column_value_135; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_135 FOR VALUES IN (135);


--
-- Name: column_value_136; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_136 FOR VALUES IN (136);


--
-- Name: column_value_137; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_137 FOR VALUES IN (137);


--
-- Name: column_value_138; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_138 FOR VALUES IN (138);


--
-- Name: column_value_139; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_139 FOR VALUES IN (139);


--
-- Name: column_value_14; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_14 FOR VALUES IN (14);


--
-- Name: column_value_140; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_140 FOR VALUES IN (140);


--
-- Name: column_value_141; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_141 FOR VALUES IN (141);


--
-- Name: column_value_142; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_142 FOR VALUES IN (142);


--
-- Name: column_value_143; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_143 FOR VALUES IN (143);


--
-- Name: column_value_144; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_144 FOR VALUES IN (144);


--
-- Name: column_value_145; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_145 FOR VALUES IN (145);


--
-- Name: column_value_146; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_146 FOR VALUES IN (146);


--
-- Name: column_value_147; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_147 FOR VALUES IN (147);


--
-- Name: column_value_148; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_148 FOR VALUES IN (148);


--
-- Name: column_value_149; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_149 FOR VALUES IN (149);


--
-- Name: column_value_15; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_15 FOR VALUES IN (15);


--
-- Name: column_value_150; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_150 FOR VALUES IN (150);


--
-- Name: column_value_151; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_151 FOR VALUES IN (151);


--
-- Name: column_value_152; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_152 FOR VALUES IN (152);


--
-- Name: column_value_153; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_153 FOR VALUES IN (153);


--
-- Name: column_value_154; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_154 FOR VALUES IN (154);


--
-- Name: column_value_155; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_155 FOR VALUES IN (155);


--
-- Name: column_value_156; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_156 FOR VALUES IN (156);


--
-- Name: column_value_157; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_157 FOR VALUES IN (157);


--
-- Name: column_value_158; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_158 FOR VALUES IN (158);


--
-- Name: column_value_159; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_159 FOR VALUES IN (159);


--
-- Name: column_value_16; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_16 FOR VALUES IN (16);


--
-- Name: column_value_160; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_160 FOR VALUES IN (160);


--
-- Name: column_value_161; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_161 FOR VALUES IN (161);


--
-- Name: column_value_162; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_162 FOR VALUES IN (162);


--
-- Name: column_value_163; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_163 FOR VALUES IN (163);


--
-- Name: column_value_164; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_164 FOR VALUES IN (164);


--
-- Name: column_value_165; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_165 FOR VALUES IN (165);


--
-- Name: column_value_166; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_166 FOR VALUES IN (166);


--
-- Name: column_value_167; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_167 FOR VALUES IN (167);


--
-- Name: column_value_168; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_168 FOR VALUES IN (168);


--
-- Name: column_value_169; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_169 FOR VALUES IN (169);


--
-- Name: column_value_17; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_17 FOR VALUES IN (17);


--
-- Name: column_value_170; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_170 FOR VALUES IN (170);


--
-- Name: column_value_171; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_171 FOR VALUES IN (171);


--
-- Name: column_value_172; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_172 FOR VALUES IN (172);


--
-- Name: column_value_173; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_173 FOR VALUES IN (173);


--
-- Name: column_value_174; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_174 FOR VALUES IN (174);


--
-- Name: column_value_175; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_175 FOR VALUES IN (175);


--
-- Name: column_value_176; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_176 FOR VALUES IN (176);


--
-- Name: column_value_177; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_177 FOR VALUES IN (177);


--
-- Name: column_value_178; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_178 FOR VALUES IN (178);


--
-- Name: column_value_179; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_179 FOR VALUES IN (179);


--
-- Name: column_value_18; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_18 FOR VALUES IN (18);


--
-- Name: column_value_180; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_180 FOR VALUES IN (180);


--
-- Name: column_value_181; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_181 FOR VALUES IN (181);


--
-- Name: column_value_182; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_182 FOR VALUES IN (182);


--
-- Name: column_value_183; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_183 FOR VALUES IN (183);


--
-- Name: column_value_184; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_184 FOR VALUES IN (184);


--
-- Name: column_value_185; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_185 FOR VALUES IN (185);


--
-- Name: column_value_186; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_186 FOR VALUES IN (186);


--
-- Name: column_value_187; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_187 FOR VALUES IN (187);


--
-- Name: column_value_188; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_188 FOR VALUES IN (188);


--
-- Name: column_value_189; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_189 FOR VALUES IN (189);


--
-- Name: column_value_19; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_19 FOR VALUES IN (19);


--
-- Name: column_value_190; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_190 FOR VALUES IN (190);


--
-- Name: column_value_191; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_191 FOR VALUES IN (191);


--
-- Name: column_value_192; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_192 FOR VALUES IN (192);


--
-- Name: column_value_193; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_193 FOR VALUES IN (193);


--
-- Name: column_value_194; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_194 FOR VALUES IN (194);


--
-- Name: column_value_195; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_195 FOR VALUES IN (195);


--
-- Name: column_value_196; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_196 FOR VALUES IN (196);


--
-- Name: column_value_197; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_197 FOR VALUES IN (197);


--
-- Name: column_value_198; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_198 FOR VALUES IN (198);


--
-- Name: column_value_199; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_199 FOR VALUES IN (199);


--
-- Name: column_value_2; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_2 FOR VALUES IN (2);


--
-- Name: column_value_20; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_20 FOR VALUES IN (20);


--
-- Name: column_value_200; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_200 FOR VALUES IN (200);


--
-- Name: column_value_201; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_201 FOR VALUES IN (201);


--
-- Name: column_value_202; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_202 FOR VALUES IN (202);


--
-- Name: column_value_203; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_203 FOR VALUES IN (203);


--
-- Name: column_value_204; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_204 FOR VALUES IN (204);


--
-- Name: column_value_205; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_205 FOR VALUES IN (205);


--
-- Name: column_value_206; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_206 FOR VALUES IN (206);


--
-- Name: column_value_207; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_207 FOR VALUES IN (207);


--
-- Name: column_value_208; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_208 FOR VALUES IN (208);


--
-- Name: column_value_209; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_209 FOR VALUES IN (209);


--
-- Name: column_value_21; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_21 FOR VALUES IN (21);


--
-- Name: column_value_210; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_210 FOR VALUES IN (210);


--
-- Name: column_value_211; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_211 FOR VALUES IN (211);


--
-- Name: column_value_212; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_212 FOR VALUES IN (212);


--
-- Name: column_value_213; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_213 FOR VALUES IN (213);


--
-- Name: column_value_214; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_214 FOR VALUES IN (214);


--
-- Name: column_value_215; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_215 FOR VALUES IN (215);


--
-- Name: column_value_216; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_216 FOR VALUES IN (216);


--
-- Name: column_value_217; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_217 FOR VALUES IN (217);


--
-- Name: column_value_218; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_218 FOR VALUES IN (218);


--
-- Name: column_value_219; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_219 FOR VALUES IN (219);


--
-- Name: column_value_22; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_22 FOR VALUES IN (22);


--
-- Name: column_value_220; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_220 FOR VALUES IN (220);


--
-- Name: column_value_221; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_221 FOR VALUES IN (221);


--
-- Name: column_value_222; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_222 FOR VALUES IN (222);


--
-- Name: column_value_223; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_223 FOR VALUES IN (223);


--
-- Name: column_value_224; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_224 FOR VALUES IN (224);


--
-- Name: column_value_225; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_225 FOR VALUES IN (225);


--
-- Name: column_value_226; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_226 FOR VALUES IN (226);


--
-- Name: column_value_227; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_227 FOR VALUES IN (227);


--
-- Name: column_value_228; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_228 FOR VALUES IN (228);


--
-- Name: column_value_229; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_229 FOR VALUES IN (229);


--
-- Name: column_value_23; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_23 FOR VALUES IN (23);


--
-- Name: column_value_230; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_230 FOR VALUES IN (230);


--
-- Name: column_value_231; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_231 FOR VALUES IN (231);


--
-- Name: column_value_232; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_232 FOR VALUES IN (232);


--
-- Name: column_value_233; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_233 FOR VALUES IN (233);


--
-- Name: column_value_234; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_234 FOR VALUES IN (234);


--
-- Name: column_value_235; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_235 FOR VALUES IN (235);


--
-- Name: column_value_236; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_236 FOR VALUES IN (236);


--
-- Name: column_value_237; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_237 FOR VALUES IN (237);


--
-- Name: column_value_238; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_238 FOR VALUES IN (238);


--
-- Name: column_value_239; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_239 FOR VALUES IN (239);


--
-- Name: column_value_24; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_24 FOR VALUES IN (24);


--
-- Name: column_value_240; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_240 FOR VALUES IN (240);


--
-- Name: column_value_241; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_241 FOR VALUES IN (241);


--
-- Name: column_value_242; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_242 FOR VALUES IN (242);


--
-- Name: column_value_243; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_243 FOR VALUES IN (243);


--
-- Name: column_value_244; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_244 FOR VALUES IN (244);


--
-- Name: column_value_245; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_245 FOR VALUES IN (245);


--
-- Name: column_value_246; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_246 FOR VALUES IN (246);


--
-- Name: column_value_247; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_247 FOR VALUES IN (247);


--
-- Name: column_value_248; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_248 FOR VALUES IN (248);


--
-- Name: column_value_249; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_249 FOR VALUES IN (249);


--
-- Name: column_value_25; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_25 FOR VALUES IN (25);


--
-- Name: column_value_250; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_250 FOR VALUES IN (250);


--
-- Name: column_value_251; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_251 FOR VALUES IN (251);


--
-- Name: column_value_252; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_252 FOR VALUES IN (252);


--
-- Name: column_value_253; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_253 FOR VALUES IN (253);


--
-- Name: column_value_254; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_254 FOR VALUES IN (254);


--
-- Name: column_value_255; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_255 FOR VALUES IN (255);


--
-- Name: column_value_256; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_256 FOR VALUES IN (256);


--
-- Name: column_value_257; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_257 FOR VALUES IN (257);


--
-- Name: column_value_258; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_258 FOR VALUES IN (258);


--
-- Name: column_value_259; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_259 FOR VALUES IN (259);


--
-- Name: column_value_26; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_26 FOR VALUES IN (26);


--
-- Name: column_value_260; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_260 FOR VALUES IN (260);


--
-- Name: column_value_261; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_261 FOR VALUES IN (261);


--
-- Name: column_value_262; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_262 FOR VALUES IN (262);


--
-- Name: column_value_263; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_263 FOR VALUES IN (263);


--
-- Name: column_value_264; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_264 FOR VALUES IN (264);


--
-- Name: column_value_265; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_265 FOR VALUES IN (265);


--
-- Name: column_value_266; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_266 FOR VALUES IN (266);


--
-- Name: column_value_267; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_267 FOR VALUES IN (267);


--
-- Name: column_value_268; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_268 FOR VALUES IN (268);


--
-- Name: column_value_269; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_269 FOR VALUES IN (269);


--
-- Name: column_value_27; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_27 FOR VALUES IN (27);


--
-- Name: column_value_270; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_270 FOR VALUES IN (270);


--
-- Name: column_value_271; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_271 FOR VALUES IN (271);


--
-- Name: column_value_272; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_272 FOR VALUES IN (272);


--
-- Name: column_value_273; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_273 FOR VALUES IN (273);


--
-- Name: column_value_274; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_274 FOR VALUES IN (274);


--
-- Name: column_value_275; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_275 FOR VALUES IN (275);


--
-- Name: column_value_276; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_276 FOR VALUES IN (276);


--
-- Name: column_value_277; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_277 FOR VALUES IN (277);


--
-- Name: column_value_278; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_278 FOR VALUES IN (278);


--
-- Name: column_value_279; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_279 FOR VALUES IN (279);


--
-- Name: column_value_28; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_28 FOR VALUES IN (28);


--
-- Name: column_value_280; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_280 FOR VALUES IN (280);


--
-- Name: column_value_281; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_281 FOR VALUES IN (281);


--
-- Name: column_value_282; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_282 FOR VALUES IN (282);


--
-- Name: column_value_283; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_283 FOR VALUES IN (283);


--
-- Name: column_value_284; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_284 FOR VALUES IN (284);


--
-- Name: column_value_285; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_285 FOR VALUES IN (285);


--
-- Name: column_value_286; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_286 FOR VALUES IN (286);


--
-- Name: column_value_287; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_287 FOR VALUES IN (287);


--
-- Name: column_value_288; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_288 FOR VALUES IN (288);


--
-- Name: column_value_289; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_289 FOR VALUES IN (289);


--
-- Name: column_value_29; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_29 FOR VALUES IN (29);


--
-- Name: column_value_290; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_290 FOR VALUES IN (290);


--
-- Name: column_value_291; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_291 FOR VALUES IN (291);


--
-- Name: column_value_292; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_292 FOR VALUES IN (292);


--
-- Name: column_value_293; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_293 FOR VALUES IN (293);


--
-- Name: column_value_294; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_294 FOR VALUES IN (294);


--
-- Name: column_value_295; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_295 FOR VALUES IN (295);


--
-- Name: column_value_296; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_296 FOR VALUES IN (296);


--
-- Name: column_value_297; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_297 FOR VALUES IN (297);


--
-- Name: column_value_298; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_298 FOR VALUES IN (298);


--
-- Name: column_value_299; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_299 FOR VALUES IN (299);


--
-- Name: column_value_3; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_3 FOR VALUES IN (3);


--
-- Name: column_value_30; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_30 FOR VALUES IN (30);


--
-- Name: column_value_300; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_300 FOR VALUES IN (300);


--
-- Name: column_value_301; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_301 FOR VALUES IN (301);


--
-- Name: column_value_302; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_302 FOR VALUES IN (302);


--
-- Name: column_value_303; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_303 FOR VALUES IN (303);


--
-- Name: column_value_304; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_304 FOR VALUES IN (304);


--
-- Name: column_value_305; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_305 FOR VALUES IN (305);


--
-- Name: column_value_306; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_306 FOR VALUES IN (306);


--
-- Name: column_value_307; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_307 FOR VALUES IN (307);


--
-- Name: column_value_308; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_308 FOR VALUES IN (308);


--
-- Name: column_value_309; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_309 FOR VALUES IN (309);


--
-- Name: column_value_31; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_31 FOR VALUES IN (31);


--
-- Name: column_value_310; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_310 FOR VALUES IN (310);


--
-- Name: column_value_311; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_311 FOR VALUES IN (311);


--
-- Name: column_value_312; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_312 FOR VALUES IN (312);


--
-- Name: column_value_313; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_313 FOR VALUES IN (313);


--
-- Name: column_value_314; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_314 FOR VALUES IN (314);


--
-- Name: column_value_315; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_315 FOR VALUES IN (315);


--
-- Name: column_value_316; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_316 FOR VALUES IN (316);


--
-- Name: column_value_317; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_317 FOR VALUES IN (317);


--
-- Name: column_value_318; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_318 FOR VALUES IN (318);


--
-- Name: column_value_319; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_319 FOR VALUES IN (319);


--
-- Name: column_value_32; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_32 FOR VALUES IN (32);


--
-- Name: column_value_320; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_320 FOR VALUES IN (320);


--
-- Name: column_value_321; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_321 FOR VALUES IN (321);


--
-- Name: column_value_322; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_322 FOR VALUES IN (322);


--
-- Name: column_value_323; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_323 FOR VALUES IN (323);


--
-- Name: column_value_324; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_324 FOR VALUES IN (324);


--
-- Name: column_value_325; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_325 FOR VALUES IN (325);


--
-- Name: column_value_326; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_326 FOR VALUES IN (326);


--
-- Name: column_value_327; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_327 FOR VALUES IN (327);


--
-- Name: column_value_328; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_328 FOR VALUES IN (328);


--
-- Name: column_value_329; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_329 FOR VALUES IN (329);


--
-- Name: column_value_33; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_33 FOR VALUES IN (33);


--
-- Name: column_value_330; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_330 FOR VALUES IN (330);


--
-- Name: column_value_331; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_331 FOR VALUES IN (331);


--
-- Name: column_value_332; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_332 FOR VALUES IN (332);


--
-- Name: column_value_333; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_333 FOR VALUES IN (333);


--
-- Name: column_value_334; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_334 FOR VALUES IN (334);


--
-- Name: column_value_335; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_335 FOR VALUES IN (335);


--
-- Name: column_value_336; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_336 FOR VALUES IN (336);


--
-- Name: column_value_337; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_337 FOR VALUES IN (337);


--
-- Name: column_value_338; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_338 FOR VALUES IN (338);


--
-- Name: column_value_339; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_339 FOR VALUES IN (339);


--
-- Name: column_value_34; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_34 FOR VALUES IN (34);


--
-- Name: column_value_340; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_340 FOR VALUES IN (340);


--
-- Name: column_value_341; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_341 FOR VALUES IN (341);


--
-- Name: column_value_342; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_342 FOR VALUES IN (342);


--
-- Name: column_value_343; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_343 FOR VALUES IN (343);


--
-- Name: column_value_344; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_344 FOR VALUES IN (344);


--
-- Name: column_value_345; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_345 FOR VALUES IN (345);


--
-- Name: column_value_346; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_346 FOR VALUES IN (346);


--
-- Name: column_value_347; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_347 FOR VALUES IN (347);


--
-- Name: column_value_348; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_348 FOR VALUES IN (348);


--
-- Name: column_value_349; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_349 FOR VALUES IN (349);


--
-- Name: column_value_35; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_35 FOR VALUES IN (35);


--
-- Name: column_value_350; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_350 FOR VALUES IN (350);


--
-- Name: column_value_351; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_351 FOR VALUES IN (351);


--
-- Name: column_value_352; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_352 FOR VALUES IN (352);


--
-- Name: column_value_353; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_353 FOR VALUES IN (353);


--
-- Name: column_value_354; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_354 FOR VALUES IN (354);


--
-- Name: column_value_355; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_355 FOR VALUES IN (355);


--
-- Name: column_value_356; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_356 FOR VALUES IN (356);


--
-- Name: column_value_357; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_357 FOR VALUES IN (357);


--
-- Name: column_value_358; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_358 FOR VALUES IN (358);


--
-- Name: column_value_359; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_359 FOR VALUES IN (359);


--
-- Name: column_value_36; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_36 FOR VALUES IN (36);


--
-- Name: column_value_360; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_360 FOR VALUES IN (360);


--
-- Name: column_value_361; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_361 FOR VALUES IN (361);


--
-- Name: column_value_362; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_362 FOR VALUES IN (362);


--
-- Name: column_value_363; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_363 FOR VALUES IN (363);


--
-- Name: column_value_364; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_364 FOR VALUES IN (364);


--
-- Name: column_value_365; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_365 FOR VALUES IN (365);


--
-- Name: column_value_366; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_366 FOR VALUES IN (366);


--
-- Name: column_value_367; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_367 FOR VALUES IN (367);


--
-- Name: column_value_368; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_368 FOR VALUES IN (368);


--
-- Name: column_value_369; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_369 FOR VALUES IN (369);


--
-- Name: column_value_37; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_37 FOR VALUES IN (37);


--
-- Name: column_value_370; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_370 FOR VALUES IN (370);


--
-- Name: column_value_371; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_371 FOR VALUES IN (371);


--
-- Name: column_value_372; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_372 FOR VALUES IN (372);


--
-- Name: column_value_373; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_373 FOR VALUES IN (373);


--
-- Name: column_value_374; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_374 FOR VALUES IN (374);


--
-- Name: column_value_375; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_375 FOR VALUES IN (375);


--
-- Name: column_value_376; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_376 FOR VALUES IN (376);


--
-- Name: column_value_377; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_377 FOR VALUES IN (377);


--
-- Name: column_value_378; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_378 FOR VALUES IN (378);


--
-- Name: column_value_379; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_379 FOR VALUES IN (379);


--
-- Name: column_value_38; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_38 FOR VALUES IN (38);


--
-- Name: column_value_380; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_380 FOR VALUES IN (380);


--
-- Name: column_value_381; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_381 FOR VALUES IN (381);


--
-- Name: column_value_382; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_382 FOR VALUES IN (382);


--
-- Name: column_value_383; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_383 FOR VALUES IN (383);


--
-- Name: column_value_384; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_384 FOR VALUES IN (384);


--
-- Name: column_value_385; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_385 FOR VALUES IN (385);


--
-- Name: column_value_386; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_386 FOR VALUES IN (386);


--
-- Name: column_value_387; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_387 FOR VALUES IN (387);


--
-- Name: column_value_388; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_388 FOR VALUES IN (388);


--
-- Name: column_value_389; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_389 FOR VALUES IN (389);


--
-- Name: column_value_39; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_39 FOR VALUES IN (39);


--
-- Name: column_value_390; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_390 FOR VALUES IN (390);


--
-- Name: column_value_391; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_391 FOR VALUES IN (391);


--
-- Name: column_value_392; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_392 FOR VALUES IN (392);


--
-- Name: column_value_393; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_393 FOR VALUES IN (393);


--
-- Name: column_value_394; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_394 FOR VALUES IN (394);


--
-- Name: column_value_395; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_395 FOR VALUES IN (395);


--
-- Name: column_value_396; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_396 FOR VALUES IN (396);


--
-- Name: column_value_397; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_397 FOR VALUES IN (397);


--
-- Name: column_value_398; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_398 FOR VALUES IN (398);


--
-- Name: column_value_399; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_399 FOR VALUES IN (399);


--
-- Name: column_value_4; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_4 FOR VALUES IN (4);


--
-- Name: column_value_40; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_40 FOR VALUES IN (40);


--
-- Name: column_value_400; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_400 FOR VALUES IN (400);


--
-- Name: column_value_401; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_401 FOR VALUES IN (401);


--
-- Name: column_value_402; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_402 FOR VALUES IN (402);


--
-- Name: column_value_403; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_403 FOR VALUES IN (403);


--
-- Name: column_value_404; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_404 FOR VALUES IN (404);


--
-- Name: column_value_405; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_405 FOR VALUES IN (405);


--
-- Name: column_value_406; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_406 FOR VALUES IN (406);


--
-- Name: column_value_407; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_407 FOR VALUES IN (407);


--
-- Name: column_value_408; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_408 FOR VALUES IN (408);


--
-- Name: column_value_409; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_409 FOR VALUES IN (409);


--
-- Name: column_value_41; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_41 FOR VALUES IN (41);


--
-- Name: column_value_410; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_410 FOR VALUES IN (410);


--
-- Name: column_value_411; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_411 FOR VALUES IN (411);


--
-- Name: column_value_412; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_412 FOR VALUES IN (412);


--
-- Name: column_value_413; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_413 FOR VALUES IN (413);


--
-- Name: column_value_414; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_414 FOR VALUES IN (414);


--
-- Name: column_value_415; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_415 FOR VALUES IN (415);


--
-- Name: column_value_416; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_416 FOR VALUES IN (416);


--
-- Name: column_value_417; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_417 FOR VALUES IN (417);


--
-- Name: column_value_418; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_418 FOR VALUES IN (418);


--
-- Name: column_value_419; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_419 FOR VALUES IN (419);


--
-- Name: column_value_42; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_42 FOR VALUES IN (42);


--
-- Name: column_value_420; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_420 FOR VALUES IN (420);


--
-- Name: column_value_421; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_421 FOR VALUES IN (421);


--
-- Name: column_value_422; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_422 FOR VALUES IN (422);


--
-- Name: column_value_423; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_423 FOR VALUES IN (423);


--
-- Name: column_value_424; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_424 FOR VALUES IN (424);


--
-- Name: column_value_425; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_425 FOR VALUES IN (425);


--
-- Name: column_value_426; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_426 FOR VALUES IN (426);


--
-- Name: column_value_427; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_427 FOR VALUES IN (427);


--
-- Name: column_value_428; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_428 FOR VALUES IN (428);


--
-- Name: column_value_429; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_429 FOR VALUES IN (429);


--
-- Name: column_value_43; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_43 FOR VALUES IN (43);


--
-- Name: column_value_430; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_430 FOR VALUES IN (430);


--
-- Name: column_value_431; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_431 FOR VALUES IN (431);


--
-- Name: column_value_432; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_432 FOR VALUES IN (432);


--
-- Name: column_value_433; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_433 FOR VALUES IN (433);


--
-- Name: column_value_434; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_434 FOR VALUES IN (434);


--
-- Name: column_value_435; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_435 FOR VALUES IN (435);


--
-- Name: column_value_436; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_436 FOR VALUES IN (436);


--
-- Name: column_value_437; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_437 FOR VALUES IN (437);


--
-- Name: column_value_438; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_438 FOR VALUES IN (438);


--
-- Name: column_value_439; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_439 FOR VALUES IN (439);


--
-- Name: column_value_44; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_44 FOR VALUES IN (44);


--
-- Name: column_value_440; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_440 FOR VALUES IN (440);


--
-- Name: column_value_441; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_441 FOR VALUES IN (441);


--
-- Name: column_value_442; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_442 FOR VALUES IN (442);


--
-- Name: column_value_443; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_443 FOR VALUES IN (443);


--
-- Name: column_value_444; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_444 FOR VALUES IN (444);


--
-- Name: column_value_445; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_445 FOR VALUES IN (445);


--
-- Name: column_value_446; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_446 FOR VALUES IN (446);


--
-- Name: column_value_447; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_447 FOR VALUES IN (447);


--
-- Name: column_value_448; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_448 FOR VALUES IN (448);


--
-- Name: column_value_449; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_449 FOR VALUES IN (449);


--
-- Name: column_value_45; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_45 FOR VALUES IN (45);


--
-- Name: column_value_450; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_450 FOR VALUES IN (450);


--
-- Name: column_value_451; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_451 FOR VALUES IN (451);


--
-- Name: column_value_452; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_452 FOR VALUES IN (452);


--
-- Name: column_value_453; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_453 FOR VALUES IN (453);


--
-- Name: column_value_454; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_454 FOR VALUES IN (454);


--
-- Name: column_value_455; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_455 FOR VALUES IN (455);


--
-- Name: column_value_456; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_456 FOR VALUES IN (456);


--
-- Name: column_value_457; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_457 FOR VALUES IN (457);


--
-- Name: column_value_458; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_458 FOR VALUES IN (458);


--
-- Name: column_value_459; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_459 FOR VALUES IN (459);


--
-- Name: column_value_46; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_46 FOR VALUES IN (46);


--
-- Name: column_value_460; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_460 FOR VALUES IN (460);


--
-- Name: column_value_461; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_461 FOR VALUES IN (461);


--
-- Name: column_value_462; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_462 FOR VALUES IN (462);


--
-- Name: column_value_463; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_463 FOR VALUES IN (463);


--
-- Name: column_value_464; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_464 FOR VALUES IN (464);


--
-- Name: column_value_465; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_465 FOR VALUES IN (465);


--
-- Name: column_value_466; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_466 FOR VALUES IN (466);


--
-- Name: column_value_467; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_467 FOR VALUES IN (467);


--
-- Name: column_value_468; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_468 FOR VALUES IN (468);


--
-- Name: column_value_469; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_469 FOR VALUES IN (469);


--
-- Name: column_value_47; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_47 FOR VALUES IN (47);


--
-- Name: column_value_470; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_470 FOR VALUES IN (470);


--
-- Name: column_value_471; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_471 FOR VALUES IN (471);


--
-- Name: column_value_472; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_472 FOR VALUES IN (472);


--
-- Name: column_value_473; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_473 FOR VALUES IN (473);


--
-- Name: column_value_474; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_474 FOR VALUES IN (474);


--
-- Name: column_value_475; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_475 FOR VALUES IN (475);


--
-- Name: column_value_476; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_476 FOR VALUES IN (476);


--
-- Name: column_value_477; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_477 FOR VALUES IN (477);


--
-- Name: column_value_478; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_478 FOR VALUES IN (478);


--
-- Name: column_value_479; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_479 FOR VALUES IN (479);


--
-- Name: column_value_48; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_48 FOR VALUES IN (48);


--
-- Name: column_value_480; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_480 FOR VALUES IN (480);


--
-- Name: column_value_481; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_481 FOR VALUES IN (481);


--
-- Name: column_value_482; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_482 FOR VALUES IN (482);


--
-- Name: column_value_483; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_483 FOR VALUES IN (483);


--
-- Name: column_value_484; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_484 FOR VALUES IN (484);


--
-- Name: column_value_485; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_485 FOR VALUES IN (485);


--
-- Name: column_value_486; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_486 FOR VALUES IN (486);


--
-- Name: column_value_487; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_487 FOR VALUES IN (487);


--
-- Name: column_value_488; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_488 FOR VALUES IN (488);


--
-- Name: column_value_489; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_489 FOR VALUES IN (489);


--
-- Name: column_value_49; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_49 FOR VALUES IN (49);


--
-- Name: column_value_490; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_490 FOR VALUES IN (490);


--
-- Name: column_value_491; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_491 FOR VALUES IN (491);


--
-- Name: column_value_492; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_492 FOR VALUES IN (492);


--
-- Name: column_value_493; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_493 FOR VALUES IN (493);


--
-- Name: column_value_494; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_494 FOR VALUES IN (494);


--
-- Name: column_value_495; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_495 FOR VALUES IN (495);


--
-- Name: column_value_496; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_496 FOR VALUES IN (496);


--
-- Name: column_value_497; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_497 FOR VALUES IN (497);


--
-- Name: column_value_498; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_498 FOR VALUES IN (498);


--
-- Name: column_value_499; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_499 FOR VALUES IN (499);


--
-- Name: column_value_5; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_5 FOR VALUES IN (5);


--
-- Name: column_value_50; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_50 FOR VALUES IN (50);


--
-- Name: column_value_500; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_500 FOR VALUES IN (500);


--
-- Name: column_value_501; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_501 FOR VALUES IN (501);


--
-- Name: column_value_502; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_502 FOR VALUES IN (502);


--
-- Name: column_value_503; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_503 FOR VALUES IN (503);


--
-- Name: column_value_504; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_504 FOR VALUES IN (504);


--
-- Name: column_value_505; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_505 FOR VALUES IN (505);


--
-- Name: column_value_506; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_506 FOR VALUES IN (506);


--
-- Name: column_value_507; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_507 FOR VALUES IN (507);


--
-- Name: column_value_508; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_508 FOR VALUES IN (508);


--
-- Name: column_value_509; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_509 FOR VALUES IN (509);


--
-- Name: column_value_51; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_51 FOR VALUES IN (51);


--
-- Name: column_value_510; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_510 FOR VALUES IN (510);


--
-- Name: column_value_511; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_511 FOR VALUES IN (511);


--
-- Name: column_value_512; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_512 FOR VALUES IN (512);


--
-- Name: column_value_513; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_513 FOR VALUES IN (513);


--
-- Name: column_value_514; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_514 FOR VALUES IN (514);


--
-- Name: column_value_515; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_515 FOR VALUES IN (515);


--
-- Name: column_value_516; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_516 FOR VALUES IN (516);


--
-- Name: column_value_517; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_517 FOR VALUES IN (517);


--
-- Name: column_value_518; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_518 FOR VALUES IN (518);


--
-- Name: column_value_519; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_519 FOR VALUES IN (519);


--
-- Name: column_value_52; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_52 FOR VALUES IN (52);


--
-- Name: column_value_520; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_520 FOR VALUES IN (520);


--
-- Name: column_value_521; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_521 FOR VALUES IN (521);


--
-- Name: column_value_522; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_522 FOR VALUES IN (522);


--
-- Name: column_value_523; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_523 FOR VALUES IN (523);


--
-- Name: column_value_524; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_524 FOR VALUES IN (524);


--
-- Name: column_value_525; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_525 FOR VALUES IN (525);


--
-- Name: column_value_526; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_526 FOR VALUES IN (526);


--
-- Name: column_value_527; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_527 FOR VALUES IN (527);


--
-- Name: column_value_528; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_528 FOR VALUES IN (528);


--
-- Name: column_value_529; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_529 FOR VALUES IN (529);


--
-- Name: column_value_53; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_53 FOR VALUES IN (53);


--
-- Name: column_value_530; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_530 FOR VALUES IN (530);


--
-- Name: column_value_531; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_531 FOR VALUES IN (531);


--
-- Name: column_value_532; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_532 FOR VALUES IN (532);


--
-- Name: column_value_533; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_533 FOR VALUES IN (533);


--
-- Name: column_value_534; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_534 FOR VALUES IN (534);


--
-- Name: column_value_535; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_535 FOR VALUES IN (535);


--
-- Name: column_value_536; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_536 FOR VALUES IN (536);


--
-- Name: column_value_537; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_537 FOR VALUES IN (537);


--
-- Name: column_value_538; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_538 FOR VALUES IN (538);


--
-- Name: column_value_539; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_539 FOR VALUES IN (539);


--
-- Name: column_value_54; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_54 FOR VALUES IN (54);


--
-- Name: column_value_540; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_540 FOR VALUES IN (540);


--
-- Name: column_value_541; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_541 FOR VALUES IN (541);


--
-- Name: column_value_542; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_542 FOR VALUES IN (542);


--
-- Name: column_value_543; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_543 FOR VALUES IN (543);


--
-- Name: column_value_544; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_544 FOR VALUES IN (544);


--
-- Name: column_value_545; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_545 FOR VALUES IN (545);


--
-- Name: column_value_546; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_546 FOR VALUES IN (546);


--
-- Name: column_value_547; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_547 FOR VALUES IN (547);


--
-- Name: column_value_548; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_548 FOR VALUES IN (548);


--
-- Name: column_value_549; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_549 FOR VALUES IN (549);


--
-- Name: column_value_55; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_55 FOR VALUES IN (55);


--
-- Name: column_value_550; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_550 FOR VALUES IN (550);


--
-- Name: column_value_551; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_551 FOR VALUES IN (551);


--
-- Name: column_value_552; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_552 FOR VALUES IN (552);


--
-- Name: column_value_553; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_553 FOR VALUES IN (553);


--
-- Name: column_value_554; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_554 FOR VALUES IN (554);


--
-- Name: column_value_555; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_555 FOR VALUES IN (555);


--
-- Name: column_value_556; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_556 FOR VALUES IN (556);


--
-- Name: column_value_557; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_557 FOR VALUES IN (557);


--
-- Name: column_value_558; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_558 FOR VALUES IN (558);


--
-- Name: column_value_559; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_559 FOR VALUES IN (559);


--
-- Name: column_value_56; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_56 FOR VALUES IN (56);


--
-- Name: column_value_560; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_560 FOR VALUES IN (560);


--
-- Name: column_value_561; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_561 FOR VALUES IN (561);


--
-- Name: column_value_562; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_562 FOR VALUES IN (562);


--
-- Name: column_value_563; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_563 FOR VALUES IN (563);


--
-- Name: column_value_564; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_564 FOR VALUES IN (564);


--
-- Name: column_value_565; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_565 FOR VALUES IN (565);


--
-- Name: column_value_566; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_566 FOR VALUES IN (566);


--
-- Name: column_value_567; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_567 FOR VALUES IN (567);


--
-- Name: column_value_568; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_568 FOR VALUES IN (568);


--
-- Name: column_value_569; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_569 FOR VALUES IN (569);


--
-- Name: column_value_57; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_57 FOR VALUES IN (57);


--
-- Name: column_value_570; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_570 FOR VALUES IN (570);


--
-- Name: column_value_571; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_571 FOR VALUES IN (571);


--
-- Name: column_value_572; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_572 FOR VALUES IN (572);


--
-- Name: column_value_573; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_573 FOR VALUES IN (573);


--
-- Name: column_value_574; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_574 FOR VALUES IN (574);


--
-- Name: column_value_575; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_575 FOR VALUES IN (575);


--
-- Name: column_value_576; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_576 FOR VALUES IN (576);


--
-- Name: column_value_577; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_577 FOR VALUES IN (577);


--
-- Name: column_value_578; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_578 FOR VALUES IN (578);


--
-- Name: column_value_579; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_579 FOR VALUES IN (579);


--
-- Name: column_value_58; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_58 FOR VALUES IN (58);


--
-- Name: column_value_580; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_580 FOR VALUES IN (580);


--
-- Name: column_value_581; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_581 FOR VALUES IN (581);


--
-- Name: column_value_582; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_582 FOR VALUES IN (582);


--
-- Name: column_value_583; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_583 FOR VALUES IN (583);


--
-- Name: column_value_584; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_584 FOR VALUES IN (584);


--
-- Name: column_value_585; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_585 FOR VALUES IN (585);


--
-- Name: column_value_586; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_586 FOR VALUES IN (586);


--
-- Name: column_value_587; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_587 FOR VALUES IN (587);


--
-- Name: column_value_588; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_588 FOR VALUES IN (588);


--
-- Name: column_value_589; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_589 FOR VALUES IN (589);


--
-- Name: column_value_59; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_59 FOR VALUES IN (59);


--
-- Name: column_value_590; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_590 FOR VALUES IN (590);


--
-- Name: column_value_591; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_591 FOR VALUES IN (591);


--
-- Name: column_value_592; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_592 FOR VALUES IN (592);


--
-- Name: column_value_593; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_593 FOR VALUES IN (593);


--
-- Name: column_value_594; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_594 FOR VALUES IN (594);


--
-- Name: column_value_6; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_6 FOR VALUES IN (6);


--
-- Name: column_value_60; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_60 FOR VALUES IN (60);


--
-- Name: column_value_61; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_61 FOR VALUES IN (61);


--
-- Name: column_value_62; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_62 FOR VALUES IN (62);


--
-- Name: column_value_63; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_63 FOR VALUES IN (63);


--
-- Name: column_value_64; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_64 FOR VALUES IN (64);


--
-- Name: column_value_65; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_65 FOR VALUES IN (65);


--
-- Name: column_value_66; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_66 FOR VALUES IN (66);


--
-- Name: column_value_67; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_67 FOR VALUES IN (67);


--
-- Name: column_value_68; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_68 FOR VALUES IN (68);


--
-- Name: column_value_69; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_69 FOR VALUES IN (69);


--
-- Name: column_value_7; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_7 FOR VALUES IN (7);


--
-- Name: column_value_70; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_70 FOR VALUES IN (70);


--
-- Name: column_value_71; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_71 FOR VALUES IN (71);


--
-- Name: column_value_72; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_72 FOR VALUES IN (72);


--
-- Name: column_value_73; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_73 FOR VALUES IN (73);


--
-- Name: column_value_74; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_74 FOR VALUES IN (74);


--
-- Name: column_value_75; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_75 FOR VALUES IN (75);


--
-- Name: column_value_76; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_76 FOR VALUES IN (76);


--
-- Name: column_value_77; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_77 FOR VALUES IN (77);


--
-- Name: column_value_78; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_78 FOR VALUES IN (78);


--
-- Name: column_value_79; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_79 FOR VALUES IN (79);


--
-- Name: column_value_8; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_8 FOR VALUES IN (8);


--
-- Name: column_value_80; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_80 FOR VALUES IN (80);


--
-- Name: column_value_81; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_81 FOR VALUES IN (81);


--
-- Name: column_value_82; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_82 FOR VALUES IN (82);


--
-- Name: column_value_83; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_83 FOR VALUES IN (83);


--
-- Name: column_value_84; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_84 FOR VALUES IN (84);


--
-- Name: column_value_85; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_85 FOR VALUES IN (85);


--
-- Name: column_value_86; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_86 FOR VALUES IN (86);


--
-- Name: column_value_87; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_87 FOR VALUES IN (87);


--
-- Name: column_value_88; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_88 FOR VALUES IN (88);


--
-- Name: column_value_89; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_89 FOR VALUES IN (89);


--
-- Name: column_value_9; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_9 FOR VALUES IN (9);


--
-- Name: column_value_90; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_90 FOR VALUES IN (90);


--
-- Name: column_value_91; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_91 FOR VALUES IN (91);


--
-- Name: column_value_92; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_92 FOR VALUES IN (92);


--
-- Name: column_value_93; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_93 FOR VALUES IN (93);


--
-- Name: column_value_94; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_94 FOR VALUES IN (94);


--
-- Name: column_value_95; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_95 FOR VALUES IN (95);


--
-- Name: column_value_96; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_96 FOR VALUES IN (96);


--
-- Name: column_value_97; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_97 FOR VALUES IN (97);


--
-- Name: column_value_98; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_98 FOR VALUES IN (98);


--
-- Name: column_value_99; Type: TABLE ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value ATTACH PARTITION gerrydb.column_value_99 FOR VALUES IN (99);


--
-- Name: column col_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb."column" ALTER COLUMN col_id SET DEFAULT nextval('gerrydb.column_col_id_seq'::regclass);


--
-- Name: column_ref ref_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_ref ALTER COLUMN ref_id SET DEFAULT nextval('gerrydb.column_ref_ref_id_seq'::regclass);


--
-- Name: column_relation relation_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_relation ALTER COLUMN relation_id SET DEFAULT nextval('gerrydb.column_relation_relation_id_seq'::regclass);


--
-- Name: column_set set_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_set ALTER COLUMN set_id SET DEFAULT nextval('gerrydb.column_set_set_id_seq'::regclass);


--
-- Name: ensemble ensemble_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.ensemble ALTER COLUMN ensemble_id SET DEFAULT nextval('gerrydb.ensemble_ensemble_id_seq'::regclass);


--
-- Name: etag etag_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.etag ALTER COLUMN etag_id SET DEFAULT nextval('gerrydb.etag_etag_id_seq'::regclass);


--
-- Name: geo_bin geo_bin_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_bin ALTER COLUMN geo_bin_id SET DEFAULT nextval('gerrydb.geo_bin_geo_bin_id_seq'::regclass);


--
-- Name: geo_import import_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_import ALTER COLUMN import_id SET DEFAULT nextval('gerrydb.geo_import_import_id_seq'::regclass);


--
-- Name: geo_layer layer_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_layer ALTER COLUMN layer_id SET DEFAULT nextval('gerrydb.geo_layer_layer_id_seq'::regclass);


--
-- Name: geo_set_version set_version_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_set_version ALTER COLUMN set_version_id SET DEFAULT nextval('gerrydb.geo_set_version_set_version_id_seq'::regclass);


--
-- Name: geography geo_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geography ALTER COLUMN geo_id SET DEFAULT nextval('gerrydb.geography_geo_id_seq'::regclass);


--
-- Name: graph graph_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.graph ALTER COLUMN graph_id SET DEFAULT nextval('gerrydb.graph_graph_id_seq'::regclass);


--
-- Name: locality loc_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.locality ALTER COLUMN loc_id SET DEFAULT nextval('gerrydb.locality_loc_id_seq'::regclass);


--
-- Name: locality_ref ref_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.locality_ref ALTER COLUMN ref_id SET DEFAULT nextval('gerrydb.locality_ref_ref_id_seq'::regclass);


--
-- Name: meta meta_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.meta ALTER COLUMN meta_id SET DEFAULT nextval('gerrydb.meta_meta_id_seq'::regclass);


--
-- Name: namespace namespace_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.namespace ALTER COLUMN namespace_id SET DEFAULT nextval('gerrydb.namespace_namespace_id_seq'::regclass);


--
-- Name: plan plan_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.plan ALTER COLUMN plan_id SET DEFAULT nextval('gerrydb.plan_plan_id_seq'::regclass);


--
-- Name: user user_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb."user" ALTER COLUMN user_id SET DEFAULT nextval('gerrydb.user_user_id_seq'::regclass);


--
-- Name: user_group group_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.user_group ALTER COLUMN group_id SET DEFAULT nextval('gerrydb.user_group_group_id_seq'::regclass);


--
-- Name: user_group_scope group_perm_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.user_group_scope ALTER COLUMN group_perm_id SET DEFAULT nextval('gerrydb.user_group_scope_group_perm_id_seq'::regclass);


--
-- Name: user_scope user_perm_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.user_scope ALTER COLUMN user_perm_id SET DEFAULT nextval('gerrydb.user_scope_user_perm_id_seq'::regclass);


--
-- Name: view view_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view ALTER COLUMN view_id SET DEFAULT nextval('gerrydb.view_view_id_seq'::regclass);


--
-- Name: view_template template_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view_template ALTER COLUMN template_id SET DEFAULT nextval('gerrydb.view_template_template_id_seq'::regclass);


--
-- Name: view_template_version template_version_id; Type: DEFAULT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view_template_version ALTER COLUMN template_version_id SET DEFAULT nextval('gerrydb.view_template_version_template_version_id_seq'::regclass);


--
-- Data for Name: api_key; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.api_key (key_hash, user_id, created_at, active) FROM stdin;
\.
COPY gerrydb.api_key (key_hash, user_id, created_at, active) FROM '$$PATH$$/9477.dat';

--
-- Data for Name: column; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb."column" (col_id, namespace_id, canonical_ref_id, description, source_url, kind, type, meta_id) FROM stdin;
\.
COPY gerrydb."column" (col_id, namespace_id, canonical_ref_id, description, source_url, kind, type, meta_id) FROM '$$PATH$$/9478.dat';

--
-- Data for Name: column_ref; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_ref (ref_id, namespace_id, col_id, path, meta_id) FROM stdin;
\.
COPY gerrydb.column_ref (ref_id, namespace_id, col_id, path, meta_id) FROM '$$PATH$$/9480.dat';

--
-- Data for Name: column_relation; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_relation (relation_id, namespace_id, name, expr, meta_id) FROM stdin;
\.
COPY gerrydb.column_relation (relation_id, namespace_id, name, expr, meta_id) FROM '$$PATH$$/9482.dat';

--
-- Data for Name: column_relation_member; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_relation_member (relation_id, member_id) FROM stdin;
\.
COPY gerrydb.column_relation_member (relation_id, member_id) FROM '$$PATH$$/9483.dat';

--
-- Data for Name: column_set; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_set (set_id, path, namespace_id, description, meta_id) FROM stdin;
\.
COPY gerrydb.column_set (set_id, path, namespace_id, description, meta_id) FROM '$$PATH$$/9485.dat';

--
-- Data for Name: column_set_member; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_set_member (set_id, ref_id, "order") FROM stdin;
\.
COPY gerrydb.column_set_member (set_id, ref_id, "order") FROM '$$PATH$$/9486.dat';

--
-- Data for Name: column_value_1; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_1 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_1 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9488.dat';

--
-- Data for Name: column_value_10; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_10 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_10 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9489.dat';

--
-- Data for Name: column_value_100; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_100 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_100 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9490.dat';

--
-- Data for Name: column_value_101; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_101 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_101 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9491.dat';

--
-- Data for Name: column_value_102; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_102 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_102 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9492.dat';

--
-- Data for Name: column_value_103; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_103 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_103 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9493.dat';

--
-- Data for Name: column_value_104; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_104 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_104 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9494.dat';

--
-- Data for Name: column_value_105; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_105 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_105 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9495.dat';

--
-- Data for Name: column_value_106; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_106 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_106 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9496.dat';

--
-- Data for Name: column_value_107; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_107 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_107 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9497.dat';

--
-- Data for Name: column_value_108; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_108 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_108 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9498.dat';

--
-- Data for Name: column_value_109; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_109 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_109 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9499.dat';

--
-- Data for Name: column_value_11; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_11 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_11 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9500.dat';

--
-- Data for Name: column_value_110; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_110 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_110 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9501.dat';

--
-- Data for Name: column_value_111; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_111 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_111 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9502.dat';

--
-- Data for Name: column_value_112; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_112 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_112 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9503.dat';

--
-- Data for Name: column_value_113; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_113 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_113 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9504.dat';

--
-- Data for Name: column_value_114; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_114 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_114 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9505.dat';

--
-- Data for Name: column_value_115; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_115 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_115 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9506.dat';

--
-- Data for Name: column_value_116; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_116 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_116 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9507.dat';

--
-- Data for Name: column_value_117; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_117 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_117 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9508.dat';

--
-- Data for Name: column_value_118; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_118 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_118 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9509.dat';

--
-- Data for Name: column_value_119; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_119 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_119 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9510.dat';

--
-- Data for Name: column_value_12; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_12 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_12 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9511.dat';

--
-- Data for Name: column_value_120; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_120 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_120 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9512.dat';

--
-- Data for Name: column_value_121; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_121 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_121 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9513.dat';

--
-- Data for Name: column_value_122; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_122 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_122 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9514.dat';

--
-- Data for Name: column_value_123; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_123 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_123 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9515.dat';

--
-- Data for Name: column_value_124; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_124 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_124 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9516.dat';

--
-- Data for Name: column_value_125; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_125 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_125 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9517.dat';

--
-- Data for Name: column_value_126; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_126 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_126 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9518.dat';

--
-- Data for Name: column_value_127; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_127 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_127 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9519.dat';

--
-- Data for Name: column_value_128; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_128 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_128 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9520.dat';

--
-- Data for Name: column_value_129; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_129 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_129 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9521.dat';

--
-- Data for Name: column_value_13; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_13 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_13 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9522.dat';

--
-- Data for Name: column_value_130; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_130 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_130 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9523.dat';

--
-- Data for Name: column_value_131; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_131 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_131 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9524.dat';

--
-- Data for Name: column_value_132; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_132 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_132 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9525.dat';

--
-- Data for Name: column_value_133; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_133 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_133 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9526.dat';

--
-- Data for Name: column_value_134; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_134 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_134 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9527.dat';

--
-- Data for Name: column_value_135; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_135 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_135 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9528.dat';

--
-- Data for Name: column_value_136; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_136 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_136 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9529.dat';

--
-- Data for Name: column_value_137; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_137 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_137 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9530.dat';

--
-- Data for Name: column_value_138; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_138 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_138 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9531.dat';

--
-- Data for Name: column_value_139; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_139 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_139 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9532.dat';

--
-- Data for Name: column_value_14; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_14 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_14 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9533.dat';

--
-- Data for Name: column_value_140; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_140 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_140 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9534.dat';

--
-- Data for Name: column_value_141; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_141 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_141 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9535.dat';

--
-- Data for Name: column_value_142; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_142 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_142 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9536.dat';

--
-- Data for Name: column_value_143; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_143 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_143 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9537.dat';

--
-- Data for Name: column_value_144; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_144 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_144 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9538.dat';

--
-- Data for Name: column_value_145; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_145 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_145 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9539.dat';

--
-- Data for Name: column_value_146; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_146 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_146 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9540.dat';

--
-- Data for Name: column_value_147; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_147 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_147 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9541.dat';

--
-- Data for Name: column_value_148; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_148 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_148 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9542.dat';

--
-- Data for Name: column_value_149; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_149 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_149 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9543.dat';

--
-- Data for Name: column_value_15; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_15 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_15 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9544.dat';

--
-- Data for Name: column_value_150; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_150 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_150 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9545.dat';

--
-- Data for Name: column_value_151; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_151 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_151 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9546.dat';

--
-- Data for Name: column_value_152; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_152 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_152 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9547.dat';

--
-- Data for Name: column_value_153; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_153 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_153 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9548.dat';

--
-- Data for Name: column_value_154; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_154 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_154 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9549.dat';

--
-- Data for Name: column_value_155; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_155 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_155 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9550.dat';

--
-- Data for Name: column_value_156; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_156 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_156 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9551.dat';

--
-- Data for Name: column_value_157; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_157 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_157 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9552.dat';

--
-- Data for Name: column_value_158; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_158 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_158 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9553.dat';

--
-- Data for Name: column_value_159; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_159 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_159 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9554.dat';

--
-- Data for Name: column_value_16; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_16 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_16 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9555.dat';

--
-- Data for Name: column_value_160; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_160 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_160 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9556.dat';

--
-- Data for Name: column_value_161; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_161 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_161 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9557.dat';

--
-- Data for Name: column_value_162; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_162 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_162 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9558.dat';

--
-- Data for Name: column_value_163; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_163 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_163 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9559.dat';

--
-- Data for Name: column_value_164; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_164 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_164 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9560.dat';

--
-- Data for Name: column_value_165; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_165 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_165 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9561.dat';

--
-- Data for Name: column_value_166; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_166 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_166 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9562.dat';

--
-- Data for Name: column_value_167; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_167 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_167 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9563.dat';

--
-- Data for Name: column_value_168; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_168 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_168 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9564.dat';

--
-- Data for Name: column_value_169; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_169 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_169 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9565.dat';

--
-- Data for Name: column_value_17; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_17 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_17 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9566.dat';

--
-- Data for Name: column_value_170; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_170 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_170 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9567.dat';

--
-- Data for Name: column_value_171; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_171 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_171 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9568.dat';

--
-- Data for Name: column_value_172; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_172 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_172 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9569.dat';

--
-- Data for Name: column_value_173; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_173 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_173 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9570.dat';

--
-- Data for Name: column_value_174; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_174 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_174 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9571.dat';

--
-- Data for Name: column_value_175; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_175 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_175 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9572.dat';

--
-- Data for Name: column_value_176; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_176 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_176 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9573.dat';

--
-- Data for Name: column_value_177; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_177 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_177 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9574.dat';

--
-- Data for Name: column_value_178; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_178 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_178 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9575.dat';

--
-- Data for Name: column_value_179; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_179 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_179 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9576.dat';

--
-- Data for Name: column_value_18; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_18 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_18 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9577.dat';

--
-- Data for Name: column_value_180; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_180 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_180 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9578.dat';

--
-- Data for Name: column_value_181; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_181 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_181 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9579.dat';

--
-- Data for Name: column_value_182; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_182 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_182 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9580.dat';

--
-- Data for Name: column_value_183; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_183 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_183 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9581.dat';

--
-- Data for Name: column_value_184; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_184 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_184 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9582.dat';

--
-- Data for Name: column_value_185; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_185 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_185 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9583.dat';

--
-- Data for Name: column_value_186; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_186 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_186 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9584.dat';

--
-- Data for Name: column_value_187; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_187 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_187 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9585.dat';

--
-- Data for Name: column_value_188; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_188 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_188 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9586.dat';

--
-- Data for Name: column_value_189; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_189 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_189 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9587.dat';

--
-- Data for Name: column_value_19; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_19 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_19 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9588.dat';

--
-- Data for Name: column_value_190; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_190 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_190 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9589.dat';

--
-- Data for Name: column_value_191; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_191 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_191 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9590.dat';

--
-- Data for Name: column_value_192; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_192 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_192 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9591.dat';

--
-- Data for Name: column_value_193; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_193 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_193 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9592.dat';

--
-- Data for Name: column_value_194; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_194 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_194 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9593.dat';

--
-- Data for Name: column_value_195; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_195 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_195 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9594.dat';

--
-- Data for Name: column_value_196; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_196 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_196 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9595.dat';

--
-- Data for Name: column_value_197; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_197 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_197 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9596.dat';

--
-- Data for Name: column_value_198; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_198 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_198 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9597.dat';

--
-- Data for Name: column_value_199; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_199 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_199 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9598.dat';

--
-- Data for Name: column_value_2; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_2 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_2 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9599.dat';

--
-- Data for Name: column_value_20; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_20 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_20 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9600.dat';

--
-- Data for Name: column_value_200; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_200 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_200 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9601.dat';

--
-- Data for Name: column_value_201; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_201 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_201 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9602.dat';

--
-- Data for Name: column_value_202; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_202 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_202 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9603.dat';

--
-- Data for Name: column_value_203; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_203 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_203 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9604.dat';

--
-- Data for Name: column_value_204; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_204 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_204 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9605.dat';

--
-- Data for Name: column_value_205; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_205 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_205 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9606.dat';

--
-- Data for Name: column_value_206; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_206 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_206 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9607.dat';

--
-- Data for Name: column_value_207; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_207 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_207 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9608.dat';

--
-- Data for Name: column_value_208; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_208 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_208 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9609.dat';

--
-- Data for Name: column_value_209; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_209 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_209 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9610.dat';

--
-- Data for Name: column_value_21; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_21 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_21 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9611.dat';

--
-- Data for Name: column_value_210; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_210 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_210 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9612.dat';

--
-- Data for Name: column_value_211; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_211 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_211 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9613.dat';

--
-- Data for Name: column_value_212; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_212 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_212 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9614.dat';

--
-- Data for Name: column_value_213; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_213 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_213 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9615.dat';

--
-- Data for Name: column_value_214; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_214 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_214 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9616.dat';

--
-- Data for Name: column_value_215; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_215 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_215 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9617.dat';

--
-- Data for Name: column_value_216; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_216 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_216 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9618.dat';

--
-- Data for Name: column_value_217; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_217 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_217 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9619.dat';

--
-- Data for Name: column_value_218; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_218 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_218 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9620.dat';

--
-- Data for Name: column_value_219; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_219 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_219 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9621.dat';

--
-- Data for Name: column_value_22; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_22 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_22 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9622.dat';

--
-- Data for Name: column_value_220; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_220 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_220 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9623.dat';

--
-- Data for Name: column_value_221; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_221 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_221 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9624.dat';

--
-- Data for Name: column_value_222; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_222 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_222 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9625.dat';

--
-- Data for Name: column_value_223; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_223 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_223 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9626.dat';

--
-- Data for Name: column_value_224; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_224 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_224 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9627.dat';

--
-- Data for Name: column_value_225; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_225 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_225 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9628.dat';

--
-- Data for Name: column_value_226; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_226 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_226 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9629.dat';

--
-- Data for Name: column_value_227; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_227 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_227 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9630.dat';

--
-- Data for Name: column_value_228; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_228 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_228 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9631.dat';

--
-- Data for Name: column_value_229; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_229 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_229 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9632.dat';

--
-- Data for Name: column_value_23; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_23 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_23 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9633.dat';

--
-- Data for Name: column_value_230; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_230 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_230 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9634.dat';

--
-- Data for Name: column_value_231; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_231 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_231 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9635.dat';

--
-- Data for Name: column_value_232; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_232 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_232 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9636.dat';

--
-- Data for Name: column_value_233; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_233 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_233 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9637.dat';

--
-- Data for Name: column_value_234; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_234 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_234 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9638.dat';

--
-- Data for Name: column_value_235; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_235 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_235 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9639.dat';

--
-- Data for Name: column_value_236; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_236 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_236 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9640.dat';

--
-- Data for Name: column_value_237; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_237 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_237 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9641.dat';

--
-- Data for Name: column_value_238; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_238 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_238 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9642.dat';

--
-- Data for Name: column_value_239; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_239 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_239 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9643.dat';

--
-- Data for Name: column_value_24; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_24 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_24 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9644.dat';

--
-- Data for Name: column_value_240; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_240 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_240 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9645.dat';

--
-- Data for Name: column_value_241; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_241 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_241 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9646.dat';

--
-- Data for Name: column_value_242; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_242 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_242 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9647.dat';

--
-- Data for Name: column_value_243; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_243 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_243 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9648.dat';

--
-- Data for Name: column_value_244; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_244 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_244 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9649.dat';

--
-- Data for Name: column_value_245; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_245 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_245 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9650.dat';

--
-- Data for Name: column_value_246; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_246 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_246 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9651.dat';

--
-- Data for Name: column_value_247; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_247 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_247 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9652.dat';

--
-- Data for Name: column_value_248; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_248 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_248 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9653.dat';

--
-- Data for Name: column_value_249; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_249 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_249 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9654.dat';

--
-- Data for Name: column_value_25; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_25 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_25 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9655.dat';

--
-- Data for Name: column_value_250; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_250 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_250 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9656.dat';

--
-- Data for Name: column_value_251; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_251 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_251 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9657.dat';

--
-- Data for Name: column_value_252; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_252 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_252 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9658.dat';

--
-- Data for Name: column_value_253; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_253 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_253 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9659.dat';

--
-- Data for Name: column_value_254; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_254 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_254 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9660.dat';

--
-- Data for Name: column_value_255; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_255 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_255 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9661.dat';

--
-- Data for Name: column_value_256; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_256 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_256 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9662.dat';

--
-- Data for Name: column_value_257; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_257 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_257 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9663.dat';

--
-- Data for Name: column_value_258; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_258 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_258 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9664.dat';

--
-- Data for Name: column_value_259; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_259 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_259 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9665.dat';

--
-- Data for Name: column_value_26; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_26 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_26 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9666.dat';

--
-- Data for Name: column_value_260; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_260 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_260 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9667.dat';

--
-- Data for Name: column_value_261; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_261 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_261 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9668.dat';

--
-- Data for Name: column_value_262; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_262 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_262 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9669.dat';

--
-- Data for Name: column_value_263; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_263 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_263 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9670.dat';

--
-- Data for Name: column_value_264; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_264 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_264 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9671.dat';

--
-- Data for Name: column_value_265; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_265 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_265 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9672.dat';

--
-- Data for Name: column_value_266; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_266 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_266 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9673.dat';

--
-- Data for Name: column_value_267; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_267 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_267 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9674.dat';

--
-- Data for Name: column_value_268; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_268 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_268 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9675.dat';

--
-- Data for Name: column_value_269; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_269 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_269 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9676.dat';

--
-- Data for Name: column_value_27; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_27 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_27 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9677.dat';

--
-- Data for Name: column_value_270; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_270 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_270 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9678.dat';

--
-- Data for Name: column_value_271; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_271 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_271 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9679.dat';

--
-- Data for Name: column_value_272; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_272 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_272 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9680.dat';

--
-- Data for Name: column_value_273; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_273 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_273 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9681.dat';

--
-- Data for Name: column_value_274; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_274 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_274 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9682.dat';

--
-- Data for Name: column_value_275; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_275 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_275 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9683.dat';

--
-- Data for Name: column_value_276; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_276 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_276 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9684.dat';

--
-- Data for Name: column_value_277; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_277 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_277 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9685.dat';

--
-- Data for Name: column_value_278; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_278 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_278 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9686.dat';

--
-- Data for Name: column_value_279; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_279 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_279 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9687.dat';

--
-- Data for Name: column_value_28; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_28 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_28 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9688.dat';

--
-- Data for Name: column_value_280; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_280 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_280 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9689.dat';

--
-- Data for Name: column_value_281; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_281 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_281 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9690.dat';

--
-- Data for Name: column_value_282; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_282 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_282 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9691.dat';

--
-- Data for Name: column_value_283; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_283 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_283 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9692.dat';

--
-- Data for Name: column_value_284; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_284 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_284 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9693.dat';

--
-- Data for Name: column_value_285; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_285 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_285 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9694.dat';

--
-- Data for Name: column_value_286; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_286 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_286 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9695.dat';

--
-- Data for Name: column_value_287; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_287 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_287 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9696.dat';

--
-- Data for Name: column_value_288; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_288 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_288 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9697.dat';

--
-- Data for Name: column_value_289; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_289 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_289 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9698.dat';

--
-- Data for Name: column_value_29; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_29 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_29 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9699.dat';

--
-- Data for Name: column_value_290; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_290 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_290 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9700.dat';

--
-- Data for Name: column_value_291; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_291 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_291 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9701.dat';

--
-- Data for Name: column_value_292; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_292 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_292 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9702.dat';

--
-- Data for Name: column_value_293; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_293 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_293 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9703.dat';

--
-- Data for Name: column_value_294; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_294 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_294 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9704.dat';

--
-- Data for Name: column_value_295; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_295 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_295 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9705.dat';

--
-- Data for Name: column_value_296; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_296 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_296 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9706.dat';

--
-- Data for Name: column_value_297; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_297 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_297 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9707.dat';

--
-- Data for Name: column_value_298; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_298 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_298 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9708.dat';

--
-- Data for Name: column_value_299; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_299 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_299 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9709.dat';

--
-- Data for Name: column_value_3; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_3 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_3 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9710.dat';

--
-- Data for Name: column_value_30; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_30 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_30 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9711.dat';

--
-- Data for Name: column_value_300; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_300 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_300 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9712.dat';

--
-- Data for Name: column_value_301; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_301 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_301 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9713.dat';

--
-- Data for Name: column_value_302; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_302 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_302 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9714.dat';

--
-- Data for Name: column_value_303; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_303 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_303 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9715.dat';

--
-- Data for Name: column_value_304; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_304 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_304 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9716.dat';

--
-- Data for Name: column_value_305; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_305 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_305 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9717.dat';

--
-- Data for Name: column_value_306; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_306 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_306 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9718.dat';

--
-- Data for Name: column_value_307; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_307 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_307 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9719.dat';

--
-- Data for Name: column_value_308; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_308 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_308 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9720.dat';

--
-- Data for Name: column_value_309; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_309 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_309 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9721.dat';

--
-- Data for Name: column_value_31; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_31 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_31 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9722.dat';

--
-- Data for Name: column_value_310; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_310 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_310 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9723.dat';

--
-- Data for Name: column_value_311; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_311 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_311 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9724.dat';

--
-- Data for Name: column_value_312; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_312 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_312 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9725.dat';

--
-- Data for Name: column_value_313; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_313 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_313 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9726.dat';

--
-- Data for Name: column_value_314; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_314 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_314 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9727.dat';

--
-- Data for Name: column_value_315; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_315 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_315 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9728.dat';

--
-- Data for Name: column_value_316; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_316 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_316 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9729.dat';

--
-- Data for Name: column_value_317; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_317 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_317 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9730.dat';

--
-- Data for Name: column_value_318; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_318 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_318 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9731.dat';

--
-- Data for Name: column_value_319; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_319 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_319 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9732.dat';

--
-- Data for Name: column_value_32; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_32 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_32 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9733.dat';

--
-- Data for Name: column_value_320; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_320 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_320 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9734.dat';

--
-- Data for Name: column_value_321; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_321 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_321 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9735.dat';

--
-- Data for Name: column_value_322; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_322 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_322 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9736.dat';

--
-- Data for Name: column_value_323; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_323 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_323 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9737.dat';

--
-- Data for Name: column_value_324; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_324 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_324 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9738.dat';

--
-- Data for Name: column_value_325; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_325 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_325 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9739.dat';

--
-- Data for Name: column_value_326; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_326 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_326 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9740.dat';

--
-- Data for Name: column_value_327; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_327 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_327 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9741.dat';

--
-- Data for Name: column_value_328; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_328 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_328 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9742.dat';

--
-- Data for Name: column_value_329; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_329 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_329 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9743.dat';

--
-- Data for Name: column_value_33; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_33 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_33 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9744.dat';

--
-- Data for Name: column_value_330; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_330 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_330 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9745.dat';

--
-- Data for Name: column_value_331; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_331 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_331 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9746.dat';

--
-- Data for Name: column_value_332; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_332 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_332 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9747.dat';

--
-- Data for Name: column_value_333; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_333 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_333 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9748.dat';

--
-- Data for Name: column_value_334; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_334 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_334 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9749.dat';

--
-- Data for Name: column_value_335; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_335 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_335 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9750.dat';

--
-- Data for Name: column_value_336; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_336 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_336 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9751.dat';

--
-- Data for Name: column_value_337; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_337 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_337 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9752.dat';

--
-- Data for Name: column_value_338; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_338 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_338 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9753.dat';

--
-- Data for Name: column_value_339; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_339 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_339 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9754.dat';

--
-- Data for Name: column_value_34; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_34 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_34 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9755.dat';

--
-- Data for Name: column_value_340; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_340 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_340 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9756.dat';

--
-- Data for Name: column_value_341; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_341 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_341 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9757.dat';

--
-- Data for Name: column_value_342; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_342 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_342 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9758.dat';

--
-- Data for Name: column_value_343; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_343 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_343 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9759.dat';

--
-- Data for Name: column_value_344; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_344 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_344 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9760.dat';

--
-- Data for Name: column_value_345; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_345 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_345 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9761.dat';

--
-- Data for Name: column_value_346; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_346 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_346 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9762.dat';

--
-- Data for Name: column_value_347; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_347 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_347 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9763.dat';

--
-- Data for Name: column_value_348; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_348 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_348 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9764.dat';

--
-- Data for Name: column_value_349; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_349 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_349 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9765.dat';

--
-- Data for Name: column_value_35; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_35 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_35 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9766.dat';

--
-- Data for Name: column_value_350; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_350 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_350 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9767.dat';

--
-- Data for Name: column_value_351; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_351 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_351 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9768.dat';

--
-- Data for Name: column_value_352; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_352 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_352 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9769.dat';

--
-- Data for Name: column_value_353; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_353 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_353 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9770.dat';

--
-- Data for Name: column_value_354; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_354 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_354 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9771.dat';

--
-- Data for Name: column_value_355; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_355 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_355 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9772.dat';

--
-- Data for Name: column_value_356; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_356 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_356 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9773.dat';

--
-- Data for Name: column_value_357; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_357 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_357 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9774.dat';

--
-- Data for Name: column_value_358; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_358 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_358 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9775.dat';

--
-- Data for Name: column_value_359; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_359 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_359 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9776.dat';

--
-- Data for Name: column_value_36; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_36 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_36 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9777.dat';

--
-- Data for Name: column_value_360; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_360 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_360 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9778.dat';

--
-- Data for Name: column_value_361; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_361 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_361 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9779.dat';

--
-- Data for Name: column_value_362; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_362 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_362 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9780.dat';

--
-- Data for Name: column_value_363; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_363 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_363 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9781.dat';

--
-- Data for Name: column_value_364; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_364 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_364 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9782.dat';

--
-- Data for Name: column_value_365; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_365 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_365 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9783.dat';

--
-- Data for Name: column_value_366; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_366 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_366 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9784.dat';

--
-- Data for Name: column_value_367; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_367 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_367 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9785.dat';

--
-- Data for Name: column_value_368; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_368 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_368 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9786.dat';

--
-- Data for Name: column_value_369; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_369 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_369 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9787.dat';

--
-- Data for Name: column_value_37; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_37 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_37 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9788.dat';

--
-- Data for Name: column_value_370; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_370 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_370 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9789.dat';

--
-- Data for Name: column_value_371; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_371 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_371 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9790.dat';

--
-- Data for Name: column_value_372; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_372 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_372 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9791.dat';

--
-- Data for Name: column_value_373; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_373 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_373 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9792.dat';

--
-- Data for Name: column_value_374; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_374 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_374 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9793.dat';

--
-- Data for Name: column_value_375; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_375 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_375 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9794.dat';

--
-- Data for Name: column_value_376; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_376 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_376 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9795.dat';

--
-- Data for Name: column_value_377; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_377 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_377 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9796.dat';

--
-- Data for Name: column_value_378; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_378 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_378 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9797.dat';

--
-- Data for Name: column_value_379; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_379 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_379 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9798.dat';

--
-- Data for Name: column_value_38; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_38 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_38 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9799.dat';

--
-- Data for Name: column_value_380; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_380 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_380 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9800.dat';

--
-- Data for Name: column_value_381; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_381 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_381 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9801.dat';

--
-- Data for Name: column_value_382; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_382 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_382 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9802.dat';

--
-- Data for Name: column_value_383; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_383 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_383 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9803.dat';

--
-- Data for Name: column_value_384; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_384 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_384 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9804.dat';

--
-- Data for Name: column_value_385; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_385 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_385 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9805.dat';

--
-- Data for Name: column_value_386; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_386 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_386 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9806.dat';

--
-- Data for Name: column_value_387; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_387 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_387 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9807.dat';

--
-- Data for Name: column_value_388; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_388 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_388 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9808.dat';

--
-- Data for Name: column_value_389; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_389 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_389 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9809.dat';

--
-- Data for Name: column_value_39; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_39 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_39 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9810.dat';

--
-- Data for Name: column_value_390; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_390 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_390 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9811.dat';

--
-- Data for Name: column_value_391; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_391 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_391 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9812.dat';

--
-- Data for Name: column_value_392; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_392 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_392 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9813.dat';

--
-- Data for Name: column_value_393; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_393 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_393 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9814.dat';

--
-- Data for Name: column_value_394; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_394 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_394 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9815.dat';

--
-- Data for Name: column_value_395; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_395 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_395 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9816.dat';

--
-- Data for Name: column_value_396; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_396 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_396 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9817.dat';

--
-- Data for Name: column_value_397; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_397 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_397 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9818.dat';

--
-- Data for Name: column_value_398; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_398 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_398 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9819.dat';

--
-- Data for Name: column_value_399; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_399 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_399 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9820.dat';

--
-- Data for Name: column_value_4; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_4 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_4 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9821.dat';

--
-- Data for Name: column_value_40; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_40 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_40 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9822.dat';

--
-- Data for Name: column_value_400; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_400 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_400 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9823.dat';

--
-- Data for Name: column_value_401; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_401 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_401 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9824.dat';

--
-- Data for Name: column_value_402; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_402 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_402 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9825.dat';

--
-- Data for Name: column_value_403; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_403 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_403 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9826.dat';

--
-- Data for Name: column_value_404; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_404 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_404 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9827.dat';

--
-- Data for Name: column_value_405; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_405 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_405 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9828.dat';

--
-- Data for Name: column_value_406; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_406 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_406 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9829.dat';

--
-- Data for Name: column_value_407; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_407 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_407 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9830.dat';

--
-- Data for Name: column_value_408; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_408 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_408 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9831.dat';

--
-- Data for Name: column_value_409; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_409 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_409 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9832.dat';

--
-- Data for Name: column_value_41; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_41 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_41 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9833.dat';

--
-- Data for Name: column_value_410; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_410 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_410 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9834.dat';

--
-- Data for Name: column_value_411; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_411 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_411 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9835.dat';

--
-- Data for Name: column_value_412; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_412 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_412 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9836.dat';

--
-- Data for Name: column_value_413; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_413 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_413 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9837.dat';

--
-- Data for Name: column_value_414; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_414 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_414 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9838.dat';

--
-- Data for Name: column_value_415; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_415 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_415 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9839.dat';

--
-- Data for Name: column_value_416; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_416 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_416 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9840.dat';

--
-- Data for Name: column_value_417; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_417 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_417 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9841.dat';

--
-- Data for Name: column_value_418; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_418 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_418 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9842.dat';

--
-- Data for Name: column_value_419; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_419 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_419 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9843.dat';

--
-- Data for Name: column_value_42; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_42 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_42 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9844.dat';

--
-- Data for Name: column_value_420; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_420 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_420 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9845.dat';

--
-- Data for Name: column_value_421; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_421 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_421 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9846.dat';

--
-- Data for Name: column_value_422; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_422 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_422 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9847.dat';

--
-- Data for Name: column_value_423; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_423 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_423 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9848.dat';

--
-- Data for Name: column_value_424; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_424 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_424 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9849.dat';

--
-- Data for Name: column_value_425; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_425 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_425 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9850.dat';

--
-- Data for Name: column_value_426; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_426 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_426 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9851.dat';

--
-- Data for Name: column_value_427; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_427 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_427 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9852.dat';

--
-- Data for Name: column_value_428; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_428 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_428 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9853.dat';

--
-- Data for Name: column_value_429; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_429 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_429 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9854.dat';

--
-- Data for Name: column_value_43; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_43 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_43 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9855.dat';

--
-- Data for Name: column_value_430; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_430 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_430 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9856.dat';

--
-- Data for Name: column_value_431; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_431 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_431 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9857.dat';

--
-- Data for Name: column_value_432; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_432 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_432 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9858.dat';

--
-- Data for Name: column_value_433; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_433 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_433 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9859.dat';

--
-- Data for Name: column_value_434; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_434 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_434 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9860.dat';

--
-- Data for Name: column_value_435; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_435 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_435 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9861.dat';

--
-- Data for Name: column_value_436; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_436 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_436 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9862.dat';

--
-- Data for Name: column_value_437; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_437 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_437 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9863.dat';

--
-- Data for Name: column_value_438; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_438 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_438 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9864.dat';

--
-- Data for Name: column_value_439; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_439 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_439 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9865.dat';

--
-- Data for Name: column_value_44; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_44 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_44 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9866.dat';

--
-- Data for Name: column_value_440; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_440 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_440 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9867.dat';

--
-- Data for Name: column_value_441; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_441 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_441 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9868.dat';

--
-- Data for Name: column_value_442; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_442 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_442 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9869.dat';

--
-- Data for Name: column_value_443; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_443 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_443 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9870.dat';

--
-- Data for Name: column_value_444; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_444 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_444 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9871.dat';

--
-- Data for Name: column_value_445; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_445 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_445 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9872.dat';

--
-- Data for Name: column_value_446; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_446 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_446 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9873.dat';

--
-- Data for Name: column_value_447; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_447 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_447 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9874.dat';

--
-- Data for Name: column_value_448; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_448 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_448 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9875.dat';

--
-- Data for Name: column_value_449; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_449 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_449 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9876.dat';

--
-- Data for Name: column_value_45; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_45 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_45 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9877.dat';

--
-- Data for Name: column_value_450; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_450 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_450 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9878.dat';

--
-- Data for Name: column_value_451; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_451 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_451 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9879.dat';

--
-- Data for Name: column_value_452; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_452 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_452 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9880.dat';

--
-- Data for Name: column_value_453; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_453 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_453 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9881.dat';

--
-- Data for Name: column_value_454; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_454 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_454 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9882.dat';

--
-- Data for Name: column_value_455; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_455 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_455 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9883.dat';

--
-- Data for Name: column_value_456; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_456 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_456 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9884.dat';

--
-- Data for Name: column_value_457; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_457 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_457 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9885.dat';

--
-- Data for Name: column_value_458; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_458 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_458 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9886.dat';

--
-- Data for Name: column_value_459; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_459 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_459 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9887.dat';

--
-- Data for Name: column_value_46; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_46 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_46 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9888.dat';

--
-- Data for Name: column_value_460; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_460 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_460 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9889.dat';

--
-- Data for Name: column_value_461; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_461 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_461 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9890.dat';

--
-- Data for Name: column_value_462; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_462 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_462 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9891.dat';

--
-- Data for Name: column_value_463; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_463 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_463 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9892.dat';

--
-- Data for Name: column_value_464; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_464 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_464 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9893.dat';

--
-- Data for Name: column_value_465; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_465 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_465 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9894.dat';

--
-- Data for Name: column_value_466; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_466 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_466 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9895.dat';

--
-- Data for Name: column_value_467; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_467 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_467 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9896.dat';

--
-- Data for Name: column_value_468; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_468 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_468 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9897.dat';

--
-- Data for Name: column_value_469; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_469 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_469 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9898.dat';

--
-- Data for Name: column_value_47; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_47 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_47 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9899.dat';

--
-- Data for Name: column_value_470; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_470 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_470 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9900.dat';

--
-- Data for Name: column_value_471; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_471 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_471 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9901.dat';

--
-- Data for Name: column_value_472; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_472 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_472 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9902.dat';

--
-- Data for Name: column_value_473; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_473 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_473 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9903.dat';

--
-- Data for Name: column_value_474; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_474 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_474 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9904.dat';

--
-- Data for Name: column_value_475; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_475 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_475 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9905.dat';

--
-- Data for Name: column_value_476; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_476 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_476 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9906.dat';

--
-- Data for Name: column_value_477; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_477 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_477 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9907.dat';

--
-- Data for Name: column_value_478; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_478 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_478 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9908.dat';

--
-- Data for Name: column_value_479; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_479 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_479 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9909.dat';

--
-- Data for Name: column_value_48; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_48 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_48 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9910.dat';

--
-- Data for Name: column_value_480; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_480 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_480 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9911.dat';

--
-- Data for Name: column_value_481; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_481 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_481 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9912.dat';

--
-- Data for Name: column_value_482; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_482 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_482 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9913.dat';

--
-- Data for Name: column_value_483; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_483 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_483 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9914.dat';

--
-- Data for Name: column_value_484; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_484 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_484 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9915.dat';

--
-- Data for Name: column_value_485; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_485 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_485 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9916.dat';

--
-- Data for Name: column_value_486; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_486 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_486 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9917.dat';

--
-- Data for Name: column_value_487; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_487 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_487 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9918.dat';

--
-- Data for Name: column_value_488; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_488 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_488 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9919.dat';

--
-- Data for Name: column_value_489; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_489 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_489 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9920.dat';

--
-- Data for Name: column_value_49; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_49 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_49 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9921.dat';

--
-- Data for Name: column_value_490; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_490 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_490 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9922.dat';

--
-- Data for Name: column_value_491; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_491 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_491 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9923.dat';

--
-- Data for Name: column_value_492; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_492 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_492 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9924.dat';

--
-- Data for Name: column_value_493; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_493 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_493 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9925.dat';

--
-- Data for Name: column_value_494; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_494 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_494 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9926.dat';

--
-- Data for Name: column_value_495; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_495 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_495 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9927.dat';

--
-- Data for Name: column_value_496; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_496 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_496 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9928.dat';

--
-- Data for Name: column_value_497; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_497 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_497 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9929.dat';

--
-- Data for Name: column_value_498; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_498 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_498 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9930.dat';

--
-- Data for Name: column_value_499; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_499 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_499 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9931.dat';

--
-- Data for Name: column_value_5; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_5 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_5 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9932.dat';

--
-- Data for Name: column_value_50; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_50 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_50 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9933.dat';

--
-- Data for Name: column_value_500; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_500 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_500 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9934.dat';

--
-- Data for Name: column_value_501; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_501 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_501 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9935.dat';

--
-- Data for Name: column_value_502; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_502 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_502 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9936.dat';

--
-- Data for Name: column_value_503; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_503 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_503 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9937.dat';

--
-- Data for Name: column_value_504; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_504 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_504 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9938.dat';

--
-- Data for Name: column_value_505; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_505 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_505 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9939.dat';

--
-- Data for Name: column_value_506; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_506 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_506 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9940.dat';

--
-- Data for Name: column_value_507; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_507 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_507 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9941.dat';

--
-- Data for Name: column_value_508; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_508 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_508 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9942.dat';

--
-- Data for Name: column_value_509; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_509 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_509 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9943.dat';

--
-- Data for Name: column_value_51; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_51 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_51 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9944.dat';

--
-- Data for Name: column_value_510; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_510 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_510 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9945.dat';

--
-- Data for Name: column_value_511; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_511 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_511 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9946.dat';

--
-- Data for Name: column_value_512; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_512 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_512 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9947.dat';

--
-- Data for Name: column_value_513; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_513 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_513 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9948.dat';

--
-- Data for Name: column_value_514; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_514 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_514 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9949.dat';

--
-- Data for Name: column_value_515; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_515 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_515 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9950.dat';

--
-- Data for Name: column_value_516; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_516 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_516 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9951.dat';

--
-- Data for Name: column_value_517; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_517 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_517 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9952.dat';

--
-- Data for Name: column_value_518; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_518 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_518 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9953.dat';

--
-- Data for Name: column_value_519; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_519 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_519 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9954.dat';

--
-- Data for Name: column_value_52; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_52 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_52 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9955.dat';

--
-- Data for Name: column_value_520; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_520 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_520 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9956.dat';

--
-- Data for Name: column_value_521; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_521 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_521 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9957.dat';

--
-- Data for Name: column_value_522; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_522 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_522 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9958.dat';

--
-- Data for Name: column_value_523; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_523 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_523 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9959.dat';

--
-- Data for Name: column_value_524; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_524 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_524 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9960.dat';

--
-- Data for Name: column_value_525; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_525 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_525 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9961.dat';

--
-- Data for Name: column_value_526; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_526 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_526 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9962.dat';

--
-- Data for Name: column_value_527; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_527 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_527 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9963.dat';

--
-- Data for Name: column_value_528; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_528 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_528 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9964.dat';

--
-- Data for Name: column_value_529; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_529 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_529 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9965.dat';

--
-- Data for Name: column_value_53; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_53 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_53 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9966.dat';

--
-- Data for Name: column_value_530; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_530 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_530 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9967.dat';

--
-- Data for Name: column_value_531; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_531 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_531 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9968.dat';

--
-- Data for Name: column_value_532; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_532 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_532 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9969.dat';

--
-- Data for Name: column_value_533; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_533 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_533 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9970.dat';

--
-- Data for Name: column_value_534; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_534 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_534 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9971.dat';

--
-- Data for Name: column_value_535; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_535 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_535 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9972.dat';

--
-- Data for Name: column_value_536; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_536 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_536 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9973.dat';

--
-- Data for Name: column_value_537; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_537 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_537 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9974.dat';

--
-- Data for Name: column_value_538; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_538 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_538 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9975.dat';

--
-- Data for Name: column_value_539; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_539 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_539 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9976.dat';

--
-- Data for Name: column_value_54; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_54 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_54 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9977.dat';

--
-- Data for Name: column_value_540; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_540 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_540 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9978.dat';

--
-- Data for Name: column_value_541; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_541 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_541 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9979.dat';

--
-- Data for Name: column_value_542; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_542 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_542 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9980.dat';

--
-- Data for Name: column_value_543; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_543 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_543 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9981.dat';

--
-- Data for Name: column_value_544; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_544 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_544 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9982.dat';

--
-- Data for Name: column_value_545; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_545 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_545 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9983.dat';

--
-- Data for Name: column_value_546; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_546 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_546 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9984.dat';

--
-- Data for Name: column_value_547; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_547 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_547 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9985.dat';

--
-- Data for Name: column_value_548; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_548 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_548 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9986.dat';

--
-- Data for Name: column_value_549; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_549 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_549 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9987.dat';

--
-- Data for Name: column_value_55; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_55 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_55 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9988.dat';

--
-- Data for Name: column_value_550; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_550 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_550 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9989.dat';

--
-- Data for Name: column_value_551; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_551 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_551 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9990.dat';

--
-- Data for Name: column_value_552; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_552 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_552 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9991.dat';

--
-- Data for Name: column_value_553; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_553 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_553 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9992.dat';

--
-- Data for Name: column_value_554; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_554 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_554 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9993.dat';

--
-- Data for Name: column_value_555; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_555 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_555 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9994.dat';

--
-- Data for Name: column_value_556; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_556 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_556 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9995.dat';

--
-- Data for Name: column_value_557; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_557 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_557 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9996.dat';

--
-- Data for Name: column_value_558; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_558 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_558 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9997.dat';

--
-- Data for Name: column_value_559; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_559 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_559 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9998.dat';

--
-- Data for Name: column_value_56; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_56 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_56 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/9999.dat';

--
-- Data for Name: column_value_560; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_560 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_560 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10000.dat';

--
-- Data for Name: column_value_561; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_561 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_561 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10001.dat';

--
-- Data for Name: column_value_562; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_562 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_562 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10002.dat';

--
-- Data for Name: column_value_563; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_563 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_563 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10003.dat';

--
-- Data for Name: column_value_564; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_564 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_564 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10004.dat';

--
-- Data for Name: column_value_565; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_565 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_565 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10005.dat';

--
-- Data for Name: column_value_566; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_566 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_566 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10006.dat';

--
-- Data for Name: column_value_567; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_567 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_567 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10007.dat';

--
-- Data for Name: column_value_568; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_568 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_568 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10008.dat';

--
-- Data for Name: column_value_569; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_569 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_569 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10009.dat';

--
-- Data for Name: column_value_57; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_57 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_57 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10010.dat';

--
-- Data for Name: column_value_570; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_570 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_570 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10011.dat';

--
-- Data for Name: column_value_571; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_571 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_571 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10012.dat';

--
-- Data for Name: column_value_572; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_572 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_572 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10013.dat';

--
-- Data for Name: column_value_573; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_573 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_573 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10014.dat';

--
-- Data for Name: column_value_574; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_574 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_574 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10015.dat';

--
-- Data for Name: column_value_575; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_575 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_575 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10016.dat';

--
-- Data for Name: column_value_576; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_576 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_576 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10017.dat';

--
-- Data for Name: column_value_577; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_577 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_577 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10018.dat';

--
-- Data for Name: column_value_578; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_578 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_578 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10019.dat';

--
-- Data for Name: column_value_579; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_579 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_579 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10020.dat';

--
-- Data for Name: column_value_58; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_58 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_58 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10021.dat';

--
-- Data for Name: column_value_580; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_580 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_580 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10022.dat';

--
-- Data for Name: column_value_581; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_581 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_581 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10023.dat';

--
-- Data for Name: column_value_582; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_582 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_582 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10024.dat';

--
-- Data for Name: column_value_583; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_583 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_583 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10025.dat';

--
-- Data for Name: column_value_584; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_584 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_584 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10026.dat';

--
-- Data for Name: column_value_585; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_585 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_585 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10027.dat';

--
-- Data for Name: column_value_586; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_586 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_586 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10028.dat';

--
-- Data for Name: column_value_587; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_587 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_587 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10029.dat';

--
-- Data for Name: column_value_588; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_588 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_588 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10030.dat';

--
-- Data for Name: column_value_589; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_589 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_589 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10031.dat';

--
-- Data for Name: column_value_59; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_59 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_59 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10032.dat';

--
-- Data for Name: column_value_590; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_590 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_590 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10033.dat';

--
-- Data for Name: column_value_591; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_591 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_591 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10034.dat';

--
-- Data for Name: column_value_592; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_592 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_592 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10035.dat';

--
-- Data for Name: column_value_593; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_593 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_593 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10036.dat';

--
-- Data for Name: column_value_594; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_594 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_594 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10037.dat';

--
-- Data for Name: column_value_6; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_6 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_6 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10038.dat';

--
-- Data for Name: column_value_60; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_60 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_60 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10039.dat';

--
-- Data for Name: column_value_61; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_61 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_61 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10040.dat';

--
-- Data for Name: column_value_62; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_62 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_62 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10041.dat';

--
-- Data for Name: column_value_63; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_63 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_63 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10042.dat';

--
-- Data for Name: column_value_64; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_64 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_64 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10043.dat';

--
-- Data for Name: column_value_65; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_65 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_65 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10044.dat';

--
-- Data for Name: column_value_66; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_66 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_66 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10045.dat';

--
-- Data for Name: column_value_67; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_67 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_67 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10046.dat';

--
-- Data for Name: column_value_68; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_68 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_68 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10047.dat';

--
-- Data for Name: column_value_69; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_69 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_69 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10048.dat';

--
-- Data for Name: column_value_7; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_7 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_7 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10049.dat';

--
-- Data for Name: column_value_70; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_70 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_70 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10050.dat';

--
-- Data for Name: column_value_71; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_71 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_71 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10051.dat';

--
-- Data for Name: column_value_72; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_72 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_72 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10052.dat';

--
-- Data for Name: column_value_73; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_73 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_73 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10053.dat';

--
-- Data for Name: column_value_74; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_74 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_74 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10054.dat';

--
-- Data for Name: column_value_75; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_75 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_75 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10055.dat';

--
-- Data for Name: column_value_76; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_76 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_76 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10056.dat';

--
-- Data for Name: column_value_77; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_77 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_77 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10057.dat';

--
-- Data for Name: column_value_78; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_78 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_78 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10058.dat';

--
-- Data for Name: column_value_79; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_79 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_79 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10059.dat';

--
-- Data for Name: column_value_8; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_8 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_8 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10060.dat';

--
-- Data for Name: column_value_80; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_80 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_80 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10061.dat';

--
-- Data for Name: column_value_81; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_81 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_81 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10062.dat';

--
-- Data for Name: column_value_82; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_82 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_82 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10063.dat';

--
-- Data for Name: column_value_83; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_83 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_83 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10064.dat';

--
-- Data for Name: column_value_84; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_84 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_84 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10065.dat';

--
-- Data for Name: column_value_85; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_85 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_85 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10066.dat';

--
-- Data for Name: column_value_86; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_86 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_86 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10067.dat';

--
-- Data for Name: column_value_87; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_87 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_87 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10068.dat';

--
-- Data for Name: column_value_88; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_88 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_88 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10069.dat';

--
-- Data for Name: column_value_89; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_89 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_89 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10070.dat';

--
-- Data for Name: column_value_9; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_9 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_9 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10071.dat';

--
-- Data for Name: column_value_90; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_90 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_90 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10072.dat';

--
-- Data for Name: column_value_91; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_91 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_91 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10073.dat';

--
-- Data for Name: column_value_92; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_92 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_92 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10074.dat';

--
-- Data for Name: column_value_93; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_93 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_93 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10075.dat';

--
-- Data for Name: column_value_94; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_94 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_94 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10076.dat';

--
-- Data for Name: column_value_95; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_95 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_95 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10077.dat';

--
-- Data for Name: column_value_96; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_96 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_96 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10078.dat';

--
-- Data for Name: column_value_97; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_97 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_97 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10079.dat';

--
-- Data for Name: column_value_98; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_98 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_98 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10080.dat';

--
-- Data for Name: column_value_99; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.column_value_99 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM stdin;
\.
COPY gerrydb.column_value_99 (col_id, geo_id, meta_id, valid_from, valid_to, val_float, val_int, val_str, val_bool) FROM '$$PATH$$/10081.dat';

--
-- Data for Name: ensemble; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.ensemble (ensemble_id, namespace_id, path, graph_id, blob_hash, blob_url, pop_col_id, seed_plan_id, num_districts, num_plans, params, description, meta_id, created_at) FROM stdin;
\.
COPY gerrydb.ensemble (ensemble_id, namespace_id, path, graph_id, blob_hash, blob_url, pop_col_id, seed_plan_id, num_districts, num_plans, params, description, meta_id, created_at) FROM '$$PATH$$/10082.dat';

--
-- Data for Name: etag; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.etag (etag_id, namespace_id, "table", etag) FROM stdin;
\.
COPY gerrydb.etag (etag_id, namespace_id, "table", etag) FROM '$$PATH$$/10084.dat';

--
-- Data for Name: geo_bin; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.geo_bin (geo_bin_id, geography, internal_point) FROM stdin;
\.
COPY gerrydb.geo_bin (geo_bin_id, geography, internal_point) FROM '$$PATH$$/10086.dat';

--
-- Data for Name: geo_hierarchy; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.geo_hierarchy (parent_id, child_id, meta_id) FROM stdin;
\.
COPY gerrydb.geo_hierarchy (parent_id, child_id, meta_id) FROM '$$PATH$$/10088.dat';

--
-- Data for Name: geo_import; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.geo_import (import_id, uuid, namespace_id, meta_id, created_at, created_by) FROM stdin;
\.
COPY gerrydb.geo_import (import_id, uuid, namespace_id, meta_id, created_at, created_by) FROM '$$PATH$$/10089.dat';

--
-- Data for Name: geo_layer; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.geo_layer (layer_id, path, namespace_id, description, source_url, meta_id) FROM stdin;
\.
COPY gerrydb.geo_layer (layer_id, path, namespace_id, description, source_url, meta_id) FROM '$$PATH$$/10091.dat';

--
-- Data for Name: geo_set_member; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.geo_set_member (set_version_id, geo_id) FROM stdin;
\.
COPY gerrydb.geo_set_member (set_version_id, geo_id) FROM '$$PATH$$/10093.dat';

--
-- Data for Name: geo_set_version; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.geo_set_version (set_version_id, layer_id, loc_id, valid_from, valid_to, meta_id) FROM stdin;
\.
COPY gerrydb.geo_set_version (set_version_id, layer_id, loc_id, valid_from, valid_to, meta_id) FROM '$$PATH$$/10094.dat';

--
-- Data for Name: geo_version; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.geo_version (import_id, geo_id, valid_from, valid_to, geo_bin_id) FROM stdin;
\.
COPY gerrydb.geo_version (import_id, geo_id, valid_from, valid_to, geo_bin_id) FROM '$$PATH$$/10096.dat';

--
-- Data for Name: geography; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.geography (geo_id, path, namespace_id, meta_id) FROM stdin;
\.
COPY gerrydb.geography (geo_id, path, namespace_id, meta_id) FROM '$$PATH$$/10097.dat';

--
-- Data for Name: graph; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.graph (graph_id, set_version_id, namespace_id, path, description, meta_id, created_at, proj) FROM stdin;
\.
COPY gerrydb.graph (graph_id, set_version_id, namespace_id, path, description, meta_id, created_at, proj) FROM '$$PATH$$/10099.dat';

--
-- Data for Name: graph_edge; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.graph_edge (graph_id, geo_id_1, geo_id_2, weights) FROM stdin;
\.
COPY gerrydb.graph_edge (graph_id, geo_id_1, geo_id_2, weights) FROM '$$PATH$$/10100.dat';

--
-- Data for Name: graph_render; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.graph_render (render_id, graph_id, created_at, created_by, path, status) FROM stdin;
\.
COPY gerrydb.graph_render (render_id, graph_id, created_at, created_by, path, status) FROM '$$PATH$$/10102.dat';

--
-- Data for Name: locality; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.locality (loc_id, canonical_ref_id, parent_id, meta_id, name, default_proj) FROM stdin;
\.
COPY gerrydb.locality (loc_id, canonical_ref_id, parent_id, meta_id, name, default_proj) FROM '$$PATH$$/10103.dat';

--
-- Data for Name: locality_ref; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.locality_ref (ref_id, loc_id, path, meta_id) FROM stdin;
\.
COPY gerrydb.locality_ref (ref_id, loc_id, path, meta_id) FROM '$$PATH$$/10105.dat';

--
-- Data for Name: meta; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.meta (meta_id, uuid, notes, created_at, created_by) FROM stdin;
\.
COPY gerrydb.meta (meta_id, uuid, notes, created_at, created_by) FROM '$$PATH$$/10107.dat';

--
-- Data for Name: namespace; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.namespace (namespace_id, path, description, public, meta_id) FROM stdin;
\.
COPY gerrydb.namespace (namespace_id, path, description, public, meta_id) FROM '$$PATH$$/10109.dat';

--
-- Data for Name: namespace_limit; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.namespace_limit (user_id, max_ns_creation, curr_creation_count) FROM stdin;
\.
COPY gerrydb.namespace_limit (user_id, max_ns_creation, curr_creation_count) FROM '$$PATH$$/10110.dat';

--
-- Data for Name: plan; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.plan (plan_id, namespace_id, path, set_version_id, num_districts, complete, description, source_url, districtr_id, daves_id, meta_id, created_at) FROM stdin;
\.
COPY gerrydb.plan (plan_id, namespace_id, path, set_version_id, num_districts, complete, description, source_url, districtr_id, daves_id, meta_id, created_at) FROM '$$PATH$$/10112.dat';

--
-- Data for Name: plan_assignment; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.plan_assignment (plan_id, geo_id, assignment) FROM stdin;
\.
COPY gerrydb.plan_assignment (plan_id, geo_id, assignment) FROM '$$PATH$$/10113.dat';

--
-- Data for Name: plan_limit; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.plan_limit (namespace_id, loc_id, layer_id, max_plans) FROM stdin;
\.
COPY gerrydb.plan_limit (namespace_id, loc_id, layer_id, max_plans) FROM '$$PATH$$/10114.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb."user" (user_id, name, email, created_at) FROM stdin;
\.
COPY gerrydb."user" (user_id, name, email, created_at) FROM '$$PATH$$/10116.dat';

--
-- Data for Name: user_group; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.user_group (group_id, name, description, meta_id) FROM stdin;
\.
COPY gerrydb.user_group (group_id, name, description, meta_id) FROM '$$PATH$$/10117.dat';

--
-- Data for Name: user_group_member; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.user_group_member (user_id, group_id, meta_id) FROM stdin;
\.
COPY gerrydb.user_group_member (user_id, group_id, meta_id) FROM '$$PATH$$/10119.dat';

--
-- Data for Name: user_group_scope; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.user_group_scope (group_perm_id, group_id, scope, namespace_group, namespace_id, meta_id) FROM stdin;
\.
COPY gerrydb.user_group_scope (group_perm_id, group_id, scope, namespace_group, namespace_id, meta_id) FROM '$$PATH$$/10120.dat';

--
-- Data for Name: user_scope; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.user_scope (user_perm_id, user_id, scope, namespace_group, namespace_id, meta_id) FROM stdin;
\.
COPY gerrydb.user_scope (user_perm_id, user_id, scope, namespace_group, namespace_id, meta_id) FROM '$$PATH$$/10122.dat';

--
-- Data for Name: view; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.view (view_id, namespace_id, path, template_id, template_version_id, loc_id, layer_id, at, proj, meta_id, graph_id, num_geos) FROM stdin;
\.
COPY gerrydb.view (view_id, namespace_id, path, template_id, template_version_id, loc_id, layer_id, at, proj, meta_id, graph_id, num_geos) FROM '$$PATH$$/10125.dat';

--
-- Data for Name: view_geo_set_versions; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.view_geo_set_versions (view_id, set_version_id) FROM stdin;
\.
COPY gerrydb.view_geo_set_versions (view_id, set_version_id) FROM '$$PATH$$/10126.dat';

--
-- Data for Name: view_render; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.view_render (render_id, view_id, created_at, created_by, path, status) FROM stdin;
\.
COPY gerrydb.view_render (render_id, view_id, created_at, created_by, path, status) FROM '$$PATH$$/10127.dat';

--
-- Data for Name: view_template; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.view_template (template_id, namespace_id, path, description, meta_id) FROM stdin;
\.
COPY gerrydb.view_template (template_id, namespace_id, path, description, meta_id) FROM '$$PATH$$/10128.dat';

--
-- Data for Name: view_template_column_member; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.view_template_column_member (template_version_id, ref_id, "order") FROM stdin;
\.
COPY gerrydb.view_template_column_member (template_version_id, ref_id, "order") FROM '$$PATH$$/10129.dat';

--
-- Data for Name: view_template_column_set_member; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.view_template_column_set_member (template_version_id, set_id, "order") FROM stdin;
\.
COPY gerrydb.view_template_column_set_member (template_version_id, set_id, "order") FROM '$$PATH$$/10130.dat';

--
-- Data for Name: view_template_version; Type: TABLE DATA; Schema: gerrydb; Owner: postgres
--

COPY gerrydb.view_template_version (template_version_id, template_id, valid_from, valid_to, meta_id) FROM stdin;
\.
COPY gerrydb.view_template_version (template_version_id, template_id, valid_from, valid_to, meta_id) FROM '$$PATH$$/10132.dat';

--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.
COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM '$$PATH$$/6682.dat';

--
-- Name: column_col_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.column_col_id_seq', 594, true);


--
-- Name: column_ref_ref_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.column_ref_ref_id_seq', 2362, true);


--
-- Name: column_relation_relation_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.column_relation_relation_id_seq', 1, false);


--
-- Name: column_set_set_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.column_set_set_id_seq', 8, true);


--
-- Name: ensemble_ensemble_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.ensemble_ensemble_id_seq', 1, false);


--
-- Name: etag_etag_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.etag_etag_id_seq', 1540, true);


--
-- Name: geo_bin_geo_bin_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.geo_bin_geo_bin_id_seq', 1, false);


--
-- Name: geo_import_import_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.geo_import_import_id_seq', 1, false);


--
-- Name: geo_layer_layer_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.geo_layer_layer_id_seq', 18, true);


--
-- Name: geo_set_version_set_version_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.geo_set_version_set_version_id_seq', 1, false);


--
-- Name: geography_geo_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.geography_geo_id_seq', 1, false);


--
-- Name: graph_graph_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.graph_graph_id_seq', 1, false);


--
-- Name: locality_loc_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.locality_loc_id_seq', 918, true);


--
-- Name: locality_ref_ref_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.locality_ref_ref_id_seq', 2752, true);


--
-- Name: meta_meta_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.meta_meta_id_seq', 33, true);


--
-- Name: namespace_namespace_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.namespace_namespace_id_seq', 2, true);


--
-- Name: plan_plan_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.plan_plan_id_seq', 1, false);


--
-- Name: user_group_group_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.user_group_group_id_seq', 1, true);


--
-- Name: user_group_scope_group_perm_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.user_group_scope_group_perm_id_seq', 1, true);


--
-- Name: user_scope_user_perm_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.user_scope_user_perm_id_seq', 1, true);


--
-- Name: user_user_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.user_user_id_seq', 1, true);


--
-- Name: view_template_template_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.view_template_template_id_seq', 1, false);


--
-- Name: view_template_version_template_version_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.view_template_version_template_version_id_seq', 1, false);


--
-- Name: view_view_id_seq; Type: SEQUENCE SET; Schema: gerrydb; Owner: postgres
--

SELECT pg_catalog.setval('gerrydb.view_view_id_seq', 1, false);


--
-- Name: api_key api_key_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.api_key
    ADD CONSTRAINT api_key_pkey PRIMARY KEY (key_hash);


--
-- Name: column column_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb."column"
    ADD CONSTRAINT column_pkey PRIMARY KEY (col_id);


--
-- Name: column_ref column_ref_namespace_id_path_key; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_ref
    ADD CONSTRAINT column_ref_namespace_id_path_key UNIQUE (namespace_id, path);


--
-- Name: column_ref column_ref_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_ref
    ADD CONSTRAINT column_ref_pkey PRIMARY KEY (ref_id);


--
-- Name: column_relation_member column_relation_member_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_relation_member
    ADD CONSTRAINT column_relation_member_pkey PRIMARY KEY (relation_id, member_id);


--
-- Name: column_relation column_relation_namespace_id_name_key; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_relation
    ADD CONSTRAINT column_relation_namespace_id_name_key UNIQUE (namespace_id, name);


--
-- Name: column_relation column_relation_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_relation
    ADD CONSTRAINT column_relation_pkey PRIMARY KEY (relation_id);


--
-- Name: column_set_member column_set_member_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_set_member
    ADD CONSTRAINT column_set_member_pkey PRIMARY KEY (set_id, ref_id);


--
-- Name: column_set column_set_path_namespace_id_key; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_set
    ADD CONSTRAINT column_set_path_namespace_id_key UNIQUE (path, namespace_id);


--
-- Name: column_set column_set_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_set
    ADD CONSTRAINT column_set_pkey PRIMARY KEY (set_id);


--
-- Name: column_value column_value_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value
    ADD CONSTRAINT column_value_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_100 column_value_100_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_100
    ADD CONSTRAINT column_value_100_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_101 column_value_101_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_101
    ADD CONSTRAINT column_value_101_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_102 column_value_102_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_102
    ADD CONSTRAINT column_value_102_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_103 column_value_103_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_103
    ADD CONSTRAINT column_value_103_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_104 column_value_104_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_104
    ADD CONSTRAINT column_value_104_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_105 column_value_105_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_105
    ADD CONSTRAINT column_value_105_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_106 column_value_106_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_106
    ADD CONSTRAINT column_value_106_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_107 column_value_107_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_107
    ADD CONSTRAINT column_value_107_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_108 column_value_108_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_108
    ADD CONSTRAINT column_value_108_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_109 column_value_109_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_109
    ADD CONSTRAINT column_value_109_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_10 column_value_10_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_10
    ADD CONSTRAINT column_value_10_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_110 column_value_110_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_110
    ADD CONSTRAINT column_value_110_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_111 column_value_111_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_111
    ADD CONSTRAINT column_value_111_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_112 column_value_112_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_112
    ADD CONSTRAINT column_value_112_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_113 column_value_113_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_113
    ADD CONSTRAINT column_value_113_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_114 column_value_114_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_114
    ADD CONSTRAINT column_value_114_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_115 column_value_115_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_115
    ADD CONSTRAINT column_value_115_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_116 column_value_116_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_116
    ADD CONSTRAINT column_value_116_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_117 column_value_117_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_117
    ADD CONSTRAINT column_value_117_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_118 column_value_118_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_118
    ADD CONSTRAINT column_value_118_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_119 column_value_119_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_119
    ADD CONSTRAINT column_value_119_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_11 column_value_11_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_11
    ADD CONSTRAINT column_value_11_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_120 column_value_120_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_120
    ADD CONSTRAINT column_value_120_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_121 column_value_121_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_121
    ADD CONSTRAINT column_value_121_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_122 column_value_122_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_122
    ADD CONSTRAINT column_value_122_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_123 column_value_123_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_123
    ADD CONSTRAINT column_value_123_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_124 column_value_124_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_124
    ADD CONSTRAINT column_value_124_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_125 column_value_125_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_125
    ADD CONSTRAINT column_value_125_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_126 column_value_126_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_126
    ADD CONSTRAINT column_value_126_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_127 column_value_127_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_127
    ADD CONSTRAINT column_value_127_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_128 column_value_128_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_128
    ADD CONSTRAINT column_value_128_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_129 column_value_129_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_129
    ADD CONSTRAINT column_value_129_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_12 column_value_12_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_12
    ADD CONSTRAINT column_value_12_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_130 column_value_130_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_130
    ADD CONSTRAINT column_value_130_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_131 column_value_131_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_131
    ADD CONSTRAINT column_value_131_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_132 column_value_132_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_132
    ADD CONSTRAINT column_value_132_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_133 column_value_133_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_133
    ADD CONSTRAINT column_value_133_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_134 column_value_134_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_134
    ADD CONSTRAINT column_value_134_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_135 column_value_135_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_135
    ADD CONSTRAINT column_value_135_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_136 column_value_136_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_136
    ADD CONSTRAINT column_value_136_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_137 column_value_137_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_137
    ADD CONSTRAINT column_value_137_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_138 column_value_138_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_138
    ADD CONSTRAINT column_value_138_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_139 column_value_139_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_139
    ADD CONSTRAINT column_value_139_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_13 column_value_13_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_13
    ADD CONSTRAINT column_value_13_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_140 column_value_140_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_140
    ADD CONSTRAINT column_value_140_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_141 column_value_141_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_141
    ADD CONSTRAINT column_value_141_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_142 column_value_142_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_142
    ADD CONSTRAINT column_value_142_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_143 column_value_143_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_143
    ADD CONSTRAINT column_value_143_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_144 column_value_144_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_144
    ADD CONSTRAINT column_value_144_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_145 column_value_145_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_145
    ADD CONSTRAINT column_value_145_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_146 column_value_146_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_146
    ADD CONSTRAINT column_value_146_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_147 column_value_147_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_147
    ADD CONSTRAINT column_value_147_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_148 column_value_148_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_148
    ADD CONSTRAINT column_value_148_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_149 column_value_149_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_149
    ADD CONSTRAINT column_value_149_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_14 column_value_14_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_14
    ADD CONSTRAINT column_value_14_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_150 column_value_150_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_150
    ADD CONSTRAINT column_value_150_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_151 column_value_151_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_151
    ADD CONSTRAINT column_value_151_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_152 column_value_152_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_152
    ADD CONSTRAINT column_value_152_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_153 column_value_153_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_153
    ADD CONSTRAINT column_value_153_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_154 column_value_154_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_154
    ADD CONSTRAINT column_value_154_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_155 column_value_155_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_155
    ADD CONSTRAINT column_value_155_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_156 column_value_156_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_156
    ADD CONSTRAINT column_value_156_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_157 column_value_157_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_157
    ADD CONSTRAINT column_value_157_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_158 column_value_158_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_158
    ADD CONSTRAINT column_value_158_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_159 column_value_159_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_159
    ADD CONSTRAINT column_value_159_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_15 column_value_15_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_15
    ADD CONSTRAINT column_value_15_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_160 column_value_160_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_160
    ADD CONSTRAINT column_value_160_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_161 column_value_161_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_161
    ADD CONSTRAINT column_value_161_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_162 column_value_162_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_162
    ADD CONSTRAINT column_value_162_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_163 column_value_163_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_163
    ADD CONSTRAINT column_value_163_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_164 column_value_164_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_164
    ADD CONSTRAINT column_value_164_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_165 column_value_165_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_165
    ADD CONSTRAINT column_value_165_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_166 column_value_166_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_166
    ADD CONSTRAINT column_value_166_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_167 column_value_167_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_167
    ADD CONSTRAINT column_value_167_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_168 column_value_168_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_168
    ADD CONSTRAINT column_value_168_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_169 column_value_169_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_169
    ADD CONSTRAINT column_value_169_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_16 column_value_16_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_16
    ADD CONSTRAINT column_value_16_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_170 column_value_170_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_170
    ADD CONSTRAINT column_value_170_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_171 column_value_171_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_171
    ADD CONSTRAINT column_value_171_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_172 column_value_172_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_172
    ADD CONSTRAINT column_value_172_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_173 column_value_173_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_173
    ADD CONSTRAINT column_value_173_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_174 column_value_174_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_174
    ADD CONSTRAINT column_value_174_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_175 column_value_175_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_175
    ADD CONSTRAINT column_value_175_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_176 column_value_176_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_176
    ADD CONSTRAINT column_value_176_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_177 column_value_177_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_177
    ADD CONSTRAINT column_value_177_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_178 column_value_178_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_178
    ADD CONSTRAINT column_value_178_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_179 column_value_179_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_179
    ADD CONSTRAINT column_value_179_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_17 column_value_17_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_17
    ADD CONSTRAINT column_value_17_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_180 column_value_180_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_180
    ADD CONSTRAINT column_value_180_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_181 column_value_181_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_181
    ADD CONSTRAINT column_value_181_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_182 column_value_182_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_182
    ADD CONSTRAINT column_value_182_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_183 column_value_183_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_183
    ADD CONSTRAINT column_value_183_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_184 column_value_184_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_184
    ADD CONSTRAINT column_value_184_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_185 column_value_185_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_185
    ADD CONSTRAINT column_value_185_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_186 column_value_186_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_186
    ADD CONSTRAINT column_value_186_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_187 column_value_187_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_187
    ADD CONSTRAINT column_value_187_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_188 column_value_188_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_188
    ADD CONSTRAINT column_value_188_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_189 column_value_189_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_189
    ADD CONSTRAINT column_value_189_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_18 column_value_18_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_18
    ADD CONSTRAINT column_value_18_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_190 column_value_190_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_190
    ADD CONSTRAINT column_value_190_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_191 column_value_191_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_191
    ADD CONSTRAINT column_value_191_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_192 column_value_192_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_192
    ADD CONSTRAINT column_value_192_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_193 column_value_193_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_193
    ADD CONSTRAINT column_value_193_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_194 column_value_194_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_194
    ADD CONSTRAINT column_value_194_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_195 column_value_195_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_195
    ADD CONSTRAINT column_value_195_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_196 column_value_196_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_196
    ADD CONSTRAINT column_value_196_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_197 column_value_197_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_197
    ADD CONSTRAINT column_value_197_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_198 column_value_198_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_198
    ADD CONSTRAINT column_value_198_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_199 column_value_199_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_199
    ADD CONSTRAINT column_value_199_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_19 column_value_19_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_19
    ADD CONSTRAINT column_value_19_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_1 column_value_1_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_1
    ADD CONSTRAINT column_value_1_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_200 column_value_200_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_200
    ADD CONSTRAINT column_value_200_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_201 column_value_201_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_201
    ADD CONSTRAINT column_value_201_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_202 column_value_202_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_202
    ADD CONSTRAINT column_value_202_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_203 column_value_203_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_203
    ADD CONSTRAINT column_value_203_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_204 column_value_204_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_204
    ADD CONSTRAINT column_value_204_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_205 column_value_205_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_205
    ADD CONSTRAINT column_value_205_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_206 column_value_206_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_206
    ADD CONSTRAINT column_value_206_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_207 column_value_207_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_207
    ADD CONSTRAINT column_value_207_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_208 column_value_208_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_208
    ADD CONSTRAINT column_value_208_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_209 column_value_209_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_209
    ADD CONSTRAINT column_value_209_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_20 column_value_20_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_20
    ADD CONSTRAINT column_value_20_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_210 column_value_210_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_210
    ADD CONSTRAINT column_value_210_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_211 column_value_211_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_211
    ADD CONSTRAINT column_value_211_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_212 column_value_212_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_212
    ADD CONSTRAINT column_value_212_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_213 column_value_213_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_213
    ADD CONSTRAINT column_value_213_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_214 column_value_214_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_214
    ADD CONSTRAINT column_value_214_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_215 column_value_215_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_215
    ADD CONSTRAINT column_value_215_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_216 column_value_216_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_216
    ADD CONSTRAINT column_value_216_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_217 column_value_217_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_217
    ADD CONSTRAINT column_value_217_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_218 column_value_218_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_218
    ADD CONSTRAINT column_value_218_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_219 column_value_219_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_219
    ADD CONSTRAINT column_value_219_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_21 column_value_21_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_21
    ADD CONSTRAINT column_value_21_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_220 column_value_220_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_220
    ADD CONSTRAINT column_value_220_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_221 column_value_221_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_221
    ADD CONSTRAINT column_value_221_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_222 column_value_222_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_222
    ADD CONSTRAINT column_value_222_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_223 column_value_223_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_223
    ADD CONSTRAINT column_value_223_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_224 column_value_224_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_224
    ADD CONSTRAINT column_value_224_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_225 column_value_225_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_225
    ADD CONSTRAINT column_value_225_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_226 column_value_226_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_226
    ADD CONSTRAINT column_value_226_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_227 column_value_227_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_227
    ADD CONSTRAINT column_value_227_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_228 column_value_228_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_228
    ADD CONSTRAINT column_value_228_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_229 column_value_229_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_229
    ADD CONSTRAINT column_value_229_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_22 column_value_22_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_22
    ADD CONSTRAINT column_value_22_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_230 column_value_230_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_230
    ADD CONSTRAINT column_value_230_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_231 column_value_231_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_231
    ADD CONSTRAINT column_value_231_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_232 column_value_232_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_232
    ADD CONSTRAINT column_value_232_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_233 column_value_233_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_233
    ADD CONSTRAINT column_value_233_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_234 column_value_234_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_234
    ADD CONSTRAINT column_value_234_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_235 column_value_235_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_235
    ADD CONSTRAINT column_value_235_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_236 column_value_236_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_236
    ADD CONSTRAINT column_value_236_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_237 column_value_237_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_237
    ADD CONSTRAINT column_value_237_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_238 column_value_238_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_238
    ADD CONSTRAINT column_value_238_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_239 column_value_239_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_239
    ADD CONSTRAINT column_value_239_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_23 column_value_23_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_23
    ADD CONSTRAINT column_value_23_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_240 column_value_240_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_240
    ADD CONSTRAINT column_value_240_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_241 column_value_241_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_241
    ADD CONSTRAINT column_value_241_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_242 column_value_242_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_242
    ADD CONSTRAINT column_value_242_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_243 column_value_243_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_243
    ADD CONSTRAINT column_value_243_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_244 column_value_244_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_244
    ADD CONSTRAINT column_value_244_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_245 column_value_245_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_245
    ADD CONSTRAINT column_value_245_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_246 column_value_246_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_246
    ADD CONSTRAINT column_value_246_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_247 column_value_247_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_247
    ADD CONSTRAINT column_value_247_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_248 column_value_248_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_248
    ADD CONSTRAINT column_value_248_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_249 column_value_249_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_249
    ADD CONSTRAINT column_value_249_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_24 column_value_24_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_24
    ADD CONSTRAINT column_value_24_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_250 column_value_250_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_250
    ADD CONSTRAINT column_value_250_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_251 column_value_251_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_251
    ADD CONSTRAINT column_value_251_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_252 column_value_252_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_252
    ADD CONSTRAINT column_value_252_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_253 column_value_253_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_253
    ADD CONSTRAINT column_value_253_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_254 column_value_254_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_254
    ADD CONSTRAINT column_value_254_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_255 column_value_255_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_255
    ADD CONSTRAINT column_value_255_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_256 column_value_256_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_256
    ADD CONSTRAINT column_value_256_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_257 column_value_257_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_257
    ADD CONSTRAINT column_value_257_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_258 column_value_258_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_258
    ADD CONSTRAINT column_value_258_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_259 column_value_259_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_259
    ADD CONSTRAINT column_value_259_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_25 column_value_25_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_25
    ADD CONSTRAINT column_value_25_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_260 column_value_260_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_260
    ADD CONSTRAINT column_value_260_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_261 column_value_261_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_261
    ADD CONSTRAINT column_value_261_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_262 column_value_262_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_262
    ADD CONSTRAINT column_value_262_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_263 column_value_263_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_263
    ADD CONSTRAINT column_value_263_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_264 column_value_264_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_264
    ADD CONSTRAINT column_value_264_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_265 column_value_265_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_265
    ADD CONSTRAINT column_value_265_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_266 column_value_266_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_266
    ADD CONSTRAINT column_value_266_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_267 column_value_267_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_267
    ADD CONSTRAINT column_value_267_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_268 column_value_268_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_268
    ADD CONSTRAINT column_value_268_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_269 column_value_269_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_269
    ADD CONSTRAINT column_value_269_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_26 column_value_26_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_26
    ADD CONSTRAINT column_value_26_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_270 column_value_270_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_270
    ADD CONSTRAINT column_value_270_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_271 column_value_271_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_271
    ADD CONSTRAINT column_value_271_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_272 column_value_272_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_272
    ADD CONSTRAINT column_value_272_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_273 column_value_273_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_273
    ADD CONSTRAINT column_value_273_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_274 column_value_274_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_274
    ADD CONSTRAINT column_value_274_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_275 column_value_275_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_275
    ADD CONSTRAINT column_value_275_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_276 column_value_276_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_276
    ADD CONSTRAINT column_value_276_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_277 column_value_277_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_277
    ADD CONSTRAINT column_value_277_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_278 column_value_278_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_278
    ADD CONSTRAINT column_value_278_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_279 column_value_279_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_279
    ADD CONSTRAINT column_value_279_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_27 column_value_27_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_27
    ADD CONSTRAINT column_value_27_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_280 column_value_280_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_280
    ADD CONSTRAINT column_value_280_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_281 column_value_281_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_281
    ADD CONSTRAINT column_value_281_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_282 column_value_282_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_282
    ADD CONSTRAINT column_value_282_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_283 column_value_283_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_283
    ADD CONSTRAINT column_value_283_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_284 column_value_284_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_284
    ADD CONSTRAINT column_value_284_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_285 column_value_285_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_285
    ADD CONSTRAINT column_value_285_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_286 column_value_286_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_286
    ADD CONSTRAINT column_value_286_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_287 column_value_287_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_287
    ADD CONSTRAINT column_value_287_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_288 column_value_288_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_288
    ADD CONSTRAINT column_value_288_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_289 column_value_289_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_289
    ADD CONSTRAINT column_value_289_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_28 column_value_28_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_28
    ADD CONSTRAINT column_value_28_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_290 column_value_290_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_290
    ADD CONSTRAINT column_value_290_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_291 column_value_291_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_291
    ADD CONSTRAINT column_value_291_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_292 column_value_292_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_292
    ADD CONSTRAINT column_value_292_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_293 column_value_293_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_293
    ADD CONSTRAINT column_value_293_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_294 column_value_294_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_294
    ADD CONSTRAINT column_value_294_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_295 column_value_295_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_295
    ADD CONSTRAINT column_value_295_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_296 column_value_296_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_296
    ADD CONSTRAINT column_value_296_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_297 column_value_297_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_297
    ADD CONSTRAINT column_value_297_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_298 column_value_298_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_298
    ADD CONSTRAINT column_value_298_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_299 column_value_299_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_299
    ADD CONSTRAINT column_value_299_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_29 column_value_29_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_29
    ADD CONSTRAINT column_value_29_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_2 column_value_2_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_2
    ADD CONSTRAINT column_value_2_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_300 column_value_300_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_300
    ADD CONSTRAINT column_value_300_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_301 column_value_301_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_301
    ADD CONSTRAINT column_value_301_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_302 column_value_302_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_302
    ADD CONSTRAINT column_value_302_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_303 column_value_303_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_303
    ADD CONSTRAINT column_value_303_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_304 column_value_304_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_304
    ADD CONSTRAINT column_value_304_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_305 column_value_305_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_305
    ADD CONSTRAINT column_value_305_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_306 column_value_306_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_306
    ADD CONSTRAINT column_value_306_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_307 column_value_307_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_307
    ADD CONSTRAINT column_value_307_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_308 column_value_308_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_308
    ADD CONSTRAINT column_value_308_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_309 column_value_309_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_309
    ADD CONSTRAINT column_value_309_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_30 column_value_30_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_30
    ADD CONSTRAINT column_value_30_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_310 column_value_310_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_310
    ADD CONSTRAINT column_value_310_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_311 column_value_311_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_311
    ADD CONSTRAINT column_value_311_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_312 column_value_312_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_312
    ADD CONSTRAINT column_value_312_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_313 column_value_313_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_313
    ADD CONSTRAINT column_value_313_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_314 column_value_314_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_314
    ADD CONSTRAINT column_value_314_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_315 column_value_315_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_315
    ADD CONSTRAINT column_value_315_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_316 column_value_316_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_316
    ADD CONSTRAINT column_value_316_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_317 column_value_317_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_317
    ADD CONSTRAINT column_value_317_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_318 column_value_318_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_318
    ADD CONSTRAINT column_value_318_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_319 column_value_319_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_319
    ADD CONSTRAINT column_value_319_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_31 column_value_31_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_31
    ADD CONSTRAINT column_value_31_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_320 column_value_320_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_320
    ADD CONSTRAINT column_value_320_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_321 column_value_321_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_321
    ADD CONSTRAINT column_value_321_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_322 column_value_322_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_322
    ADD CONSTRAINT column_value_322_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_323 column_value_323_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_323
    ADD CONSTRAINT column_value_323_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_324 column_value_324_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_324
    ADD CONSTRAINT column_value_324_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_325 column_value_325_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_325
    ADD CONSTRAINT column_value_325_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_326 column_value_326_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_326
    ADD CONSTRAINT column_value_326_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_327 column_value_327_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_327
    ADD CONSTRAINT column_value_327_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_328 column_value_328_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_328
    ADD CONSTRAINT column_value_328_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_329 column_value_329_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_329
    ADD CONSTRAINT column_value_329_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_32 column_value_32_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_32
    ADD CONSTRAINT column_value_32_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_330 column_value_330_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_330
    ADD CONSTRAINT column_value_330_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_331 column_value_331_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_331
    ADD CONSTRAINT column_value_331_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_332 column_value_332_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_332
    ADD CONSTRAINT column_value_332_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_333 column_value_333_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_333
    ADD CONSTRAINT column_value_333_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_334 column_value_334_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_334
    ADD CONSTRAINT column_value_334_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_335 column_value_335_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_335
    ADD CONSTRAINT column_value_335_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_336 column_value_336_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_336
    ADD CONSTRAINT column_value_336_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_337 column_value_337_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_337
    ADD CONSTRAINT column_value_337_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_338 column_value_338_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_338
    ADD CONSTRAINT column_value_338_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_339 column_value_339_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_339
    ADD CONSTRAINT column_value_339_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_33 column_value_33_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_33
    ADD CONSTRAINT column_value_33_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_340 column_value_340_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_340
    ADD CONSTRAINT column_value_340_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_341 column_value_341_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_341
    ADD CONSTRAINT column_value_341_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_342 column_value_342_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_342
    ADD CONSTRAINT column_value_342_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_343 column_value_343_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_343
    ADD CONSTRAINT column_value_343_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_344 column_value_344_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_344
    ADD CONSTRAINT column_value_344_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_345 column_value_345_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_345
    ADD CONSTRAINT column_value_345_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_346 column_value_346_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_346
    ADD CONSTRAINT column_value_346_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_347 column_value_347_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_347
    ADD CONSTRAINT column_value_347_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_348 column_value_348_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_348
    ADD CONSTRAINT column_value_348_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_349 column_value_349_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_349
    ADD CONSTRAINT column_value_349_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_34 column_value_34_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_34
    ADD CONSTRAINT column_value_34_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_350 column_value_350_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_350
    ADD CONSTRAINT column_value_350_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_351 column_value_351_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_351
    ADD CONSTRAINT column_value_351_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_352 column_value_352_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_352
    ADD CONSTRAINT column_value_352_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_353 column_value_353_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_353
    ADD CONSTRAINT column_value_353_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_354 column_value_354_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_354
    ADD CONSTRAINT column_value_354_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_355 column_value_355_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_355
    ADD CONSTRAINT column_value_355_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_356 column_value_356_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_356
    ADD CONSTRAINT column_value_356_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_357 column_value_357_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_357
    ADD CONSTRAINT column_value_357_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_358 column_value_358_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_358
    ADD CONSTRAINT column_value_358_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_359 column_value_359_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_359
    ADD CONSTRAINT column_value_359_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_35 column_value_35_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_35
    ADD CONSTRAINT column_value_35_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_360 column_value_360_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_360
    ADD CONSTRAINT column_value_360_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_361 column_value_361_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_361
    ADD CONSTRAINT column_value_361_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_362 column_value_362_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_362
    ADD CONSTRAINT column_value_362_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_363 column_value_363_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_363
    ADD CONSTRAINT column_value_363_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_364 column_value_364_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_364
    ADD CONSTRAINT column_value_364_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_365 column_value_365_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_365
    ADD CONSTRAINT column_value_365_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_366 column_value_366_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_366
    ADD CONSTRAINT column_value_366_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_367 column_value_367_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_367
    ADD CONSTRAINT column_value_367_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_368 column_value_368_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_368
    ADD CONSTRAINT column_value_368_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_369 column_value_369_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_369
    ADD CONSTRAINT column_value_369_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_36 column_value_36_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_36
    ADD CONSTRAINT column_value_36_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_370 column_value_370_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_370
    ADD CONSTRAINT column_value_370_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_371 column_value_371_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_371
    ADD CONSTRAINT column_value_371_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_372 column_value_372_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_372
    ADD CONSTRAINT column_value_372_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_373 column_value_373_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_373
    ADD CONSTRAINT column_value_373_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_374 column_value_374_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_374
    ADD CONSTRAINT column_value_374_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_375 column_value_375_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_375
    ADD CONSTRAINT column_value_375_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_376 column_value_376_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_376
    ADD CONSTRAINT column_value_376_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_377 column_value_377_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_377
    ADD CONSTRAINT column_value_377_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_378 column_value_378_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_378
    ADD CONSTRAINT column_value_378_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_379 column_value_379_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_379
    ADD CONSTRAINT column_value_379_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_37 column_value_37_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_37
    ADD CONSTRAINT column_value_37_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_380 column_value_380_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_380
    ADD CONSTRAINT column_value_380_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_381 column_value_381_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_381
    ADD CONSTRAINT column_value_381_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_382 column_value_382_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_382
    ADD CONSTRAINT column_value_382_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_383 column_value_383_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_383
    ADD CONSTRAINT column_value_383_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_384 column_value_384_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_384
    ADD CONSTRAINT column_value_384_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_385 column_value_385_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_385
    ADD CONSTRAINT column_value_385_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_386 column_value_386_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_386
    ADD CONSTRAINT column_value_386_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_387 column_value_387_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_387
    ADD CONSTRAINT column_value_387_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_388 column_value_388_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_388
    ADD CONSTRAINT column_value_388_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_389 column_value_389_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_389
    ADD CONSTRAINT column_value_389_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_38 column_value_38_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_38
    ADD CONSTRAINT column_value_38_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_390 column_value_390_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_390
    ADD CONSTRAINT column_value_390_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_391 column_value_391_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_391
    ADD CONSTRAINT column_value_391_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_392 column_value_392_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_392
    ADD CONSTRAINT column_value_392_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_393 column_value_393_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_393
    ADD CONSTRAINT column_value_393_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_394 column_value_394_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_394
    ADD CONSTRAINT column_value_394_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_395 column_value_395_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_395
    ADD CONSTRAINT column_value_395_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_396 column_value_396_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_396
    ADD CONSTRAINT column_value_396_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_397 column_value_397_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_397
    ADD CONSTRAINT column_value_397_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_398 column_value_398_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_398
    ADD CONSTRAINT column_value_398_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_399 column_value_399_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_399
    ADD CONSTRAINT column_value_399_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_39 column_value_39_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_39
    ADD CONSTRAINT column_value_39_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_3 column_value_3_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_3
    ADD CONSTRAINT column_value_3_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_400 column_value_400_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_400
    ADD CONSTRAINT column_value_400_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_401 column_value_401_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_401
    ADD CONSTRAINT column_value_401_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_402 column_value_402_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_402
    ADD CONSTRAINT column_value_402_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_403 column_value_403_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_403
    ADD CONSTRAINT column_value_403_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_404 column_value_404_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_404
    ADD CONSTRAINT column_value_404_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_405 column_value_405_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_405
    ADD CONSTRAINT column_value_405_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_406 column_value_406_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_406
    ADD CONSTRAINT column_value_406_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_407 column_value_407_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_407
    ADD CONSTRAINT column_value_407_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_408 column_value_408_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_408
    ADD CONSTRAINT column_value_408_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_409 column_value_409_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_409
    ADD CONSTRAINT column_value_409_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_40 column_value_40_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_40
    ADD CONSTRAINT column_value_40_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_410 column_value_410_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_410
    ADD CONSTRAINT column_value_410_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_411 column_value_411_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_411
    ADD CONSTRAINT column_value_411_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_412 column_value_412_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_412
    ADD CONSTRAINT column_value_412_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_413 column_value_413_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_413
    ADD CONSTRAINT column_value_413_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_414 column_value_414_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_414
    ADD CONSTRAINT column_value_414_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_415 column_value_415_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_415
    ADD CONSTRAINT column_value_415_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_416 column_value_416_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_416
    ADD CONSTRAINT column_value_416_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_417 column_value_417_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_417
    ADD CONSTRAINT column_value_417_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_418 column_value_418_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_418
    ADD CONSTRAINT column_value_418_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_419 column_value_419_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_419
    ADD CONSTRAINT column_value_419_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_41 column_value_41_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_41
    ADD CONSTRAINT column_value_41_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_420 column_value_420_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_420
    ADD CONSTRAINT column_value_420_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_421 column_value_421_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_421
    ADD CONSTRAINT column_value_421_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_422 column_value_422_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_422
    ADD CONSTRAINT column_value_422_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_423 column_value_423_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_423
    ADD CONSTRAINT column_value_423_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_424 column_value_424_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_424
    ADD CONSTRAINT column_value_424_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_425 column_value_425_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_425
    ADD CONSTRAINT column_value_425_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_426 column_value_426_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_426
    ADD CONSTRAINT column_value_426_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_427 column_value_427_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_427
    ADD CONSTRAINT column_value_427_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_428 column_value_428_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_428
    ADD CONSTRAINT column_value_428_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_429 column_value_429_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_429
    ADD CONSTRAINT column_value_429_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_42 column_value_42_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_42
    ADD CONSTRAINT column_value_42_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_430 column_value_430_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_430
    ADD CONSTRAINT column_value_430_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_431 column_value_431_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_431
    ADD CONSTRAINT column_value_431_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_432 column_value_432_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_432
    ADD CONSTRAINT column_value_432_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_433 column_value_433_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_433
    ADD CONSTRAINT column_value_433_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_434 column_value_434_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_434
    ADD CONSTRAINT column_value_434_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_435 column_value_435_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_435
    ADD CONSTRAINT column_value_435_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_436 column_value_436_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_436
    ADD CONSTRAINT column_value_436_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_437 column_value_437_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_437
    ADD CONSTRAINT column_value_437_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_438 column_value_438_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_438
    ADD CONSTRAINT column_value_438_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_439 column_value_439_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_439
    ADD CONSTRAINT column_value_439_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_43 column_value_43_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_43
    ADD CONSTRAINT column_value_43_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_440 column_value_440_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_440
    ADD CONSTRAINT column_value_440_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_441 column_value_441_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_441
    ADD CONSTRAINT column_value_441_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_442 column_value_442_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_442
    ADD CONSTRAINT column_value_442_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_443 column_value_443_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_443
    ADD CONSTRAINT column_value_443_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_444 column_value_444_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_444
    ADD CONSTRAINT column_value_444_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_445 column_value_445_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_445
    ADD CONSTRAINT column_value_445_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_446 column_value_446_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_446
    ADD CONSTRAINT column_value_446_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_447 column_value_447_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_447
    ADD CONSTRAINT column_value_447_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_448 column_value_448_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_448
    ADD CONSTRAINT column_value_448_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_449 column_value_449_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_449
    ADD CONSTRAINT column_value_449_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_44 column_value_44_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_44
    ADD CONSTRAINT column_value_44_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_450 column_value_450_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_450
    ADD CONSTRAINT column_value_450_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_451 column_value_451_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_451
    ADD CONSTRAINT column_value_451_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_452 column_value_452_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_452
    ADD CONSTRAINT column_value_452_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_453 column_value_453_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_453
    ADD CONSTRAINT column_value_453_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_454 column_value_454_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_454
    ADD CONSTRAINT column_value_454_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_455 column_value_455_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_455
    ADD CONSTRAINT column_value_455_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_456 column_value_456_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_456
    ADD CONSTRAINT column_value_456_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_457 column_value_457_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_457
    ADD CONSTRAINT column_value_457_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_458 column_value_458_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_458
    ADD CONSTRAINT column_value_458_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_459 column_value_459_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_459
    ADD CONSTRAINT column_value_459_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_45 column_value_45_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_45
    ADD CONSTRAINT column_value_45_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_460 column_value_460_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_460
    ADD CONSTRAINT column_value_460_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_461 column_value_461_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_461
    ADD CONSTRAINT column_value_461_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_462 column_value_462_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_462
    ADD CONSTRAINT column_value_462_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_463 column_value_463_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_463
    ADD CONSTRAINT column_value_463_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_464 column_value_464_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_464
    ADD CONSTRAINT column_value_464_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_465 column_value_465_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_465
    ADD CONSTRAINT column_value_465_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_466 column_value_466_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_466
    ADD CONSTRAINT column_value_466_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_467 column_value_467_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_467
    ADD CONSTRAINT column_value_467_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_468 column_value_468_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_468
    ADD CONSTRAINT column_value_468_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_469 column_value_469_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_469
    ADD CONSTRAINT column_value_469_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_46 column_value_46_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_46
    ADD CONSTRAINT column_value_46_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_470 column_value_470_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_470
    ADD CONSTRAINT column_value_470_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_471 column_value_471_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_471
    ADD CONSTRAINT column_value_471_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_472 column_value_472_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_472
    ADD CONSTRAINT column_value_472_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_473 column_value_473_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_473
    ADD CONSTRAINT column_value_473_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_474 column_value_474_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_474
    ADD CONSTRAINT column_value_474_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_475 column_value_475_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_475
    ADD CONSTRAINT column_value_475_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_476 column_value_476_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_476
    ADD CONSTRAINT column_value_476_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_477 column_value_477_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_477
    ADD CONSTRAINT column_value_477_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_478 column_value_478_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_478
    ADD CONSTRAINT column_value_478_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_479 column_value_479_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_479
    ADD CONSTRAINT column_value_479_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_47 column_value_47_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_47
    ADD CONSTRAINT column_value_47_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_480 column_value_480_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_480
    ADD CONSTRAINT column_value_480_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_481 column_value_481_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_481
    ADD CONSTRAINT column_value_481_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_482 column_value_482_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_482
    ADD CONSTRAINT column_value_482_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_483 column_value_483_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_483
    ADD CONSTRAINT column_value_483_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_484 column_value_484_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_484
    ADD CONSTRAINT column_value_484_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_485 column_value_485_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_485
    ADD CONSTRAINT column_value_485_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_486 column_value_486_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_486
    ADD CONSTRAINT column_value_486_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_487 column_value_487_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_487
    ADD CONSTRAINT column_value_487_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_488 column_value_488_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_488
    ADD CONSTRAINT column_value_488_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_489 column_value_489_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_489
    ADD CONSTRAINT column_value_489_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_48 column_value_48_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_48
    ADD CONSTRAINT column_value_48_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_490 column_value_490_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_490
    ADD CONSTRAINT column_value_490_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_491 column_value_491_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_491
    ADD CONSTRAINT column_value_491_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_492 column_value_492_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_492
    ADD CONSTRAINT column_value_492_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_493 column_value_493_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_493
    ADD CONSTRAINT column_value_493_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_494 column_value_494_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_494
    ADD CONSTRAINT column_value_494_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_495 column_value_495_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_495
    ADD CONSTRAINT column_value_495_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_496 column_value_496_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_496
    ADD CONSTRAINT column_value_496_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_497 column_value_497_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_497
    ADD CONSTRAINT column_value_497_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_498 column_value_498_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_498
    ADD CONSTRAINT column_value_498_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_499 column_value_499_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_499
    ADD CONSTRAINT column_value_499_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_49 column_value_49_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_49
    ADD CONSTRAINT column_value_49_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_4 column_value_4_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_4
    ADD CONSTRAINT column_value_4_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_500 column_value_500_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_500
    ADD CONSTRAINT column_value_500_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_501 column_value_501_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_501
    ADD CONSTRAINT column_value_501_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_502 column_value_502_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_502
    ADD CONSTRAINT column_value_502_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_503 column_value_503_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_503
    ADD CONSTRAINT column_value_503_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_504 column_value_504_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_504
    ADD CONSTRAINT column_value_504_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_505 column_value_505_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_505
    ADD CONSTRAINT column_value_505_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_506 column_value_506_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_506
    ADD CONSTRAINT column_value_506_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_507 column_value_507_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_507
    ADD CONSTRAINT column_value_507_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_508 column_value_508_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_508
    ADD CONSTRAINT column_value_508_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_509 column_value_509_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_509
    ADD CONSTRAINT column_value_509_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_50 column_value_50_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_50
    ADD CONSTRAINT column_value_50_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_510 column_value_510_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_510
    ADD CONSTRAINT column_value_510_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_511 column_value_511_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_511
    ADD CONSTRAINT column_value_511_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_512 column_value_512_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_512
    ADD CONSTRAINT column_value_512_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_513 column_value_513_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_513
    ADD CONSTRAINT column_value_513_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_514 column_value_514_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_514
    ADD CONSTRAINT column_value_514_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_515 column_value_515_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_515
    ADD CONSTRAINT column_value_515_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_516 column_value_516_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_516
    ADD CONSTRAINT column_value_516_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_517 column_value_517_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_517
    ADD CONSTRAINT column_value_517_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_518 column_value_518_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_518
    ADD CONSTRAINT column_value_518_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_519 column_value_519_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_519
    ADD CONSTRAINT column_value_519_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_51 column_value_51_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_51
    ADD CONSTRAINT column_value_51_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_520 column_value_520_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_520
    ADD CONSTRAINT column_value_520_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_521 column_value_521_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_521
    ADD CONSTRAINT column_value_521_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_522 column_value_522_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_522
    ADD CONSTRAINT column_value_522_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_523 column_value_523_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_523
    ADD CONSTRAINT column_value_523_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_524 column_value_524_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_524
    ADD CONSTRAINT column_value_524_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_525 column_value_525_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_525
    ADD CONSTRAINT column_value_525_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_526 column_value_526_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_526
    ADD CONSTRAINT column_value_526_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_527 column_value_527_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_527
    ADD CONSTRAINT column_value_527_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_528 column_value_528_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_528
    ADD CONSTRAINT column_value_528_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_529 column_value_529_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_529
    ADD CONSTRAINT column_value_529_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_52 column_value_52_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_52
    ADD CONSTRAINT column_value_52_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_530 column_value_530_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_530
    ADD CONSTRAINT column_value_530_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_531 column_value_531_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_531
    ADD CONSTRAINT column_value_531_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_532 column_value_532_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_532
    ADD CONSTRAINT column_value_532_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_533 column_value_533_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_533
    ADD CONSTRAINT column_value_533_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_534 column_value_534_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_534
    ADD CONSTRAINT column_value_534_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_535 column_value_535_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_535
    ADD CONSTRAINT column_value_535_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_536 column_value_536_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_536
    ADD CONSTRAINT column_value_536_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_537 column_value_537_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_537
    ADD CONSTRAINT column_value_537_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_538 column_value_538_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_538
    ADD CONSTRAINT column_value_538_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_539 column_value_539_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_539
    ADD CONSTRAINT column_value_539_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_53 column_value_53_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_53
    ADD CONSTRAINT column_value_53_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_540 column_value_540_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_540
    ADD CONSTRAINT column_value_540_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_541 column_value_541_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_541
    ADD CONSTRAINT column_value_541_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_542 column_value_542_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_542
    ADD CONSTRAINT column_value_542_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_543 column_value_543_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_543
    ADD CONSTRAINT column_value_543_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_544 column_value_544_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_544
    ADD CONSTRAINT column_value_544_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_545 column_value_545_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_545
    ADD CONSTRAINT column_value_545_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_546 column_value_546_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_546
    ADD CONSTRAINT column_value_546_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_547 column_value_547_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_547
    ADD CONSTRAINT column_value_547_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_548 column_value_548_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_548
    ADD CONSTRAINT column_value_548_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_549 column_value_549_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_549
    ADD CONSTRAINT column_value_549_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_54 column_value_54_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_54
    ADD CONSTRAINT column_value_54_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_550 column_value_550_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_550
    ADD CONSTRAINT column_value_550_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_551 column_value_551_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_551
    ADD CONSTRAINT column_value_551_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_552 column_value_552_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_552
    ADD CONSTRAINT column_value_552_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_553 column_value_553_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_553
    ADD CONSTRAINT column_value_553_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_554 column_value_554_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_554
    ADD CONSTRAINT column_value_554_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_555 column_value_555_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_555
    ADD CONSTRAINT column_value_555_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_556 column_value_556_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_556
    ADD CONSTRAINT column_value_556_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_557 column_value_557_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_557
    ADD CONSTRAINT column_value_557_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_558 column_value_558_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_558
    ADD CONSTRAINT column_value_558_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_559 column_value_559_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_559
    ADD CONSTRAINT column_value_559_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_55 column_value_55_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_55
    ADD CONSTRAINT column_value_55_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_560 column_value_560_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_560
    ADD CONSTRAINT column_value_560_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_561 column_value_561_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_561
    ADD CONSTRAINT column_value_561_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_562 column_value_562_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_562
    ADD CONSTRAINT column_value_562_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_563 column_value_563_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_563
    ADD CONSTRAINT column_value_563_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_564 column_value_564_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_564
    ADD CONSTRAINT column_value_564_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_565 column_value_565_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_565
    ADD CONSTRAINT column_value_565_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_566 column_value_566_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_566
    ADD CONSTRAINT column_value_566_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_567 column_value_567_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_567
    ADD CONSTRAINT column_value_567_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_568 column_value_568_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_568
    ADD CONSTRAINT column_value_568_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_569 column_value_569_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_569
    ADD CONSTRAINT column_value_569_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_56 column_value_56_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_56
    ADD CONSTRAINT column_value_56_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_570 column_value_570_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_570
    ADD CONSTRAINT column_value_570_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_571 column_value_571_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_571
    ADD CONSTRAINT column_value_571_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_572 column_value_572_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_572
    ADD CONSTRAINT column_value_572_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_573 column_value_573_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_573
    ADD CONSTRAINT column_value_573_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_574 column_value_574_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_574
    ADD CONSTRAINT column_value_574_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_575 column_value_575_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_575
    ADD CONSTRAINT column_value_575_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_576 column_value_576_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_576
    ADD CONSTRAINT column_value_576_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_577 column_value_577_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_577
    ADD CONSTRAINT column_value_577_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_578 column_value_578_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_578
    ADD CONSTRAINT column_value_578_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_579 column_value_579_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_579
    ADD CONSTRAINT column_value_579_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_57 column_value_57_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_57
    ADD CONSTRAINT column_value_57_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_580 column_value_580_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_580
    ADD CONSTRAINT column_value_580_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_581 column_value_581_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_581
    ADD CONSTRAINT column_value_581_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_582 column_value_582_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_582
    ADD CONSTRAINT column_value_582_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_583 column_value_583_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_583
    ADD CONSTRAINT column_value_583_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_584 column_value_584_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_584
    ADD CONSTRAINT column_value_584_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_585 column_value_585_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_585
    ADD CONSTRAINT column_value_585_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_586 column_value_586_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_586
    ADD CONSTRAINT column_value_586_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_587 column_value_587_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_587
    ADD CONSTRAINT column_value_587_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_588 column_value_588_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_588
    ADD CONSTRAINT column_value_588_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_589 column_value_589_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_589
    ADD CONSTRAINT column_value_589_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_58 column_value_58_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_58
    ADD CONSTRAINT column_value_58_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_590 column_value_590_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_590
    ADD CONSTRAINT column_value_590_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_591 column_value_591_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_591
    ADD CONSTRAINT column_value_591_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_592 column_value_592_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_592
    ADD CONSTRAINT column_value_592_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_593 column_value_593_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_593
    ADD CONSTRAINT column_value_593_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_594 column_value_594_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_594
    ADD CONSTRAINT column_value_594_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_59 column_value_59_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_59
    ADD CONSTRAINT column_value_59_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_5 column_value_5_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_5
    ADD CONSTRAINT column_value_5_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_60 column_value_60_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_60
    ADD CONSTRAINT column_value_60_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_61 column_value_61_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_61
    ADD CONSTRAINT column_value_61_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_62 column_value_62_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_62
    ADD CONSTRAINT column_value_62_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_63 column_value_63_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_63
    ADD CONSTRAINT column_value_63_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_64 column_value_64_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_64
    ADD CONSTRAINT column_value_64_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_65 column_value_65_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_65
    ADD CONSTRAINT column_value_65_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_66 column_value_66_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_66
    ADD CONSTRAINT column_value_66_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_67 column_value_67_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_67
    ADD CONSTRAINT column_value_67_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_68 column_value_68_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_68
    ADD CONSTRAINT column_value_68_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_69 column_value_69_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_69
    ADD CONSTRAINT column_value_69_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_6 column_value_6_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_6
    ADD CONSTRAINT column_value_6_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_70 column_value_70_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_70
    ADD CONSTRAINT column_value_70_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_71 column_value_71_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_71
    ADD CONSTRAINT column_value_71_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_72 column_value_72_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_72
    ADD CONSTRAINT column_value_72_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_73 column_value_73_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_73
    ADD CONSTRAINT column_value_73_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_74 column_value_74_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_74
    ADD CONSTRAINT column_value_74_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_75 column_value_75_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_75
    ADD CONSTRAINT column_value_75_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_76 column_value_76_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_76
    ADD CONSTRAINT column_value_76_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_77 column_value_77_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_77
    ADD CONSTRAINT column_value_77_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_78 column_value_78_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_78
    ADD CONSTRAINT column_value_78_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_79 column_value_79_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_79
    ADD CONSTRAINT column_value_79_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_7 column_value_7_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_7
    ADD CONSTRAINT column_value_7_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_80 column_value_80_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_80
    ADD CONSTRAINT column_value_80_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_81 column_value_81_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_81
    ADD CONSTRAINT column_value_81_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_82 column_value_82_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_82
    ADD CONSTRAINT column_value_82_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_83 column_value_83_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_83
    ADD CONSTRAINT column_value_83_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_84 column_value_84_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_84
    ADD CONSTRAINT column_value_84_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_85 column_value_85_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_85
    ADD CONSTRAINT column_value_85_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_86 column_value_86_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_86
    ADD CONSTRAINT column_value_86_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_87 column_value_87_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_87
    ADD CONSTRAINT column_value_87_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_88 column_value_88_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_88
    ADD CONSTRAINT column_value_88_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_89 column_value_89_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_89
    ADD CONSTRAINT column_value_89_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_8 column_value_8_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_8
    ADD CONSTRAINT column_value_8_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_90 column_value_90_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_90
    ADD CONSTRAINT column_value_90_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_91 column_value_91_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_91
    ADD CONSTRAINT column_value_91_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_92 column_value_92_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_92
    ADD CONSTRAINT column_value_92_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_93 column_value_93_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_93
    ADD CONSTRAINT column_value_93_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_94 column_value_94_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_94
    ADD CONSTRAINT column_value_94_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_95 column_value_95_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_95
    ADD CONSTRAINT column_value_95_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_96 column_value_96_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_96
    ADD CONSTRAINT column_value_96_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_97 column_value_97_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_97
    ADD CONSTRAINT column_value_97_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_98 column_value_98_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_98
    ADD CONSTRAINT column_value_98_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_99 column_value_99_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_99
    ADD CONSTRAINT column_value_99_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: column_value_9 column_value_9_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_value_9
    ADD CONSTRAINT column_value_9_pkey PRIMARY KEY (col_id, geo_id, valid_from);


--
-- Name: ensemble ensemble_namespace_id_path_key; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.ensemble
    ADD CONSTRAINT ensemble_namespace_id_path_key UNIQUE (namespace_id, path);


--
-- Name: ensemble ensemble_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.ensemble
    ADD CONSTRAINT ensemble_pkey PRIMARY KEY (ensemble_id);


--
-- Name: etag etag_namespace_id_table_key; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.etag
    ADD CONSTRAINT etag_namespace_id_table_key UNIQUE (namespace_id, "table");


--
-- Name: etag etag_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.etag
    ADD CONSTRAINT etag_pkey PRIMARY KEY (etag_id);


--
-- Name: geo_bin geo_bin_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_bin
    ADD CONSTRAINT geo_bin_pkey PRIMARY KEY (geo_bin_id);


--
-- Name: geo_hierarchy geo_hierarchy_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_hierarchy
    ADD CONSTRAINT geo_hierarchy_pkey PRIMARY KEY (parent_id, child_id);


--
-- Name: geo_import geo_import_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_import
    ADD CONSTRAINT geo_import_pkey PRIMARY KEY (import_id);


--
-- Name: geo_layer geo_layer_path_namespace_id_key; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_layer
    ADD CONSTRAINT geo_layer_path_namespace_id_key UNIQUE (path, namespace_id);


--
-- Name: geo_layer geo_layer_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_layer
    ADD CONSTRAINT geo_layer_pkey PRIMARY KEY (layer_id);


--
-- Name: geo_set_member geo_set_member_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_set_member
    ADD CONSTRAINT geo_set_member_pkey PRIMARY KEY (set_version_id, geo_id);


--
-- Name: geo_set_version geo_set_version_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_set_version
    ADD CONSTRAINT geo_set_version_pkey PRIMARY KEY (set_version_id);


--
-- Name: geo_version geo_version_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_version
    ADD CONSTRAINT geo_version_pkey PRIMARY KEY (import_id, geo_id);


--
-- Name: geography geography_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geography
    ADD CONSTRAINT geography_pkey PRIMARY KEY (geo_id);


--
-- Name: graph_edge graph_edge_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.graph_edge
    ADD CONSTRAINT graph_edge_pkey PRIMARY KEY (graph_id, geo_id_1, geo_id_2);


--
-- Name: graph graph_namespace_id_path_key; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.graph
    ADD CONSTRAINT graph_namespace_id_path_key UNIQUE (namespace_id, path);


--
-- Name: graph graph_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.graph
    ADD CONSTRAINT graph_pkey PRIMARY KEY (graph_id);


--
-- Name: graph_render graph_render_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.graph_render
    ADD CONSTRAINT graph_render_pkey PRIMARY KEY (render_id);


--
-- Name: locality locality_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.locality
    ADD CONSTRAINT locality_pkey PRIMARY KEY (loc_id);


--
-- Name: locality_ref locality_ref_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.locality_ref
    ADD CONSTRAINT locality_ref_pkey PRIMARY KEY (ref_id);


--
-- Name: meta meta_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.meta
    ADD CONSTRAINT meta_pkey PRIMARY KEY (meta_id);


--
-- Name: namespace_limit namespace_limit_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.namespace_limit
    ADD CONSTRAINT namespace_limit_pkey PRIMARY KEY (user_id);


--
-- Name: namespace namespace_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.namespace
    ADD CONSTRAINT namespace_pkey PRIMARY KEY (namespace_id);


--
-- Name: plan_assignment plan_assignment_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.plan_assignment
    ADD CONSTRAINT plan_assignment_pkey PRIMARY KEY (plan_id, geo_id);


--
-- Name: plan_limit plan_limit_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.plan_limit
    ADD CONSTRAINT plan_limit_pkey PRIMARY KEY (namespace_id, loc_id, layer_id);


--
-- Name: plan plan_namespace_id_path_key; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.plan
    ADD CONSTRAINT plan_namespace_id_path_key UNIQUE (namespace_id, path);


--
-- Name: plan plan_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.plan
    ADD CONSTRAINT plan_pkey PRIMARY KEY (plan_id);


--
-- Name: geo_bin uq_geo_bin_geometry_hash; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_bin
    ADD CONSTRAINT uq_geo_bin_geometry_hash UNIQUE (geometry_hash);


--
-- Name: geography uq_geography_path_namespace; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geography
    ADD CONSTRAINT uq_geography_path_namespace UNIQUE (path, namespace_id);


--
-- Name: user_group_member user_group_member_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.user_group_member
    ADD CONSTRAINT user_group_member_pkey PRIMARY KEY (user_id, group_id);


--
-- Name: user_group user_group_name_key; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.user_group
    ADD CONSTRAINT user_group_name_key UNIQUE (name);


--
-- Name: user_group user_group_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.user_group
    ADD CONSTRAINT user_group_pkey PRIMARY KEY (group_id);


--
-- Name: user_group_scope user_group_scope_group_id_scope_namespace_id_key; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.user_group_scope
    ADD CONSTRAINT user_group_scope_group_id_scope_namespace_id_key UNIQUE (group_id, scope, namespace_id);


--
-- Name: user_group_scope user_group_scope_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.user_group_scope
    ADD CONSTRAINT user_group_scope_pkey PRIMARY KEY (group_perm_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (user_id);


--
-- Name: user_scope user_scope_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.user_scope
    ADD CONSTRAINT user_scope_pkey PRIMARY KEY (user_perm_id);


--
-- Name: user_scope user_scope_user_id_scope_namespace_id_key; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.user_scope
    ADD CONSTRAINT user_scope_user_id_scope_namespace_id_key UNIQUE (user_id, scope, namespace_id);


--
-- Name: view_geo_set_versions view_geo_set_versions_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view_geo_set_versions
    ADD CONSTRAINT view_geo_set_versions_pkey PRIMARY KEY (view_id, set_version_id);


--
-- Name: view view_namespace_id_path_key; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view
    ADD CONSTRAINT view_namespace_id_path_key UNIQUE (namespace_id, path);


--
-- Name: view view_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view
    ADD CONSTRAINT view_pkey PRIMARY KEY (view_id);


--
-- Name: view_render view_render_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view_render
    ADD CONSTRAINT view_render_pkey PRIMARY KEY (render_id);


--
-- Name: view_template_column_member view_template_column_member_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view_template_column_member
    ADD CONSTRAINT view_template_column_member_pkey PRIMARY KEY (template_version_id, ref_id);


--
-- Name: view_template_column_set_member view_template_column_set_member_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view_template_column_set_member
    ADD CONSTRAINT view_template_column_set_member_pkey PRIMARY KEY (template_version_id, set_id);


--
-- Name: view_template view_template_namespace_id_path_key; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view_template
    ADD CONSTRAINT view_template_namespace_id_path_key UNIQUE (namespace_id, path);


--
-- Name: view_template view_template_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view_template
    ADD CONSTRAINT view_template_pkey PRIMARY KEY (template_id);


--
-- Name: view_template_version view_template_version_pkey; Type: CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view_template_version
    ADD CONSTRAINT view_template_version_pkey PRIMARY KEY (template_version_id);


--
-- Name: ix_geo_bin_geometry_hash; Type: INDEX; Schema: gerrydb; Owner: postgres
--

CREATE INDEX ix_geo_bin_geometry_hash ON gerrydb.geo_bin USING btree (geometry_hash);


--
-- Name: ix_gerrydb_column_canonical_ref_id; Type: INDEX; Schema: gerrydb; Owner: postgres
--

CREATE UNIQUE INDEX ix_gerrydb_column_canonical_ref_id ON gerrydb."column" USING btree (canonical_ref_id);


--
-- Name: ix_gerrydb_column_ref_path; Type: INDEX; Schema: gerrydb; Owner: postgres
--

CREATE INDEX ix_gerrydb_column_ref_path ON gerrydb.column_ref USING btree (path);


--
-- Name: ix_gerrydb_ensemble_graph_id; Type: INDEX; Schema: gerrydb; Owner: postgres
--

CREATE INDEX ix_gerrydb_ensemble_graph_id ON gerrydb.ensemble USING btree (graph_id);


--
-- Name: ix_gerrydb_ensemble_namespace_id; Type: INDEX; Schema: gerrydb; Owner: postgres
--

CREATE INDEX ix_gerrydb_ensemble_namespace_id ON gerrydb.ensemble USING btree (namespace_id);


--
-- Name: ix_gerrydb_ensemble_path; Type: INDEX; Schema: gerrydb; Owner: postgres
--

CREATE INDEX ix_gerrydb_ensemble_path ON gerrydb.ensemble USING btree (path);


--
-- Name: ix_gerrydb_geo_import_uuid; Type: INDEX; Schema: gerrydb; Owner: postgres
--

CREATE UNIQUE INDEX ix_gerrydb_geo_import_uuid ON gerrydb.geo_import USING btree (uuid);


--
-- Name: ix_gerrydb_graph_namespace_id; Type: INDEX; Schema: gerrydb; Owner: postgres
--

CREATE INDEX ix_gerrydb_graph_namespace_id ON gerrydb.graph USING btree (namespace_id);


--
-- Name: ix_gerrydb_graph_path; Type: INDEX; Schema: gerrydb; Owner: postgres
--

CREATE INDEX ix_gerrydb_graph_path ON gerrydb.graph USING btree (path);


--
-- Name: ix_gerrydb_graph_set_version_id; Type: INDEX; Schema: gerrydb; Owner: postgres
--

CREATE INDEX ix_gerrydb_graph_set_version_id ON gerrydb.graph USING btree (set_version_id);


--
-- Name: ix_gerrydb_locality_canonical_ref_id; Type: INDEX; Schema: gerrydb; Owner: postgres
--

CREATE UNIQUE INDEX ix_gerrydb_locality_canonical_ref_id ON gerrydb.locality USING btree (canonical_ref_id);


--
-- Name: ix_gerrydb_locality_ref_path; Type: INDEX; Schema: gerrydb; Owner: postgres
--

CREATE UNIQUE INDEX ix_gerrydb_locality_ref_path ON gerrydb.locality_ref USING btree (path);


--
-- Name: ix_gerrydb_meta_uuid; Type: INDEX; Schema: gerrydb; Owner: postgres
--

CREATE UNIQUE INDEX ix_gerrydb_meta_uuid ON gerrydb.meta USING btree (uuid);


--
-- Name: ix_gerrydb_namespace_path; Type: INDEX; Schema: gerrydb; Owner: postgres
--

CREATE UNIQUE INDEX ix_gerrydb_namespace_path ON gerrydb.namespace USING btree (path);


--
-- Name: ix_gerrydb_plan_namespace_id; Type: INDEX; Schema: gerrydb; Owner: postgres
--

CREATE INDEX ix_gerrydb_plan_namespace_id ON gerrydb.plan USING btree (namespace_id);


--
-- Name: ix_gerrydb_plan_path; Type: INDEX; Schema: gerrydb; Owner: postgres
--

CREATE INDEX ix_gerrydb_plan_path ON gerrydb.plan USING btree (path);


--
-- Name: ix_gerrydb_plan_set_version_id; Type: INDEX; Schema: gerrydb; Owner: postgres
--

CREATE INDEX ix_gerrydb_plan_set_version_id ON gerrydb.plan USING btree (set_version_id);


--
-- Name: ix_gerrydb_user_email; Type: INDEX; Schema: gerrydb; Owner: postgres
--

CREATE UNIQUE INDEX ix_gerrydb_user_email ON gerrydb."user" USING btree (email);


--
-- Name: ix_gerrydb_view_namespace_id; Type: INDEX; Schema: gerrydb; Owner: postgres
--

CREATE INDEX ix_gerrydb_view_namespace_id ON gerrydb.view USING btree (namespace_id);


--
-- Name: ix_gerrydb_view_path; Type: INDEX; Schema: gerrydb; Owner: postgres
--

CREATE INDEX ix_gerrydb_view_path ON gerrydb.view USING btree (path);


--
-- Name: ix_gerrydb_view_template_namespace_id; Type: INDEX; Schema: gerrydb; Owner: postgres
--

CREATE INDEX ix_gerrydb_view_template_namespace_id ON gerrydb.view_template USING btree (namespace_id);


--
-- Name: ix_gerrydb_view_template_path; Type: INDEX; Schema: gerrydb; Owner: postgres
--

CREATE INDEX ix_gerrydb_view_template_path ON gerrydb.view_template USING btree (path);


--
-- Name: column_value_100_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_100_pkey;


--
-- Name: column_value_101_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_101_pkey;


--
-- Name: column_value_102_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_102_pkey;


--
-- Name: column_value_103_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_103_pkey;


--
-- Name: column_value_104_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_104_pkey;


--
-- Name: column_value_105_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_105_pkey;


--
-- Name: column_value_106_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_106_pkey;


--
-- Name: column_value_107_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_107_pkey;


--
-- Name: column_value_108_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_108_pkey;


--
-- Name: column_value_109_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_109_pkey;


--
-- Name: column_value_10_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_10_pkey;


--
-- Name: column_value_110_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_110_pkey;


--
-- Name: column_value_111_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_111_pkey;


--
-- Name: column_value_112_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_112_pkey;


--
-- Name: column_value_113_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_113_pkey;


--
-- Name: column_value_114_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_114_pkey;


--
-- Name: column_value_115_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_115_pkey;


--
-- Name: column_value_116_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_116_pkey;


--
-- Name: column_value_117_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_117_pkey;


--
-- Name: column_value_118_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_118_pkey;


--
-- Name: column_value_119_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_119_pkey;


--
-- Name: column_value_11_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_11_pkey;


--
-- Name: column_value_120_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_120_pkey;


--
-- Name: column_value_121_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_121_pkey;


--
-- Name: column_value_122_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_122_pkey;


--
-- Name: column_value_123_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_123_pkey;


--
-- Name: column_value_124_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_124_pkey;


--
-- Name: column_value_125_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_125_pkey;


--
-- Name: column_value_126_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_126_pkey;


--
-- Name: column_value_127_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_127_pkey;


--
-- Name: column_value_128_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_128_pkey;


--
-- Name: column_value_129_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_129_pkey;


--
-- Name: column_value_12_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_12_pkey;


--
-- Name: column_value_130_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_130_pkey;


--
-- Name: column_value_131_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_131_pkey;


--
-- Name: column_value_132_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_132_pkey;


--
-- Name: column_value_133_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_133_pkey;


--
-- Name: column_value_134_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_134_pkey;


--
-- Name: column_value_135_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_135_pkey;


--
-- Name: column_value_136_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_136_pkey;


--
-- Name: column_value_137_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_137_pkey;


--
-- Name: column_value_138_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_138_pkey;


--
-- Name: column_value_139_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_139_pkey;


--
-- Name: column_value_13_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_13_pkey;


--
-- Name: column_value_140_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_140_pkey;


--
-- Name: column_value_141_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_141_pkey;


--
-- Name: column_value_142_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_142_pkey;


--
-- Name: column_value_143_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_143_pkey;


--
-- Name: column_value_144_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_144_pkey;


--
-- Name: column_value_145_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_145_pkey;


--
-- Name: column_value_146_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_146_pkey;


--
-- Name: column_value_147_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_147_pkey;


--
-- Name: column_value_148_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_148_pkey;


--
-- Name: column_value_149_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_149_pkey;


--
-- Name: column_value_14_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_14_pkey;


--
-- Name: column_value_150_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_150_pkey;


--
-- Name: column_value_151_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_151_pkey;


--
-- Name: column_value_152_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_152_pkey;


--
-- Name: column_value_153_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_153_pkey;


--
-- Name: column_value_154_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_154_pkey;


--
-- Name: column_value_155_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_155_pkey;


--
-- Name: column_value_156_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_156_pkey;


--
-- Name: column_value_157_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_157_pkey;


--
-- Name: column_value_158_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_158_pkey;


--
-- Name: column_value_159_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_159_pkey;


--
-- Name: column_value_15_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_15_pkey;


--
-- Name: column_value_160_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_160_pkey;


--
-- Name: column_value_161_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_161_pkey;


--
-- Name: column_value_162_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_162_pkey;


--
-- Name: column_value_163_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_163_pkey;


--
-- Name: column_value_164_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_164_pkey;


--
-- Name: column_value_165_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_165_pkey;


--
-- Name: column_value_166_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_166_pkey;


--
-- Name: column_value_167_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_167_pkey;


--
-- Name: column_value_168_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_168_pkey;


--
-- Name: column_value_169_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_169_pkey;


--
-- Name: column_value_16_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_16_pkey;


--
-- Name: column_value_170_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_170_pkey;


--
-- Name: column_value_171_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_171_pkey;


--
-- Name: column_value_172_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_172_pkey;


--
-- Name: column_value_173_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_173_pkey;


--
-- Name: column_value_174_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_174_pkey;


--
-- Name: column_value_175_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_175_pkey;


--
-- Name: column_value_176_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_176_pkey;


--
-- Name: column_value_177_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_177_pkey;


--
-- Name: column_value_178_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_178_pkey;


--
-- Name: column_value_179_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_179_pkey;


--
-- Name: column_value_17_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_17_pkey;


--
-- Name: column_value_180_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_180_pkey;


--
-- Name: column_value_181_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_181_pkey;


--
-- Name: column_value_182_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_182_pkey;


--
-- Name: column_value_183_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_183_pkey;


--
-- Name: column_value_184_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_184_pkey;


--
-- Name: column_value_185_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_185_pkey;


--
-- Name: column_value_186_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_186_pkey;


--
-- Name: column_value_187_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_187_pkey;


--
-- Name: column_value_188_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_188_pkey;


--
-- Name: column_value_189_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_189_pkey;


--
-- Name: column_value_18_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_18_pkey;


--
-- Name: column_value_190_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_190_pkey;


--
-- Name: column_value_191_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_191_pkey;


--
-- Name: column_value_192_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_192_pkey;


--
-- Name: column_value_193_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_193_pkey;


--
-- Name: column_value_194_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_194_pkey;


--
-- Name: column_value_195_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_195_pkey;


--
-- Name: column_value_196_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_196_pkey;


--
-- Name: column_value_197_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_197_pkey;


--
-- Name: column_value_198_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_198_pkey;


--
-- Name: column_value_199_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_199_pkey;


--
-- Name: column_value_19_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_19_pkey;


--
-- Name: column_value_1_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_1_pkey;


--
-- Name: column_value_200_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_200_pkey;


--
-- Name: column_value_201_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_201_pkey;


--
-- Name: column_value_202_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_202_pkey;


--
-- Name: column_value_203_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_203_pkey;


--
-- Name: column_value_204_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_204_pkey;


--
-- Name: column_value_205_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_205_pkey;


--
-- Name: column_value_206_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_206_pkey;


--
-- Name: column_value_207_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_207_pkey;


--
-- Name: column_value_208_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_208_pkey;


--
-- Name: column_value_209_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_209_pkey;


--
-- Name: column_value_20_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_20_pkey;


--
-- Name: column_value_210_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_210_pkey;


--
-- Name: column_value_211_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_211_pkey;


--
-- Name: column_value_212_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_212_pkey;


--
-- Name: column_value_213_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_213_pkey;


--
-- Name: column_value_214_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_214_pkey;


--
-- Name: column_value_215_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_215_pkey;


--
-- Name: column_value_216_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_216_pkey;


--
-- Name: column_value_217_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_217_pkey;


--
-- Name: column_value_218_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_218_pkey;


--
-- Name: column_value_219_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_219_pkey;


--
-- Name: column_value_21_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_21_pkey;


--
-- Name: column_value_220_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_220_pkey;


--
-- Name: column_value_221_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_221_pkey;


--
-- Name: column_value_222_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_222_pkey;


--
-- Name: column_value_223_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_223_pkey;


--
-- Name: column_value_224_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_224_pkey;


--
-- Name: column_value_225_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_225_pkey;


--
-- Name: column_value_226_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_226_pkey;


--
-- Name: column_value_227_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_227_pkey;


--
-- Name: column_value_228_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_228_pkey;


--
-- Name: column_value_229_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_229_pkey;


--
-- Name: column_value_22_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_22_pkey;


--
-- Name: column_value_230_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_230_pkey;


--
-- Name: column_value_231_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_231_pkey;


--
-- Name: column_value_232_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_232_pkey;


--
-- Name: column_value_233_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_233_pkey;


--
-- Name: column_value_234_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_234_pkey;


--
-- Name: column_value_235_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_235_pkey;


--
-- Name: column_value_236_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_236_pkey;


--
-- Name: column_value_237_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_237_pkey;


--
-- Name: column_value_238_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_238_pkey;


--
-- Name: column_value_239_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_239_pkey;


--
-- Name: column_value_23_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_23_pkey;


--
-- Name: column_value_240_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_240_pkey;


--
-- Name: column_value_241_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_241_pkey;


--
-- Name: column_value_242_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_242_pkey;


--
-- Name: column_value_243_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_243_pkey;


--
-- Name: column_value_244_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_244_pkey;


--
-- Name: column_value_245_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_245_pkey;


--
-- Name: column_value_246_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_246_pkey;


--
-- Name: column_value_247_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_247_pkey;


--
-- Name: column_value_248_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_248_pkey;


--
-- Name: column_value_249_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_249_pkey;


--
-- Name: column_value_24_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_24_pkey;


--
-- Name: column_value_250_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_250_pkey;


--
-- Name: column_value_251_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_251_pkey;


--
-- Name: column_value_252_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_252_pkey;


--
-- Name: column_value_253_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_253_pkey;


--
-- Name: column_value_254_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_254_pkey;


--
-- Name: column_value_255_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_255_pkey;


--
-- Name: column_value_256_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_256_pkey;


--
-- Name: column_value_257_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_257_pkey;


--
-- Name: column_value_258_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_258_pkey;


--
-- Name: column_value_259_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_259_pkey;


--
-- Name: column_value_25_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_25_pkey;


--
-- Name: column_value_260_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_260_pkey;


--
-- Name: column_value_261_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_261_pkey;


--
-- Name: column_value_262_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_262_pkey;


--
-- Name: column_value_263_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_263_pkey;


--
-- Name: column_value_264_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_264_pkey;


--
-- Name: column_value_265_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_265_pkey;


--
-- Name: column_value_266_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_266_pkey;


--
-- Name: column_value_267_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_267_pkey;


--
-- Name: column_value_268_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_268_pkey;


--
-- Name: column_value_269_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_269_pkey;


--
-- Name: column_value_26_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_26_pkey;


--
-- Name: column_value_270_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_270_pkey;


--
-- Name: column_value_271_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_271_pkey;


--
-- Name: column_value_272_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_272_pkey;


--
-- Name: column_value_273_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_273_pkey;


--
-- Name: column_value_274_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_274_pkey;


--
-- Name: column_value_275_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_275_pkey;


--
-- Name: column_value_276_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_276_pkey;


--
-- Name: column_value_277_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_277_pkey;


--
-- Name: column_value_278_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_278_pkey;


--
-- Name: column_value_279_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_279_pkey;


--
-- Name: column_value_27_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_27_pkey;


--
-- Name: column_value_280_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_280_pkey;


--
-- Name: column_value_281_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_281_pkey;


--
-- Name: column_value_282_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_282_pkey;


--
-- Name: column_value_283_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_283_pkey;


--
-- Name: column_value_284_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_284_pkey;


--
-- Name: column_value_285_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_285_pkey;


--
-- Name: column_value_286_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_286_pkey;


--
-- Name: column_value_287_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_287_pkey;


--
-- Name: column_value_288_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_288_pkey;


--
-- Name: column_value_289_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_289_pkey;


--
-- Name: column_value_28_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_28_pkey;


--
-- Name: column_value_290_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_290_pkey;


--
-- Name: column_value_291_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_291_pkey;


--
-- Name: column_value_292_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_292_pkey;


--
-- Name: column_value_293_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_293_pkey;


--
-- Name: column_value_294_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_294_pkey;


--
-- Name: column_value_295_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_295_pkey;


--
-- Name: column_value_296_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_296_pkey;


--
-- Name: column_value_297_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_297_pkey;


--
-- Name: column_value_298_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_298_pkey;


--
-- Name: column_value_299_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_299_pkey;


--
-- Name: column_value_29_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_29_pkey;


--
-- Name: column_value_2_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_2_pkey;


--
-- Name: column_value_300_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_300_pkey;


--
-- Name: column_value_301_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_301_pkey;


--
-- Name: column_value_302_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_302_pkey;


--
-- Name: column_value_303_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_303_pkey;


--
-- Name: column_value_304_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_304_pkey;


--
-- Name: column_value_305_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_305_pkey;


--
-- Name: column_value_306_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_306_pkey;


--
-- Name: column_value_307_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_307_pkey;


--
-- Name: column_value_308_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_308_pkey;


--
-- Name: column_value_309_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_309_pkey;


--
-- Name: column_value_30_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_30_pkey;


--
-- Name: column_value_310_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_310_pkey;


--
-- Name: column_value_311_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_311_pkey;


--
-- Name: column_value_312_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_312_pkey;


--
-- Name: column_value_313_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_313_pkey;


--
-- Name: column_value_314_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_314_pkey;


--
-- Name: column_value_315_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_315_pkey;


--
-- Name: column_value_316_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_316_pkey;


--
-- Name: column_value_317_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_317_pkey;


--
-- Name: column_value_318_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_318_pkey;


--
-- Name: column_value_319_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_319_pkey;


--
-- Name: column_value_31_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_31_pkey;


--
-- Name: column_value_320_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_320_pkey;


--
-- Name: column_value_321_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_321_pkey;


--
-- Name: column_value_322_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_322_pkey;


--
-- Name: column_value_323_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_323_pkey;


--
-- Name: column_value_324_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_324_pkey;


--
-- Name: column_value_325_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_325_pkey;


--
-- Name: column_value_326_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_326_pkey;


--
-- Name: column_value_327_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_327_pkey;


--
-- Name: column_value_328_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_328_pkey;


--
-- Name: column_value_329_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_329_pkey;


--
-- Name: column_value_32_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_32_pkey;


--
-- Name: column_value_330_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_330_pkey;


--
-- Name: column_value_331_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_331_pkey;


--
-- Name: column_value_332_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_332_pkey;


--
-- Name: column_value_333_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_333_pkey;


--
-- Name: column_value_334_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_334_pkey;


--
-- Name: column_value_335_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_335_pkey;


--
-- Name: column_value_336_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_336_pkey;


--
-- Name: column_value_337_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_337_pkey;


--
-- Name: column_value_338_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_338_pkey;


--
-- Name: column_value_339_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_339_pkey;


--
-- Name: column_value_33_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_33_pkey;


--
-- Name: column_value_340_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_340_pkey;


--
-- Name: column_value_341_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_341_pkey;


--
-- Name: column_value_342_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_342_pkey;


--
-- Name: column_value_343_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_343_pkey;


--
-- Name: column_value_344_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_344_pkey;


--
-- Name: column_value_345_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_345_pkey;


--
-- Name: column_value_346_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_346_pkey;


--
-- Name: column_value_347_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_347_pkey;


--
-- Name: column_value_348_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_348_pkey;


--
-- Name: column_value_349_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_349_pkey;


--
-- Name: column_value_34_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_34_pkey;


--
-- Name: column_value_350_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_350_pkey;


--
-- Name: column_value_351_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_351_pkey;


--
-- Name: column_value_352_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_352_pkey;


--
-- Name: column_value_353_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_353_pkey;


--
-- Name: column_value_354_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_354_pkey;


--
-- Name: column_value_355_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_355_pkey;


--
-- Name: column_value_356_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_356_pkey;


--
-- Name: column_value_357_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_357_pkey;


--
-- Name: column_value_358_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_358_pkey;


--
-- Name: column_value_359_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_359_pkey;


--
-- Name: column_value_35_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_35_pkey;


--
-- Name: column_value_360_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_360_pkey;


--
-- Name: column_value_361_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_361_pkey;


--
-- Name: column_value_362_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_362_pkey;


--
-- Name: column_value_363_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_363_pkey;


--
-- Name: column_value_364_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_364_pkey;


--
-- Name: column_value_365_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_365_pkey;


--
-- Name: column_value_366_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_366_pkey;


--
-- Name: column_value_367_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_367_pkey;


--
-- Name: column_value_368_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_368_pkey;


--
-- Name: column_value_369_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_369_pkey;


--
-- Name: column_value_36_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_36_pkey;


--
-- Name: column_value_370_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_370_pkey;


--
-- Name: column_value_371_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_371_pkey;


--
-- Name: column_value_372_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_372_pkey;


--
-- Name: column_value_373_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_373_pkey;


--
-- Name: column_value_374_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_374_pkey;


--
-- Name: column_value_375_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_375_pkey;


--
-- Name: column_value_376_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_376_pkey;


--
-- Name: column_value_377_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_377_pkey;


--
-- Name: column_value_378_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_378_pkey;


--
-- Name: column_value_379_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_379_pkey;


--
-- Name: column_value_37_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_37_pkey;


--
-- Name: column_value_380_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_380_pkey;


--
-- Name: column_value_381_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_381_pkey;


--
-- Name: column_value_382_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_382_pkey;


--
-- Name: column_value_383_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_383_pkey;


--
-- Name: column_value_384_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_384_pkey;


--
-- Name: column_value_385_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_385_pkey;


--
-- Name: column_value_386_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_386_pkey;


--
-- Name: column_value_387_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_387_pkey;


--
-- Name: column_value_388_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_388_pkey;


--
-- Name: column_value_389_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_389_pkey;


--
-- Name: column_value_38_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_38_pkey;


--
-- Name: column_value_390_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_390_pkey;


--
-- Name: column_value_391_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_391_pkey;


--
-- Name: column_value_392_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_392_pkey;


--
-- Name: column_value_393_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_393_pkey;


--
-- Name: column_value_394_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_394_pkey;


--
-- Name: column_value_395_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_395_pkey;


--
-- Name: column_value_396_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_396_pkey;


--
-- Name: column_value_397_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_397_pkey;


--
-- Name: column_value_398_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_398_pkey;


--
-- Name: column_value_399_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_399_pkey;


--
-- Name: column_value_39_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_39_pkey;


--
-- Name: column_value_3_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_3_pkey;


--
-- Name: column_value_400_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_400_pkey;


--
-- Name: column_value_401_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_401_pkey;


--
-- Name: column_value_402_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_402_pkey;


--
-- Name: column_value_403_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_403_pkey;


--
-- Name: column_value_404_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_404_pkey;


--
-- Name: column_value_405_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_405_pkey;


--
-- Name: column_value_406_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_406_pkey;


--
-- Name: column_value_407_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_407_pkey;


--
-- Name: column_value_408_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_408_pkey;


--
-- Name: column_value_409_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_409_pkey;


--
-- Name: column_value_40_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_40_pkey;


--
-- Name: column_value_410_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_410_pkey;


--
-- Name: column_value_411_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_411_pkey;


--
-- Name: column_value_412_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_412_pkey;


--
-- Name: column_value_413_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_413_pkey;


--
-- Name: column_value_414_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_414_pkey;


--
-- Name: column_value_415_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_415_pkey;


--
-- Name: column_value_416_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_416_pkey;


--
-- Name: column_value_417_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_417_pkey;


--
-- Name: column_value_418_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_418_pkey;


--
-- Name: column_value_419_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_419_pkey;


--
-- Name: column_value_41_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_41_pkey;


--
-- Name: column_value_420_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_420_pkey;


--
-- Name: column_value_421_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_421_pkey;


--
-- Name: column_value_422_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_422_pkey;


--
-- Name: column_value_423_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_423_pkey;


--
-- Name: column_value_424_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_424_pkey;


--
-- Name: column_value_425_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_425_pkey;


--
-- Name: column_value_426_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_426_pkey;


--
-- Name: column_value_427_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_427_pkey;


--
-- Name: column_value_428_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_428_pkey;


--
-- Name: column_value_429_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_429_pkey;


--
-- Name: column_value_42_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_42_pkey;


--
-- Name: column_value_430_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_430_pkey;


--
-- Name: column_value_431_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_431_pkey;


--
-- Name: column_value_432_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_432_pkey;


--
-- Name: column_value_433_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_433_pkey;


--
-- Name: column_value_434_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_434_pkey;


--
-- Name: column_value_435_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_435_pkey;


--
-- Name: column_value_436_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_436_pkey;


--
-- Name: column_value_437_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_437_pkey;


--
-- Name: column_value_438_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_438_pkey;


--
-- Name: column_value_439_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_439_pkey;


--
-- Name: column_value_43_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_43_pkey;


--
-- Name: column_value_440_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_440_pkey;


--
-- Name: column_value_441_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_441_pkey;


--
-- Name: column_value_442_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_442_pkey;


--
-- Name: column_value_443_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_443_pkey;


--
-- Name: column_value_444_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_444_pkey;


--
-- Name: column_value_445_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_445_pkey;


--
-- Name: column_value_446_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_446_pkey;


--
-- Name: column_value_447_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_447_pkey;


--
-- Name: column_value_448_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_448_pkey;


--
-- Name: column_value_449_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_449_pkey;


--
-- Name: column_value_44_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_44_pkey;


--
-- Name: column_value_450_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_450_pkey;


--
-- Name: column_value_451_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_451_pkey;


--
-- Name: column_value_452_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_452_pkey;


--
-- Name: column_value_453_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_453_pkey;


--
-- Name: column_value_454_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_454_pkey;


--
-- Name: column_value_455_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_455_pkey;


--
-- Name: column_value_456_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_456_pkey;


--
-- Name: column_value_457_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_457_pkey;


--
-- Name: column_value_458_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_458_pkey;


--
-- Name: column_value_459_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_459_pkey;


--
-- Name: column_value_45_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_45_pkey;


--
-- Name: column_value_460_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_460_pkey;


--
-- Name: column_value_461_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_461_pkey;


--
-- Name: column_value_462_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_462_pkey;


--
-- Name: column_value_463_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_463_pkey;


--
-- Name: column_value_464_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_464_pkey;


--
-- Name: column_value_465_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_465_pkey;


--
-- Name: column_value_466_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_466_pkey;


--
-- Name: column_value_467_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_467_pkey;


--
-- Name: column_value_468_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_468_pkey;


--
-- Name: column_value_469_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_469_pkey;


--
-- Name: column_value_46_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_46_pkey;


--
-- Name: column_value_470_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_470_pkey;


--
-- Name: column_value_471_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_471_pkey;


--
-- Name: column_value_472_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_472_pkey;


--
-- Name: column_value_473_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_473_pkey;


--
-- Name: column_value_474_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_474_pkey;


--
-- Name: column_value_475_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_475_pkey;


--
-- Name: column_value_476_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_476_pkey;


--
-- Name: column_value_477_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_477_pkey;


--
-- Name: column_value_478_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_478_pkey;


--
-- Name: column_value_479_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_479_pkey;


--
-- Name: column_value_47_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_47_pkey;


--
-- Name: column_value_480_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_480_pkey;


--
-- Name: column_value_481_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_481_pkey;


--
-- Name: column_value_482_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_482_pkey;


--
-- Name: column_value_483_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_483_pkey;


--
-- Name: column_value_484_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_484_pkey;


--
-- Name: column_value_485_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_485_pkey;


--
-- Name: column_value_486_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_486_pkey;


--
-- Name: column_value_487_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_487_pkey;


--
-- Name: column_value_488_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_488_pkey;


--
-- Name: column_value_489_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_489_pkey;


--
-- Name: column_value_48_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_48_pkey;


--
-- Name: column_value_490_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_490_pkey;


--
-- Name: column_value_491_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_491_pkey;


--
-- Name: column_value_492_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_492_pkey;


--
-- Name: column_value_493_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_493_pkey;


--
-- Name: column_value_494_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_494_pkey;


--
-- Name: column_value_495_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_495_pkey;


--
-- Name: column_value_496_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_496_pkey;


--
-- Name: column_value_497_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_497_pkey;


--
-- Name: column_value_498_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_498_pkey;


--
-- Name: column_value_499_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_499_pkey;


--
-- Name: column_value_49_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_49_pkey;


--
-- Name: column_value_4_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_4_pkey;


--
-- Name: column_value_500_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_500_pkey;


--
-- Name: column_value_501_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_501_pkey;


--
-- Name: column_value_502_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_502_pkey;


--
-- Name: column_value_503_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_503_pkey;


--
-- Name: column_value_504_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_504_pkey;


--
-- Name: column_value_505_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_505_pkey;


--
-- Name: column_value_506_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_506_pkey;


--
-- Name: column_value_507_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_507_pkey;


--
-- Name: column_value_508_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_508_pkey;


--
-- Name: column_value_509_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_509_pkey;


--
-- Name: column_value_50_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_50_pkey;


--
-- Name: column_value_510_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_510_pkey;


--
-- Name: column_value_511_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_511_pkey;


--
-- Name: column_value_512_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_512_pkey;


--
-- Name: column_value_513_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_513_pkey;


--
-- Name: column_value_514_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_514_pkey;


--
-- Name: column_value_515_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_515_pkey;


--
-- Name: column_value_516_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_516_pkey;


--
-- Name: column_value_517_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_517_pkey;


--
-- Name: column_value_518_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_518_pkey;


--
-- Name: column_value_519_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_519_pkey;


--
-- Name: column_value_51_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_51_pkey;


--
-- Name: column_value_520_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_520_pkey;


--
-- Name: column_value_521_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_521_pkey;


--
-- Name: column_value_522_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_522_pkey;


--
-- Name: column_value_523_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_523_pkey;


--
-- Name: column_value_524_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_524_pkey;


--
-- Name: column_value_525_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_525_pkey;


--
-- Name: column_value_526_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_526_pkey;


--
-- Name: column_value_527_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_527_pkey;


--
-- Name: column_value_528_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_528_pkey;


--
-- Name: column_value_529_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_529_pkey;


--
-- Name: column_value_52_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_52_pkey;


--
-- Name: column_value_530_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_530_pkey;


--
-- Name: column_value_531_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_531_pkey;


--
-- Name: column_value_532_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_532_pkey;


--
-- Name: column_value_533_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_533_pkey;


--
-- Name: column_value_534_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_534_pkey;


--
-- Name: column_value_535_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_535_pkey;


--
-- Name: column_value_536_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_536_pkey;


--
-- Name: column_value_537_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_537_pkey;


--
-- Name: column_value_538_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_538_pkey;


--
-- Name: column_value_539_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_539_pkey;


--
-- Name: column_value_53_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_53_pkey;


--
-- Name: column_value_540_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_540_pkey;


--
-- Name: column_value_541_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_541_pkey;


--
-- Name: column_value_542_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_542_pkey;


--
-- Name: column_value_543_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_543_pkey;


--
-- Name: column_value_544_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_544_pkey;


--
-- Name: column_value_545_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_545_pkey;


--
-- Name: column_value_546_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_546_pkey;


--
-- Name: column_value_547_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_547_pkey;


--
-- Name: column_value_548_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_548_pkey;


--
-- Name: column_value_549_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_549_pkey;


--
-- Name: column_value_54_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_54_pkey;


--
-- Name: column_value_550_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_550_pkey;


--
-- Name: column_value_551_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_551_pkey;


--
-- Name: column_value_552_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_552_pkey;


--
-- Name: column_value_553_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_553_pkey;


--
-- Name: column_value_554_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_554_pkey;


--
-- Name: column_value_555_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_555_pkey;


--
-- Name: column_value_556_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_556_pkey;


--
-- Name: column_value_557_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_557_pkey;


--
-- Name: column_value_558_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_558_pkey;


--
-- Name: column_value_559_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_559_pkey;


--
-- Name: column_value_55_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_55_pkey;


--
-- Name: column_value_560_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_560_pkey;


--
-- Name: column_value_561_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_561_pkey;


--
-- Name: column_value_562_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_562_pkey;


--
-- Name: column_value_563_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_563_pkey;


--
-- Name: column_value_564_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_564_pkey;


--
-- Name: column_value_565_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_565_pkey;


--
-- Name: column_value_566_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_566_pkey;


--
-- Name: column_value_567_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_567_pkey;


--
-- Name: column_value_568_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_568_pkey;


--
-- Name: column_value_569_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_569_pkey;


--
-- Name: column_value_56_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_56_pkey;


--
-- Name: column_value_570_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_570_pkey;


--
-- Name: column_value_571_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_571_pkey;


--
-- Name: column_value_572_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_572_pkey;


--
-- Name: column_value_573_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_573_pkey;


--
-- Name: column_value_574_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_574_pkey;


--
-- Name: column_value_575_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_575_pkey;


--
-- Name: column_value_576_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_576_pkey;


--
-- Name: column_value_577_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_577_pkey;


--
-- Name: column_value_578_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_578_pkey;


--
-- Name: column_value_579_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_579_pkey;


--
-- Name: column_value_57_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_57_pkey;


--
-- Name: column_value_580_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_580_pkey;


--
-- Name: column_value_581_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_581_pkey;


--
-- Name: column_value_582_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_582_pkey;


--
-- Name: column_value_583_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_583_pkey;


--
-- Name: column_value_584_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_584_pkey;


--
-- Name: column_value_585_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_585_pkey;


--
-- Name: column_value_586_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_586_pkey;


--
-- Name: column_value_587_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_587_pkey;


--
-- Name: column_value_588_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_588_pkey;


--
-- Name: column_value_589_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_589_pkey;


--
-- Name: column_value_58_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_58_pkey;


--
-- Name: column_value_590_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_590_pkey;


--
-- Name: column_value_591_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_591_pkey;


--
-- Name: column_value_592_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_592_pkey;


--
-- Name: column_value_593_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_593_pkey;


--
-- Name: column_value_594_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_594_pkey;


--
-- Name: column_value_59_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_59_pkey;


--
-- Name: column_value_5_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_5_pkey;


--
-- Name: column_value_60_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_60_pkey;


--
-- Name: column_value_61_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_61_pkey;


--
-- Name: column_value_62_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_62_pkey;


--
-- Name: column_value_63_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_63_pkey;


--
-- Name: column_value_64_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_64_pkey;


--
-- Name: column_value_65_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_65_pkey;


--
-- Name: column_value_66_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_66_pkey;


--
-- Name: column_value_67_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_67_pkey;


--
-- Name: column_value_68_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_68_pkey;


--
-- Name: column_value_69_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_69_pkey;


--
-- Name: column_value_6_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_6_pkey;


--
-- Name: column_value_70_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_70_pkey;


--
-- Name: column_value_71_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_71_pkey;


--
-- Name: column_value_72_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_72_pkey;


--
-- Name: column_value_73_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_73_pkey;


--
-- Name: column_value_74_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_74_pkey;


--
-- Name: column_value_75_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_75_pkey;


--
-- Name: column_value_76_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_76_pkey;


--
-- Name: column_value_77_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_77_pkey;


--
-- Name: column_value_78_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_78_pkey;


--
-- Name: column_value_79_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_79_pkey;


--
-- Name: column_value_7_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_7_pkey;


--
-- Name: column_value_80_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_80_pkey;


--
-- Name: column_value_81_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_81_pkey;


--
-- Name: column_value_82_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_82_pkey;


--
-- Name: column_value_83_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_83_pkey;


--
-- Name: column_value_84_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_84_pkey;


--
-- Name: column_value_85_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_85_pkey;


--
-- Name: column_value_86_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_86_pkey;


--
-- Name: column_value_87_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_87_pkey;


--
-- Name: column_value_88_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_88_pkey;


--
-- Name: column_value_89_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_89_pkey;


--
-- Name: column_value_8_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_8_pkey;


--
-- Name: column_value_90_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_90_pkey;


--
-- Name: column_value_91_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_91_pkey;


--
-- Name: column_value_92_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_92_pkey;


--
-- Name: column_value_93_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_93_pkey;


--
-- Name: column_value_94_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_94_pkey;


--
-- Name: column_value_95_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_95_pkey;


--
-- Name: column_value_96_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_96_pkey;


--
-- Name: column_value_97_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_97_pkey;


--
-- Name: column_value_98_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_98_pkey;


--
-- Name: column_value_99_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_99_pkey;


--
-- Name: column_value_9_pkey; Type: INDEX ATTACH; Schema: gerrydb; Owner: postgres
--

ALTER INDEX gerrydb.column_value_pkey ATTACH PARTITION gerrydb.column_value_9_pkey;


--
-- Name: api_key api_key_user_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.api_key
    ADD CONSTRAINT api_key_user_id_fkey FOREIGN KEY (user_id) REFERENCES gerrydb."user"(user_id);


--
-- Name: column column_canonical_ref_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb."column"
    ADD CONSTRAINT column_canonical_ref_id_fkey FOREIGN KEY (canonical_ref_id) REFERENCES gerrydb.column_ref(ref_id);


--
-- Name: column column_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb."column"
    ADD CONSTRAINT column_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: column column_namespace_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb."column"
    ADD CONSTRAINT column_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES gerrydb.namespace(namespace_id);


--
-- Name: column_ref column_ref_col_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_ref
    ADD CONSTRAINT column_ref_col_id_fkey FOREIGN KEY (col_id) REFERENCES gerrydb."column"(col_id);


--
-- Name: column_ref column_ref_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_ref
    ADD CONSTRAINT column_ref_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: column_ref column_ref_namespace_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_ref
    ADD CONSTRAINT column_ref_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES gerrydb.namespace(namespace_id);


--
-- Name: column_relation_member column_relation_member_member_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_relation_member
    ADD CONSTRAINT column_relation_member_member_id_fkey FOREIGN KEY (member_id) REFERENCES gerrydb."column"(col_id);


--
-- Name: column_relation_member column_relation_member_relation_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_relation_member
    ADD CONSTRAINT column_relation_member_relation_id_fkey FOREIGN KEY (relation_id) REFERENCES gerrydb.column_relation(relation_id);


--
-- Name: column_relation column_relation_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_relation
    ADD CONSTRAINT column_relation_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: column_relation column_relation_namespace_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_relation
    ADD CONSTRAINT column_relation_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES gerrydb.namespace(namespace_id);


--
-- Name: column_set_member column_set_member_ref_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_set_member
    ADD CONSTRAINT column_set_member_ref_id_fkey FOREIGN KEY (ref_id) REFERENCES gerrydb.column_ref(ref_id);


--
-- Name: column_set_member column_set_member_set_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_set_member
    ADD CONSTRAINT column_set_member_set_id_fkey FOREIGN KEY (set_id) REFERENCES gerrydb.column_set(set_id);


--
-- Name: column_set column_set_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_set
    ADD CONSTRAINT column_set_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: column_set column_set_namespace_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.column_set
    ADD CONSTRAINT column_set_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES gerrydb.namespace(namespace_id);


--
-- Name: column_value column_value_col_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE gerrydb.column_value
    ADD CONSTRAINT column_value_col_id_fkey FOREIGN KEY (col_id) REFERENCES gerrydb."column"(col_id);


--
-- Name: column_value column_value_geo_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE gerrydb.column_value
    ADD CONSTRAINT column_value_geo_id_fkey FOREIGN KEY (geo_id) REFERENCES gerrydb.geography(geo_id);


--
-- Name: column_value column_value_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE gerrydb.column_value
    ADD CONSTRAINT column_value_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: ensemble ensemble_graph_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.ensemble
    ADD CONSTRAINT ensemble_graph_id_fkey FOREIGN KEY (graph_id) REFERENCES gerrydb.graph(graph_id);


--
-- Name: ensemble ensemble_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.ensemble
    ADD CONSTRAINT ensemble_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: ensemble ensemble_namespace_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.ensemble
    ADD CONSTRAINT ensemble_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES gerrydb.namespace(namespace_id);


--
-- Name: ensemble ensemble_pop_col_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.ensemble
    ADD CONSTRAINT ensemble_pop_col_id_fkey FOREIGN KEY (pop_col_id) REFERENCES gerrydb."column"(col_id);


--
-- Name: ensemble ensemble_seed_plan_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.ensemble
    ADD CONSTRAINT ensemble_seed_plan_id_fkey FOREIGN KEY (seed_plan_id) REFERENCES gerrydb.plan(plan_id);


--
-- Name: etag etag_namespace_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.etag
    ADD CONSTRAINT etag_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES gerrydb.namespace(namespace_id);


--
-- Name: geo_hierarchy geo_hierarchy_child_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_hierarchy
    ADD CONSTRAINT geo_hierarchy_child_id_fkey FOREIGN KEY (child_id) REFERENCES gerrydb.geography(geo_id);


--
-- Name: geo_hierarchy geo_hierarchy_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_hierarchy
    ADD CONSTRAINT geo_hierarchy_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: geo_hierarchy geo_hierarchy_parent_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_hierarchy
    ADD CONSTRAINT geo_hierarchy_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES gerrydb.geography(geo_id);


--
-- Name: geo_import geo_import_created_by_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_import
    ADD CONSTRAINT geo_import_created_by_fkey FOREIGN KEY (created_by) REFERENCES gerrydb."user"(user_id);


--
-- Name: geo_import geo_import_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_import
    ADD CONSTRAINT geo_import_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: geo_import geo_import_namespace_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_import
    ADD CONSTRAINT geo_import_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES gerrydb.namespace(namespace_id);


--
-- Name: geo_layer geo_layer_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_layer
    ADD CONSTRAINT geo_layer_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: geo_layer geo_layer_namespace_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_layer
    ADD CONSTRAINT geo_layer_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES gerrydb.namespace(namespace_id);


--
-- Name: geo_set_member geo_set_member_geo_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_set_member
    ADD CONSTRAINT geo_set_member_geo_id_fkey FOREIGN KEY (geo_id) REFERENCES gerrydb.geography(geo_id);


--
-- Name: geo_set_member geo_set_member_set_version_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_set_member
    ADD CONSTRAINT geo_set_member_set_version_id_fkey FOREIGN KEY (set_version_id) REFERENCES gerrydb.geo_set_version(set_version_id);


--
-- Name: geo_set_version geo_set_version_layer_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_set_version
    ADD CONSTRAINT geo_set_version_layer_id_fkey FOREIGN KEY (layer_id) REFERENCES gerrydb.geo_layer(layer_id);


--
-- Name: geo_set_version geo_set_version_loc_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_set_version
    ADD CONSTRAINT geo_set_version_loc_id_fkey FOREIGN KEY (loc_id) REFERENCES gerrydb.locality(loc_id);


--
-- Name: geo_set_version geo_set_version_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_set_version
    ADD CONSTRAINT geo_set_version_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: geo_version geo_version_geo_bin_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_version
    ADD CONSTRAINT geo_version_geo_bin_id_fkey FOREIGN KEY (geo_bin_id) REFERENCES gerrydb.geo_bin(geo_bin_id);


--
-- Name: geo_version geo_version_geo_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_version
    ADD CONSTRAINT geo_version_geo_id_fkey FOREIGN KEY (geo_id) REFERENCES gerrydb.geography(geo_id);


--
-- Name: geo_version geo_version_import_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geo_version
    ADD CONSTRAINT geo_version_import_id_fkey FOREIGN KEY (import_id) REFERENCES gerrydb.geo_import(import_id);


--
-- Name: geography geography_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geography
    ADD CONSTRAINT geography_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: geography geography_namespace_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.geography
    ADD CONSTRAINT geography_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES gerrydb.namespace(namespace_id);


--
-- Name: graph_edge graph_edge_geo_id_1_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.graph_edge
    ADD CONSTRAINT graph_edge_geo_id_1_fkey FOREIGN KEY (geo_id_1) REFERENCES gerrydb.geography(geo_id);


--
-- Name: graph_edge graph_edge_geo_id_2_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.graph_edge
    ADD CONSTRAINT graph_edge_geo_id_2_fkey FOREIGN KEY (geo_id_2) REFERENCES gerrydb.geography(geo_id);


--
-- Name: graph_edge graph_edge_graph_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.graph_edge
    ADD CONSTRAINT graph_edge_graph_id_fkey FOREIGN KEY (graph_id) REFERENCES gerrydb.graph(graph_id);


--
-- Name: graph graph_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.graph
    ADD CONSTRAINT graph_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: graph graph_namespace_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.graph
    ADD CONSTRAINT graph_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES gerrydb.namespace(namespace_id);


--
-- Name: graph_render graph_render_created_by_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.graph_render
    ADD CONSTRAINT graph_render_created_by_fkey FOREIGN KEY (created_by) REFERENCES gerrydb."user"(user_id);


--
-- Name: graph_render graph_render_graph_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.graph_render
    ADD CONSTRAINT graph_render_graph_id_fkey FOREIGN KEY (graph_id) REFERENCES gerrydb.graph(graph_id);


--
-- Name: graph graph_set_version_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.graph
    ADD CONSTRAINT graph_set_version_id_fkey FOREIGN KEY (set_version_id) REFERENCES gerrydb.geo_set_version(set_version_id);


--
-- Name: locality locality_canonical_ref_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.locality
    ADD CONSTRAINT locality_canonical_ref_id_fkey FOREIGN KEY (canonical_ref_id) REFERENCES gerrydb.locality_ref(ref_id);


--
-- Name: locality locality_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.locality
    ADD CONSTRAINT locality_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: locality locality_parent_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.locality
    ADD CONSTRAINT locality_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES gerrydb.locality(loc_id);


--
-- Name: locality_ref locality_ref_loc_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.locality_ref
    ADD CONSTRAINT locality_ref_loc_id_fkey FOREIGN KEY (loc_id) REFERENCES gerrydb.locality(loc_id);


--
-- Name: locality_ref locality_ref_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.locality_ref
    ADD CONSTRAINT locality_ref_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: meta meta_created_by_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.meta
    ADD CONSTRAINT meta_created_by_fkey FOREIGN KEY (created_by) REFERENCES gerrydb."user"(user_id);


--
-- Name: namespace_limit namespace_limit_user_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.namespace_limit
    ADD CONSTRAINT namespace_limit_user_id_fkey FOREIGN KEY (user_id) REFERENCES gerrydb."user"(user_id);


--
-- Name: namespace namespace_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.namespace
    ADD CONSTRAINT namespace_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: plan_assignment plan_assignment_geo_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.plan_assignment
    ADD CONSTRAINT plan_assignment_geo_id_fkey FOREIGN KEY (geo_id) REFERENCES gerrydb.geography(geo_id);


--
-- Name: plan_assignment plan_assignment_plan_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.plan_assignment
    ADD CONSTRAINT plan_assignment_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES gerrydb.plan(plan_id);


--
-- Name: plan_limit plan_limit_layer_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.plan_limit
    ADD CONSTRAINT plan_limit_layer_id_fkey FOREIGN KEY (layer_id) REFERENCES gerrydb.geo_layer(layer_id);


--
-- Name: plan_limit plan_limit_loc_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.plan_limit
    ADD CONSTRAINT plan_limit_loc_id_fkey FOREIGN KEY (loc_id) REFERENCES gerrydb.locality(loc_id);


--
-- Name: plan_limit plan_limit_namespace_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.plan_limit
    ADD CONSTRAINT plan_limit_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES gerrydb.namespace(namespace_id);


--
-- Name: plan plan_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.plan
    ADD CONSTRAINT plan_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: plan plan_namespace_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.plan
    ADD CONSTRAINT plan_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES gerrydb.namespace(namespace_id);


--
-- Name: plan plan_set_version_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.plan
    ADD CONSTRAINT plan_set_version_id_fkey FOREIGN KEY (set_version_id) REFERENCES gerrydb.geo_set_version(set_version_id);


--
-- Name: user_group_member user_group_member_group_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.user_group_member
    ADD CONSTRAINT user_group_member_group_id_fkey FOREIGN KEY (group_id) REFERENCES gerrydb.user_group(group_id);


--
-- Name: user_group_member user_group_member_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.user_group_member
    ADD CONSTRAINT user_group_member_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: user_group_member user_group_member_user_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.user_group_member
    ADD CONSTRAINT user_group_member_user_id_fkey FOREIGN KEY (user_id) REFERENCES gerrydb."user"(user_id);


--
-- Name: user_group user_group_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.user_group
    ADD CONSTRAINT user_group_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: user_group_scope user_group_scope_group_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.user_group_scope
    ADD CONSTRAINT user_group_scope_group_id_fkey FOREIGN KEY (group_id) REFERENCES gerrydb.user_group(group_id);


--
-- Name: user_group_scope user_group_scope_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.user_group_scope
    ADD CONSTRAINT user_group_scope_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: user_group_scope user_group_scope_namespace_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.user_group_scope
    ADD CONSTRAINT user_group_scope_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES gerrydb.namespace(namespace_id);


--
-- Name: user_scope user_scope_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.user_scope
    ADD CONSTRAINT user_scope_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: user_scope user_scope_namespace_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.user_scope
    ADD CONSTRAINT user_scope_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES gerrydb.namespace(namespace_id);


--
-- Name: user_scope user_scope_user_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.user_scope
    ADD CONSTRAINT user_scope_user_id_fkey FOREIGN KEY (user_id) REFERENCES gerrydb."user"(user_id);


--
-- Name: view_geo_set_versions view_geo_set_versions_set_version_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view_geo_set_versions
    ADD CONSTRAINT view_geo_set_versions_set_version_id_fkey FOREIGN KEY (set_version_id) REFERENCES gerrydb.geo_set_version(set_version_id);


--
-- Name: view_geo_set_versions view_geo_set_versions_view_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view_geo_set_versions
    ADD CONSTRAINT view_geo_set_versions_view_id_fkey FOREIGN KEY (view_id) REFERENCES gerrydb.view(view_id);


--
-- Name: view view_graph_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view
    ADD CONSTRAINT view_graph_id_fkey FOREIGN KEY (graph_id) REFERENCES gerrydb.graph(graph_id);


--
-- Name: view view_layer_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view
    ADD CONSTRAINT view_layer_id_fkey FOREIGN KEY (layer_id) REFERENCES gerrydb.geo_layer(layer_id);


--
-- Name: view view_loc_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view
    ADD CONSTRAINT view_loc_id_fkey FOREIGN KEY (loc_id) REFERENCES gerrydb.locality(loc_id);


--
-- Name: view view_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view
    ADD CONSTRAINT view_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: view view_namespace_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view
    ADD CONSTRAINT view_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES gerrydb.namespace(namespace_id);


--
-- Name: view_render view_render_created_by_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view_render
    ADD CONSTRAINT view_render_created_by_fkey FOREIGN KEY (created_by) REFERENCES gerrydb."user"(user_id);


--
-- Name: view_render view_render_view_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view_render
    ADD CONSTRAINT view_render_view_id_fkey FOREIGN KEY (view_id) REFERENCES gerrydb.view(view_id);


--
-- Name: view_template_column_member view_template_column_member_ref_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view_template_column_member
    ADD CONSTRAINT view_template_column_member_ref_id_fkey FOREIGN KEY (ref_id) REFERENCES gerrydb.column_ref(ref_id);


--
-- Name: view_template_column_member view_template_column_member_template_version_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view_template_column_member
    ADD CONSTRAINT view_template_column_member_template_version_id_fkey FOREIGN KEY (template_version_id) REFERENCES gerrydb.view_template_version(template_version_id);


--
-- Name: view_template_column_set_member view_template_column_set_member_set_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view_template_column_set_member
    ADD CONSTRAINT view_template_column_set_member_set_id_fkey FOREIGN KEY (set_id) REFERENCES gerrydb.column_set(set_id);


--
-- Name: view_template_column_set_member view_template_column_set_member_template_version_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view_template_column_set_member
    ADD CONSTRAINT view_template_column_set_member_template_version_id_fkey FOREIGN KEY (template_version_id) REFERENCES gerrydb.view_template_version(template_version_id);


--
-- Name: view view_template_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view
    ADD CONSTRAINT view_template_id_fkey FOREIGN KEY (template_id) REFERENCES gerrydb.view_template(template_id);


--
-- Name: view_template view_template_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view_template
    ADD CONSTRAINT view_template_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: view_template view_template_namespace_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view_template
    ADD CONSTRAINT view_template_namespace_id_fkey FOREIGN KEY (namespace_id) REFERENCES gerrydb.namespace(namespace_id);


--
-- Name: view view_template_version_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view
    ADD CONSTRAINT view_template_version_id_fkey FOREIGN KEY (template_version_id) REFERENCES gerrydb.view_template_version(template_version_id);


--
-- Name: view_template_version view_template_version_meta_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view_template_version
    ADD CONSTRAINT view_template_version_meta_id_fkey FOREIGN KEY (meta_id) REFERENCES gerrydb.meta(meta_id);


--
-- Name: view_template_version view_template_version_template_id_fkey; Type: FK CONSTRAINT; Schema: gerrydb; Owner: postgres
--

ALTER TABLE ONLY gerrydb.view_template_version
    ADD CONSTRAINT view_template_version_template_id_fkey FOREIGN KEY (template_id) REFERENCES gerrydb.view_template(template_id);


--
-- PostgreSQL database dump complete
--

